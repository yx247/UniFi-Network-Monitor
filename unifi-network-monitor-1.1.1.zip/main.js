const Yt = globalThis, Be = Yt.ShadowRoot && (Yt.ShadyCSS === void 0 || Yt.ShadyCSS.nativeShadow) && "adoptedStyleSheets" in Document.prototype && "replace" in CSSStyleSheet.prototype, Us = Symbol(), es = /* @__PURE__ */ new WeakMap();
let fi = class {
  constructor(t, e, s) {
    if (this._$cssResult$ = !0, s !== Us) throw Error("CSSResult is not constructable. Use `unsafeCSS` or `css` instead.");
    this.cssText = t, this.t = e;
  }
  get styleSheet() {
    let t = this.o;
    const e = this.t;
    if (Be && t === void 0) {
      const s = e !== void 0 && e.length === 1;
      s && (t = es.get(e)), t === void 0 && ((this.o = t = new CSSStyleSheet()).replaceSync(this.cssText), s && es.set(e, t));
    }
    return t;
  }
  toString() {
    return this.cssText;
  }
};
const ss = Be ? (i) => i : (i) => i instanceof CSSStyleSheet ? ((t) => {
  let e = "";
  for (const s of t.cssRules) e += s.cssText;
  return ((s) => new fi(typeof s == "string" ? s : s + "", void 0, Us))(e);
})(i) : i, { is: gi, defineProperty: mi, getOwnPropertyDescriptor: vi, getOwnPropertyNames: wi, getOwnPropertySymbols: bi, getPrototypeOf: xi } = Object, Y = globalThis, is = Y.trustedTypes, yi = is ? is.emptyScript : "", $i = Y.reactiveElementPolyfillSupport, At = (i, t) => i, $e = { toAttribute(i, t) {
  switch (t) {
    case Boolean:
      i = i ? yi : null;
      break;
    case Object:
    case Array:
      i = i == null ? i : JSON.stringify(i);
  }
  return i;
}, fromAttribute(i, t) {
  let e = i;
  switch (t) {
    case Boolean:
      e = i !== null;
      break;
    case Number:
      e = i === null ? null : Number(i);
      break;
    case Object:
    case Array:
      try {
        e = JSON.parse(i);
      } catch {
        e = null;
      }
  }
  return e;
} }, Bs = (i, t) => !gi(i, t), ns = { attribute: !0, type: String, converter: $e, reflect: !1, useDefault: !1, hasChanged: Bs };
Symbol.metadata ?? (Symbol.metadata = Symbol("metadata")), Y.litPropertyMetadata ?? (Y.litPropertyMetadata = /* @__PURE__ */ new WeakMap());
let ht = class extends HTMLElement {
  static addInitializer(t) {
    this._$Ei(), (this.l ?? (this.l = [])).push(t);
  }
  static get observedAttributes() {
    return this.finalize(), this._$Eh && [...this._$Eh.keys()];
  }
  static createProperty(t, e = ns) {
    if (e.state && (e.attribute = !1), this._$Ei(), this.prototype.hasOwnProperty(t) && ((e = Object.create(e)).wrapped = !0), this.elementProperties.set(t, e), !e.noAccessor) {
      const s = Symbol(), n = this.getPropertyDescriptor(t, s, e);
      n !== void 0 && mi(this.prototype, t, n);
    }
  }
  static getPropertyDescriptor(t, e, s) {
    const { get: n, set: a } = vi(this.prototype, t) ?? { get() {
      return this[e];
    }, set(r) {
      this[e] = r;
    } };
    return { get: n, set(r) {
      const u = n?.call(this);
      a?.call(this, r), this.requestUpdate(t, u, s);
    }, configurable: !0, enumerable: !0 };
  }
  static getPropertyOptions(t) {
    return this.elementProperties.get(t) ?? ns;
  }
  static _$Ei() {
    if (this.hasOwnProperty(At("elementProperties"))) return;
    const t = xi(this);
    t.finalize(), t.l !== void 0 && (this.l = [...t.l]), this.elementProperties = new Map(t.elementProperties);
  }
  static finalize() {
    if (this.hasOwnProperty(At("finalized"))) return;
    if (this.finalized = !0, this._$Ei(), this.hasOwnProperty(At("properties"))) {
      const e = this.properties, s = [...wi(e), ...bi(e)];
      for (const n of s) this.createProperty(n, e[n]);
    }
    const t = this[Symbol.metadata];
    if (t !== null) {
      const e = litPropertyMetadata.get(t);
      if (e !== void 0) for (const [s, n] of e) this.elementProperties.set(s, n);
    }
    this._$Eh = /* @__PURE__ */ new Map();
    for (const [e, s] of this.elementProperties) {
      const n = this._$Eu(e, s);
      n !== void 0 && this._$Eh.set(n, e);
    }
    this.elementStyles = this.finalizeStyles(this.styles);
  }
  static finalizeStyles(t) {
    const e = [];
    if (Array.isArray(t)) {
      const s = new Set(t.flat(1 / 0).reverse());
      for (const n of s) e.unshift(ss(n));
    } else t !== void 0 && e.push(ss(t));
    return e;
  }
  static _$Eu(t, e) {
    const s = e.attribute;
    return s === !1 ? void 0 : typeof s == "string" ? s : typeof t == "string" ? t.toLowerCase() : void 0;
  }
  constructor() {
    super(), this._$Ep = void 0, this.isUpdatePending = !1, this.hasUpdated = !1, this._$Em = null, this._$Ev();
  }
  _$Ev() {
    this._$ES = new Promise((t) => this.enableUpdating = t), this._$AL = /* @__PURE__ */ new Map(), this._$E_(), this.requestUpdate(), this.constructor.l?.forEach((t) => t(this));
  }
  addController(t) {
    (this._$EO ?? (this._$EO = /* @__PURE__ */ new Set())).add(t), this.renderRoot !== void 0 && this.isConnected && t.hostConnected?.();
  }
  removeController(t) {
    this._$EO?.delete(t);
  }
  _$E_() {
    const t = /* @__PURE__ */ new Map(), e = this.constructor.elementProperties;
    for (const s of e.keys()) this.hasOwnProperty(s) && (t.set(s, this[s]), delete this[s]);
    t.size > 0 && (this._$Ep = t);
  }
  createRenderRoot() {
    const t = this.shadowRoot ?? this.attachShadow(this.constructor.shadowRootOptions);
    return ((e, s) => {
      if (Be) e.adoptedStyleSheets = s.map((n) => n instanceof CSSStyleSheet ? n : n.styleSheet);
      else for (const n of s) {
        const a = document.createElement("style"), r = Yt.litNonce;
        r !== void 0 && a.setAttribute("nonce", r), a.textContent = n.cssText, e.appendChild(a);
      }
    })(t, this.constructor.elementStyles), t;
  }
  connectedCallback() {
    this.renderRoot ?? (this.renderRoot = this.createRenderRoot()), this.enableUpdating(!0), this._$EO?.forEach((t) => t.hostConnected?.());
  }
  enableUpdating(t) {
  }
  disconnectedCallback() {
    this._$EO?.forEach((t) => t.hostDisconnected?.());
  }
  attributeChangedCallback(t, e, s) {
    this._$AK(t, s);
  }
  _$ET(t, e) {
    const s = this.constructor.elementProperties.get(t), n = this.constructor._$Eu(t, s);
    if (n !== void 0 && s.reflect === !0) {
      const a = (s.converter?.toAttribute !== void 0 ? s.converter : $e).toAttribute(e, s.type);
      this._$Em = t, a == null ? this.removeAttribute(n) : this.setAttribute(n, a), this._$Em = null;
    }
  }
  _$AK(t, e) {
    const s = this.constructor, n = s._$Eh.get(t);
    if (n !== void 0 && this._$Em !== n) {
      const a = s.getPropertyOptions(n), r = typeof a.converter == "function" ? { fromAttribute: a.converter } : a.converter?.fromAttribute !== void 0 ? a.converter : $e;
      this._$Em = n;
      const u = r.fromAttribute(e, a.type);
      this[n] = u ?? this._$Ej?.get(n) ?? u, this._$Em = null;
    }
  }
  requestUpdate(t, e, s, n = !1, a) {
    if (t !== void 0) {
      const r = this.constructor;
      if (n === !1 && (a = this[t]), s ?? (s = r.getPropertyOptions(t)), !((s.hasChanged ?? Bs)(a, e) || s.useDefault && s.reflect && a === this._$Ej?.get(t) && !this.hasAttribute(r._$Eu(t, s)))) return;
      this.C(t, e, s);
    }
    this.isUpdatePending === !1 && (this._$ES = this._$EP());
  }
  C(t, e, { useDefault: s, reflect: n, wrapped: a }, r) {
    s && !(this._$Ej ?? (this._$Ej = /* @__PURE__ */ new Map())).has(t) && (this._$Ej.set(t, r ?? e ?? this[t]), a !== !0 || r !== void 0) || (this._$AL.has(t) || (this.hasUpdated || s || (e = void 0), this._$AL.set(t, e)), n === !0 && this._$Em !== t && (this._$Eq ?? (this._$Eq = /* @__PURE__ */ new Set())).add(t));
  }
  async _$EP() {
    this.isUpdatePending = !0;
    try {
      await this._$ES;
    } catch (e) {
      Promise.reject(e);
    }
    const t = this.scheduleUpdate();
    return t != null && await t, !this.isUpdatePending;
  }
  scheduleUpdate() {
    return this.performUpdate();
  }
  performUpdate() {
    if (!this.isUpdatePending) return;
    if (!this.hasUpdated) {
      if (this.renderRoot ?? (this.renderRoot = this.createRenderRoot()), this._$Ep) {
        for (const [n, a] of this._$Ep) this[n] = a;
        this._$Ep = void 0;
      }
      const s = this.constructor.elementProperties;
      if (s.size > 0) for (const [n, a] of s) {
        const { wrapped: r } = a, u = this[n];
        r !== !0 || this._$AL.has(n) || u === void 0 || this.C(n, void 0, a, u);
      }
    }
    let t = !1;
    const e = this._$AL;
    try {
      t = this.shouldUpdate(e), t ? (this.willUpdate(e), this._$EO?.forEach((s) => s.hostUpdate?.()), this.update(e)) : this._$EM();
    } catch (s) {
      throw t = !1, this._$EM(), s;
    }
    t && this._$AE(e);
  }
  willUpdate(t) {
  }
  _$AE(t) {
    this._$EO?.forEach((e) => e.hostUpdated?.()), this.hasUpdated || (this.hasUpdated = !0, this.firstUpdated(t)), this.updated(t);
  }
  _$EM() {
    this._$AL = /* @__PURE__ */ new Map(), this.isUpdatePending = !1;
  }
  get updateComplete() {
    return this.getUpdateComplete();
  }
  getUpdateComplete() {
    return this._$ES;
  }
  shouldUpdate(t) {
    return !0;
  }
  update(t) {
    this._$Eq && (this._$Eq = this._$Eq.forEach((e) => this._$ET(e, this[e]))), this._$EM();
  }
  updated(t) {
  }
  firstUpdated(t) {
  }
};
ht.elementStyles = [], ht.shadowRootOptions = { mode: "open" }, ht[At("elementProperties")] = /* @__PURE__ */ new Map(), ht[At("finalized")] = /* @__PURE__ */ new Map(), $i?.({ ReactiveElement: ht }), (Y.reactiveElementVersions ?? (Y.reactiveElementVersions = [])).push("2.1.2");
const _t = globalThis, as = (i) => i, ee = _t.trustedTypes, rs = ee ? ee.createPolicy("lit-html", { createHTML: (i) => i }) : void 0, Os = "$lit$", V = `lit$${Math.random().toFixed(9).slice(2)}$`, zs = "?" + V, ki = `<${zs}>`, lt = document, Nt = () => lt.createComment(""), Rt = (i) => i === null || typeof i != "object" && typeof i != "function", ke = Array.isArray, fe = `[ 	
\f\r]`, yt = /<(?:(!--|\/[^a-zA-Z])|(\/?[a-zA-Z][^>\s]*)|(\/?$))/g, os = /-->/g, ls = />/g, tt = RegExp(`>|${fe}(?:([^\\s"'>=/]+)(${fe}*=${fe}*(?:[^ 	
\f\r"'\`<>=]|("|')|))|$)`, "g"), ds = /'/g, cs = /"/g, Ds = /^(?:script|style|textarea|title)$/i, Oe = /* @__PURE__ */ ((i) => (t, ...e) => ({ _$litType$: i, strings: t, values: e }))(1), mt = Symbol.for("lit-noChange"), C = Symbol.for("lit-nothing"), ps = /* @__PURE__ */ new WeakMap(), at = lt.createTreeWalker(lt, 129);
function Ws(i, t) {
  if (!ke(i) || !i.hasOwnProperty("raw")) throw Error("invalid template strings array");
  return rs !== void 0 ? rs.createHTML(t) : t;
}
const Ai = (i, t) => {
  const e = i.length - 1, s = [];
  let n, a = t === 2 ? "<svg>" : t === 3 ? "<math>" : "", r = yt;
  for (let u = 0; u < e; u++) {
    const o = i[u];
    let d, c, p = -1, g = 0;
    for (; g < o.length && (r.lastIndex = g, c = r.exec(o), c !== null); ) g = r.lastIndex, r === yt ? c[1] === "!--" ? r = os : c[1] !== void 0 ? r = ls : c[2] !== void 0 ? (Ds.test(c[2]) && (n = RegExp("</" + c[2], "g")), r = tt) : c[3] !== void 0 && (r = tt) : r === tt ? c[0] === ">" ? (r = n ?? yt, p = -1) : c[1] === void 0 ? p = -2 : (p = r.lastIndex - c[2].length, d = c[1], r = c[3] === void 0 ? tt : c[3] === '"' ? cs : ds) : r === cs || r === ds ? r = tt : r === os || r === ls ? r = yt : (r = tt, n = void 0);
    const m = r === tt && i[u + 1].startsWith("/>") ? " " : "";
    a += r === yt ? o + ki : p >= 0 ? (s.push(d), o.slice(0, p) + Os + o.slice(p) + V + m) : o + V + (p === -2 ? u : m);
  }
  return [Ws(i, a + (i[e] || "<?>") + (t === 2 ? "</svg>" : t === 3 ? "</math>" : "")), s];
};
class Ut {
  constructor({ strings: t, _$litType$: e }, s) {
    let n;
    this.parts = [];
    let a = 0, r = 0;
    const u = t.length - 1, o = this.parts, [d, c] = Ai(t, e);
    if (this.el = Ut.createElement(d, s), at.currentNode = this.el.content, e === 2 || e === 3) {
      const p = this.el.content.firstChild;
      p.replaceWith(...p.childNodes);
    }
    for (; (n = at.nextNode()) !== null && o.length < u; ) {
      if (n.nodeType === 1) {
        if (n.hasAttributes()) for (const p of n.getAttributeNames()) if (p.endsWith(Os)) {
          const g = c[r++], m = n.getAttribute(p).split(V), h = /([.?@])?(.*)/.exec(g);
          o.push({ type: 1, index: a, name: h[2], strings: m, ctor: h[1] === "." ? Mi : h[1] === "?" ? Si : h[1] === "@" ? Ci : re }), n.removeAttribute(p);
        } else p.startsWith(V) && (o.push({ type: 6, index: a }), n.removeAttribute(p));
        if (Ds.test(n.tagName)) {
          const p = n.textContent.split(V), g = p.length - 1;
          if (g > 0) {
            n.textContent = ee ? ee.emptyScript : "";
            for (let m = 0; m < g; m++) n.append(p[m], Nt()), at.nextNode(), o.push({ type: 2, index: ++a });
            n.append(p[g], Nt());
          }
        }
      } else if (n.nodeType === 8) if (n.data === zs) o.push({ type: 2, index: a });
      else {
        let p = -1;
        for (; (p = n.data.indexOf(V, p + 1)) !== -1; ) o.push({ type: 7, index: a }), p += V.length - 1;
      }
      a++;
    }
  }
  static createElement(t, e) {
    const s = lt.createElement("template");
    return s.innerHTML = t, s;
  }
}
function vt(i, t, e = i, s) {
  if (t === mt) return t;
  let n = s !== void 0 ? e._$Co?.[s] : e._$Cl;
  const a = Rt(t) ? void 0 : t._$litDirective$;
  return n?.constructor !== a && (n?._$AO?.(!1), a === void 0 ? n = void 0 : (n = new a(i), n._$AT(i, e, s)), s !== void 0 ? (e._$Co ?? (e._$Co = []))[s] = n : e._$Cl = n), n !== void 0 && (t = vt(i, n._$AS(i, t.values), n, s)), t;
}
class _i {
  constructor(t, e) {
    this._$AV = [], this._$AN = void 0, this._$AD = t, this._$AM = e;
  }
  get parentNode() {
    return this._$AM.parentNode;
  }
  get _$AU() {
    return this._$AM._$AU;
  }
  u(t) {
    const { el: { content: e }, parts: s } = this._$AD, n = (t?.creationScope ?? lt).importNode(e, !0);
    at.currentNode = n;
    let a = at.nextNode(), r = 0, u = 0, o = s[0];
    for (; o !== void 0; ) {
      if (r === o.index) {
        let d;
        o.type === 2 ? d = new Ht(a, a.nextSibling, this, t) : o.type === 1 ? d = new o.ctor(a, o.name, o.strings, this, t) : o.type === 6 && (d = new Pi(a, this, t)), this._$AV.push(d), o = s[++u];
      }
      r !== o?.index && (a = at.nextNode(), r++);
    }
    return at.currentNode = lt, n;
  }
  p(t) {
    let e = 0;
    for (const s of this._$AV) s !== void 0 && (s.strings !== void 0 ? (s._$AI(t, s, e), e += s.strings.length - 2) : s._$AI(t[e])), e++;
  }
}
class Ht {
  get _$AU() {
    return this._$AM?._$AU ?? this._$Cv;
  }
  constructor(t, e, s, n) {
    this.type = 2, this._$AH = C, this._$AN = void 0, this._$AA = t, this._$AB = e, this._$AM = s, this.options = n, this._$Cv = n?.isConnected ?? !0;
  }
  get parentNode() {
    let t = this._$AA.parentNode;
    const e = this._$AM;
    return e !== void 0 && t?.nodeType === 11 && (t = e.parentNode), t;
  }
  get startNode() {
    return this._$AA;
  }
  get endNode() {
    return this._$AB;
  }
  _$AI(t, e = this) {
    t = vt(this, t, e), Rt(t) ? t === C || t == null || t === "" ? (this._$AH !== C && this._$AR(), this._$AH = C) : t !== this._$AH && t !== mt && this._(t) : t._$litType$ !== void 0 ? this.$(t) : t.nodeType !== void 0 ? this.T(t) : ((s) => ke(s) || typeof s?.[Symbol.iterator] == "function")(t) ? this.k(t) : this._(t);
  }
  O(t) {
    return this._$AA.parentNode.insertBefore(t, this._$AB);
  }
  T(t) {
    this._$AH !== t && (this._$AR(), this._$AH = this.O(t));
  }
  _(t) {
    this._$AH !== C && Rt(this._$AH) ? this._$AA.nextSibling.data = t : this.T(lt.createTextNode(t)), this._$AH = t;
  }
  $(t) {
    const { values: e, _$litType$: s } = t, n = typeof s == "number" ? this._$AC(t) : (s.el === void 0 && (s.el = Ut.createElement(Ws(s.h, s.h[0]), this.options)), s);
    if (this._$AH?._$AD === n) this._$AH.p(e);
    else {
      const a = new _i(n, this), r = a.u(this.options);
      a.p(e), this.T(r), this._$AH = a;
    }
  }
  _$AC(t) {
    let e = ps.get(t.strings);
    return e === void 0 && ps.set(t.strings, e = new Ut(t)), e;
  }
  k(t) {
    ke(this._$AH) || (this._$AH = [], this._$AR());
    const e = this._$AH;
    let s, n = 0;
    for (const a of t) n === e.length ? e.push(s = new Ht(this.O(Nt()), this.O(Nt()), this, this.options)) : s = e[n], s._$AI(a), n++;
    n < e.length && (this._$AR(s && s._$AB.nextSibling, n), e.length = n);
  }
  _$AR(t = this._$AA.nextSibling, e) {
    for (this._$AP?.(!1, !0, e); t !== this._$AB; ) {
      const s = as(t).nextSibling;
      as(t).remove(), t = s;
    }
  }
  setConnected(t) {
    this._$AM === void 0 && (this._$Cv = t, this._$AP?.(t));
  }
}
class re {
  get tagName() {
    return this.element.tagName;
  }
  get _$AU() {
    return this._$AM._$AU;
  }
  constructor(t, e, s, n, a) {
    this.type = 1, this._$AH = C, this._$AN = void 0, this.element = t, this.name = e, this._$AM = n, this.options = a, s.length > 2 || s[0] !== "" || s[1] !== "" ? (this._$AH = Array(s.length - 1).fill(new String()), this.strings = s) : this._$AH = C;
  }
  _$AI(t, e = this, s, n) {
    const a = this.strings;
    let r = !1;
    if (a === void 0) t = vt(this, t, e, 0), r = !Rt(t) || t !== this._$AH && t !== mt, r && (this._$AH = t);
    else {
      const u = t;
      let o, d;
      for (t = a[0], o = 0; o < a.length - 1; o++) d = vt(this, u[s + o], e, o), d === mt && (d = this._$AH[o]), r || (r = !Rt(d) || d !== this._$AH[o]), d === C ? t = C : t !== C && (t += (d ?? "") + a[o + 1]), this._$AH[o] = d;
    }
    r && !n && this.j(t);
  }
  j(t) {
    t === C ? this.element.removeAttribute(this.name) : this.element.setAttribute(this.name, t ?? "");
  }
}
class Mi extends re {
  constructor() {
    super(...arguments), this.type = 3;
  }
  j(t) {
    this.element[this.name] = t === C ? void 0 : t;
  }
}
class Si extends re {
  constructor() {
    super(...arguments), this.type = 4;
  }
  j(t) {
    this.element.toggleAttribute(this.name, !!t && t !== C);
  }
}
class Ci extends re {
  constructor(t, e, s, n, a) {
    super(t, e, s, n, a), this.type = 5;
  }
  _$AI(t, e = this) {
    if ((t = vt(this, t, e, 0) ?? C) === mt) return;
    const s = this._$AH, n = t === C && s !== C || t.capture !== s.capture || t.once !== s.once || t.passive !== s.passive, a = t !== C && (s === C || n);
    n && this.element.removeEventListener(this.name, this, s), a && this.element.addEventListener(this.name, this, t), this._$AH = t;
  }
  handleEvent(t) {
    typeof this._$AH == "function" ? this._$AH.call(this.options?.host ?? this.element, t) : this._$AH.handleEvent(t);
  }
}
class Pi {
  constructor(t, e, s) {
    this.element = t, this.type = 6, this._$AN = void 0, this._$AM = e, this.options = s;
  }
  get _$AU() {
    return this._$AM._$AU;
  }
  _$AI(t) {
    vt(this, t);
  }
}
const Ti = _t.litHtmlPolyfillSupport;
Ti?.(Ut, Ht), (_t.litHtmlVersions ?? (_t.litHtmlVersions = [])).push("3.3.2");
const Mt = globalThis;
class St extends ht {
  constructor() {
    super(...arguments), this.renderOptions = { host: this }, this._$Do = void 0;
  }
  createRenderRoot() {
    var e;
    const t = super.createRenderRoot();
    return (e = this.renderOptions).renderBefore ?? (e.renderBefore = t.firstChild), t;
  }
  update(t) {
    const e = this.render();
    this.hasUpdated || (this.renderOptions.isConnected = this.isConnected), super.update(t), this._$Do = ((s, n, a) => {
      const r = a?.renderBefore ?? n;
      let u = r._$litPart$;
      if (u === void 0) {
        const o = a?.renderBefore ?? null;
        r._$litPart$ = u = new Ht(n.insertBefore(Nt(), o), o, void 0, a ?? {});
      }
      return u._$AI(s), u;
    })(e, this.renderRoot, this.renderOptions);
  }
  connectedCallback() {
    super.connectedCallback(), this._$Do?.setConnected(!0);
  }
  disconnectedCallback() {
    super.disconnectedCallback(), this._$Do?.setConnected(!1);
  }
  render() {
    return mt;
  }
}
St._$litElement$ = !0, St.finalized = !0, Mt.litElementHydrateSupport?.({ LitElement: St });
const Ei = Mt.litElementPolyfillSupport;
Ei?.({ LitElement: St }), (Mt.litElementVersions ?? (Mt.litElementVersions = [])).push("4.2.2");
class Hs extends St {
  constructor() {
    super(), this._initialized = !1, this._eventListeners = /* @__PURE__ */ new Map();
  }
  initializeMicroApp() {
    this._initialized || (this._setupEventListeners(), this._initialized = !0);
  }
  connectedCallback() {
    super.connectedCallback(), this.initializeMicroApp(), this.onConnected();
  }
  disconnectedCallback() {
    super.disconnectedCallback(), this._cleanupEventListeners(), this.onDisconnected();
  }
  attributeChangedCallback(t, e, s) {
    super.attributeChangedCallback(t, e, s), this.onAttributeChanged(t, e, s);
  }
  _setupEventListeners() {
  }
  _cleanupEventListeners() {
    const t = Array.from(this._eventListeners.entries());
    for (const [e, s] of t) s.forEach((n) => {
      window.removeEventListener(e, n);
    });
    this._eventListeners.clear();
  }
  addEventListener(t, e, s) {
    super.addEventListener(t, e, s);
  }
  dispatchCustomEvent(t, e) {
    const s = new CustomEvent(t, { bubbles: !0, composed: !0, detail: e });
    this.dispatchEvent(s);
  }
  onConnected() {
  }
  onDisconnected() {
  }
  onAttributeChanged(t, e, s) {
  }
  render() {
    return Oe``;
  }
}
class Kt {
  constructor(t, e = "en-US", s = "en-US", n = !1) {
    this.translations = t, this.defaultLocale = s, this._dev = n;
  }
  resolve(t, e) {
    if (typeof t == "string") return this.resolveString(t, e);
    if (Array.isArray(t)) return t.map((s) => this.resolve(s, e));
    if (t && typeof t == "object") {
      const s = {};
      for (const [n, a] of Object.entries(t)) s[n] = this.resolve(a, e);
      return s;
    }
    return t;
  }
  resolveString(t, e) {
    return !t || typeof t != "string" ? t : t.replace(/\$t:([A-Z_]+)/g, (s, n) => this.getTranslation(n, e));
  }
  getTranslation(t, e, s) {
    const n = this.getLocaleFallback(e);
    for (const a of n) if (this.translations[a] && this.translations[a][t] !== void 0) {
      let r = this.translations[a][t];
      return s && typeof s == "object" && Object.keys(s).length > 0 && (r = this.replacePlaceholders(r, s)), r;
    }
    return this._dev, t;
  }
  getLocaleFallback(t) {
    const e = [t];
    if (t.includes("-")) {
      const s = t.split("-")[0];
      e.push(s);
    }
    return e.includes(this.defaultLocale) || e.push(this.defaultLocale), e;
  }
  replacePlaceholders(t, e) {
    return t.replace(/\{(\w+)\}/g, (s, n) => n in e ? String(e[n]) : s);
  }
}
const oe = new class {
  constructor() {
    this.resolver = null, this._currentLocale = "en-US", this._defaultLocale = "en-US", this._translations = {}, this._staticPath = "", this._initialized = !1, this._dev = !1;
  }
  init(i = {}) {
    const { locale: t = "en-US", defaultLocale: e = "en-US", staticPath: s = "", dev: n = !1, translations: a = {} } = i;
    if (this._currentLocale = t, this._defaultLocale = e, this._staticPath = s, this._dev = n, a) for (const [r, u] of Object.entries(a)) this._translations[r] = { ...u };
    this.resolver = new Kt(this._translations, this._currentLocale, this._defaultLocale, this._dev), this._initialized = !0, this._loadTranslationsAsync(), this._dev;
  }
  async _loadTranslationsAsync() {
    if (!this._staticPath) return;
    const i = [this._currentLocale];
    this._defaultLocale && !i.includes(this._defaultLocale) && i.push(this._defaultLocale);
    for (const t of i) if (!(this._translations[t] && Object.keys(this._translations[t]).length > 0)) try {
      const e = `${this._staticPath.endsWith("/") ? this._staticPath.slice(0, -1) : this._staticPath}/locales/${t}.json`, s = await fetch(e);
      if (s.ok) {
        const n = await s.json();
        this._translations[t] = n, this.resolver = new Kt(this._translations, this._currentLocale, this._defaultLocale, this._dev), this._dev;
      } else this._dev;
    } catch {
      this._dev;
    }
  }
  t(i, t) {
    return this._initialized && this.resolver ? this.resolver.getTranslation(i, this._currentLocale, t) : i;
  }
  setLocale(i) {
    this._currentLocale !== i && (this._currentLocale = i, this.resolver = new Kt(this._translations, this._currentLocale, this._defaultLocale, this._dev), this._loadTranslationsAsync());
  }
  getLocale() {
    return this._currentLocale;
  }
  resolveConfig(i) {
    return this._initialized && this.resolver ? this.resolver.resolve(i, this._currentLocale) : i;
  }
  addTranslations(i, t) {
    this._translations[i] = { ...this._translations[i], ...t }, this.resolver = new Kt(this._translations, this._currentLocale, this._defaultLocale, this._dev);
  }
  updateStaticPath(i, t) {
    this._staticPath !== i && (this._staticPath = i, t !== void 0 && (this._dev = t), i && this._loadTranslationsAsync());
  }
}();
function ze(i = {}) {
  return oe.init(i);
}
function Ls(i, t) {
  return oe.t(i, t);
}
function Fs(i) {
  oe.setLocale(i);
}
function js(i, t) {
  oe.updateStaticPath(i, t);
}
let rt = "";
try {
  if (import.meta !== void 0 && import.meta.url) {
    const i = new URL(import.meta.url);
    i.protocol !== "http:" && i.protocol !== "https:" || (rt = i.origin);
  }
} catch {
}
function Ii(i) {
  try {
    rt = i.startsWith("http://") || i.startsWith("https://") ? new URL(i).origin : i;
  } catch {
    rt = i;
  }
}
function Ks(i, t) {
  const e = i.startsWith("/") ? i.slice(1) : i;
  return t ? `${t.endsWith("/") ? t : `${t}/`}${e}` : rt ? `${rt.endsWith("/") ? rt : `${rt}/`}${e}` : typeof window < "u" && window.location ? `${window.location.origin}/${e}` : `/${e}`;
}
class le extends Hs {
  constructor() {
    super(), this.spCtx = { api: {}, darkMode: !1, language: "en-US", networkMode: "wan", staticPath: "", role: 0, background: "", widgetInfo: {}, customParam: {} };
  }
  updateContext(t) {
    if (!t || typeof t != "object") return;
    const e = Object.fromEntries(Object.entries(t).filter(([s, n]) => n !== void 0));
    this.spCtx = { ...this.spCtx, ...e };
  }
  firstUpdated(t) {
    super.firstUpdated?.(t), this.onFirstRendered();
  }
  updated(t) {
    if (super.updated(t), t.has("spCtx")) {
      const e = t.get("spCtx") || {}, s = this.spCtx;
      s.darkMode !== e.darkMode && this.onDarkModeChanged(s.darkMode, e.darkMode), s.language !== e.language && this.onLanguageChanged(s.language, e.language), s.networkMode !== e.networkMode && this.onNetworkModeChanged(s.networkMode, e.networkMode), s.staticPath !== e.staticPath && s.staticPath && js(s.staticPath, s.dev);
    }
  }
  onConnected() {
    super.onConnected(), this._initI18nFromContext(), this.onInitialized({ widgetInfo: this.spCtx.widgetInfo, customParam: this.spCtx.customParam });
  }
  _initI18nFromContext() {
    try {
      ze({ locale: this.spCtx?.language || "en-US", staticPath: this.spCtx?.staticPath || "", dev: this.spCtx?.dev || !1 });
    } catch {
    }
  }
  t(t, e) {
    return Ls(t, e);
  }
  getAssetPath(t) {
    return Ks(t, this.spCtx?.staticPath || "");
  }
  onInitialized(t) {
  }
  onFirstRendered() {
  }
  onDarkModeChanged(t, e) {
  }
  onLanguageChanged(t, e) {
    Fs(t);
  }
  onNetworkModeChanged(t, e) {
  }
  render() {
    return Oe``;
  }
}
le.properties = { spCtx: { type: Object, attribute: !1 } };
class Gs extends Hs {
  constructor() {
    super(), this.spCtx = { api: {}, darkMode: !1, language: "en-US", networkMode: "wan", staticPath: "", role: 0, widgetInfo: {}, defaultBackgroundColor: "" };
  }
  updateContext(t) {
    if (!t || typeof t != "object") return;
    const e = Object.fromEntries(Object.entries(t).filter(([s, n]) => n !== void 0));
    this.spCtx = { ...this.spCtx, ...e };
  }
  firstUpdated(t) {
    super.firstUpdated?.(t), this.onFirstRendered();
  }
  updated(t) {
    if (super.updated(t), t.has("spCtx")) {
      const e = t.get("spCtx") || {}, s = this.spCtx;
      s.widgetInfo !== e.widgetInfo && this.onWidgetInfoChanged(s.widgetInfo, e.widgetInfo), s.darkMode !== e.darkMode && this.onDarkModeChanged(s.darkMode, e.darkMode), s.language !== e.language && this.onLanguageChanged(s.language, e.language), s.networkMode !== e.networkMode && this.onNetworkModeChanged(s.networkMode, e.networkMode), s.staticPath !== e.staticPath && s.staticPath && js(s.staticPath, s.dev);
    }
  }
  onConnected() {
    super.onConnected(), this._initI18nFromContext(), this.onInitialized();
  }
  _initI18nFromContext() {
    try {
      ze({ locale: this.spCtx?.language || "en-US", staticPath: this.spCtx?.staticPath || "", dev: this.spCtx?.dev || !1 });
    } catch {
    }
  }
  t(t, e) {
    return Ls(t, e);
  }
  getAssetPath(t) {
    return Ks(t, this.spCtx?.staticPath || "");
  }
  onInitialized() {
  }
  onFirstRendered() {
  }
  onDarkModeChanged(t, e) {
  }
  onLanguageChanged(t, e) {
    Fs(t);
  }
  onNetworkModeChanged(t, e) {
  }
  onWidgetInfoChanged(t, e) {
  }
  render() {
    return Oe``;
  }
}
Gs.properties = { spCtx: { type: Object, attribute: !1 } };
const Ni = "1.0.19";
function Ri(i = {}) {
  const { translations: t, defaultLocale: e = "en-US", dev: s = !1, assetBaseURL: n } = i;
  n && Ii(n), ze({ locale: e, defaultLocale: e, translations: t, dev: s });
}
const Ae = {
  appJsonVersion: "1.1",
  author: "UniFi Monitor Contributors",
  microAppId: "unifi-network-monitor",
  version: "1.1.1",
  entry: "main.js",
  icon: "icon.png",
  debug: !1,
  appInfo: {
    appName: "$t:APP_NAME",
    description: "$t:APP_DESCRIPTION",
    networkDescription: "$t:NETWORK_DESCRIPTION"
  },
  locales: {
    "zh-CN": "zh-CN.json",
    "en-US": "en-US.json"
  },
  defaultLocale: "zh-CN",
  permissions: ["network", "dataNode"],
  // The gateway address is user-configurable, so a static host allow-list cannot cover it.
  // The runtime client enforces that every request targets exactly the configured gateway
  // origin (scheme + host + port) and only GET requests are implemented.
  networkDomains: ["*"],
  dataNodes: {
    unifiConfig: { scope: "user", isPublic: !1 },
    unifiAuth: { scope: "user", isPublic: !1 },
    unifiCache: { scope: "user", isPublic: !1 }
  }
}, Ui = { "unifi-settings": { background: "#0f1015", backgroundDark: "#0f1015", headerTextColor: "#ffffff", headerTextColorDark: "#ffffff", width: 760, height: 800, resize: !0, move: !0, showFullscreenBtn: !0 }, "unifi-dashboard": { type: "main", background: "linear-gradient(160deg, #0e1015 0%, #121722 55%, #0e1015 100%)", backgroundDark: "linear-gradient(160deg, #0e1015 0%, #121722 55%, #0e1015 100%)", headerTextColor: "#ffffff", headerTextColorDark: "#ffffff", width: 1280, height: 860, resize: !0, move: !0, showFullscreenBtn: !0 }, "unifi-client-detail": { background: "#0f1015", backgroundDark: "#0f1015", headerTextColor: "#ffffff", headerTextColorDark: "#ffffff", width: 760, height: 760, resize: !0, move: !0, showFullscreenBtn: !0 } }, Bi = { "unifi-widget": { configComponentName: "unifi-settings", size: ["1x1", "1x2", "2x1", "2x2", "2x4", "1xfull", "4x4"], background: "", widgetName: "$t:WIDGET_NAME", widgetDescription: "$t:WIDGET_DESCRIPTION", sort: 20 } }, Gt = {
  pages: Ui,
  widgets: Bi
};
const Jt = globalThis, De = Jt.ShadowRoot && (Jt.ShadyCSS === void 0 || Jt.ShadyCSS.nativeShadow) && "adoptedStyleSheets" in Document.prototype && "replace" in CSSStyleSheet.prototype, We = Symbol(), us = /* @__PURE__ */ new WeakMap();
let qs = class {
  constructor(t, e, s) {
    if (this._$cssResult$ = !0, s !== We) throw Error("CSSResult is not constructable. Use `unsafeCSS` or `css` instead.");
    this.cssText = t, this.t = e;
  }
  get styleSheet() {
    let t = this.o;
    const e = this.t;
    if (De && t === void 0) {
      const s = e !== void 0 && e.length === 1;
      s && (t = us.get(e)), t === void 0 && ((this.o = t = new CSSStyleSheet()).replaceSync(this.cssText), s && us.set(e, t));
    }
    return t;
  }
  toString() {
    return this.cssText;
  }
};
const Oi = (i) => new qs(typeof i == "string" ? i : i + "", void 0, We), Lt = (i, ...t) => {
  const e = i.length === 1 ? i[0] : t.reduce((s, n, a) => s + ((r) => {
    if (r._$cssResult$ === !0) return r.cssText;
    if (typeof r == "number") return r;
    throw Error("Value passed to 'css' function must be a 'css' function result: " + r + ". Use 'unsafeCSS' to pass non-literal values, but take care to ensure page security.");
  })(n) + i[a + 1], i[0]);
  return new qs(e, i, We);
}, zi = (i, t) => {
  if (De) i.adoptedStyleSheets = t.map((e) => e instanceof CSSStyleSheet ? e : e.styleSheet);
  else for (const e of t) {
    const s = document.createElement("style"), n = Jt.litNonce;
    n !== void 0 && s.setAttribute("nonce", n), s.textContent = e.cssText, i.appendChild(s);
  }
}, hs = De ? (i) => i : (i) => i instanceof CSSStyleSheet ? ((t) => {
  let e = "";
  for (const s of t.cssRules) e += s.cssText;
  return Oi(e);
})(i) : i;
const { is: Di, defineProperty: Wi, getOwnPropertyDescriptor: Hi, getOwnPropertyNames: Li, getOwnPropertySymbols: Fi, getPrototypeOf: ji } = Object, J = globalThis, fs = J.trustedTypes, Ki = fs ? fs.emptyScript : "", Gi = J.reactiveElementPolyfillSupport, Ct = (i, t) => i, _e = { toAttribute(i, t) {
  switch (t) {
    case Boolean:
      i = i ? Ki : null;
      break;
    case Object:
    case Array:
      i = i == null ? i : JSON.stringify(i);
  }
  return i;
}, fromAttribute(i, t) {
  let e = i;
  switch (t) {
    case Boolean:
      e = i !== null;
      break;
    case Number:
      e = i === null ? null : Number(i);
      break;
    case Object:
    case Array:
      try {
        e = JSON.parse(i);
      } catch {
        e = null;
      }
  }
  return e;
} }, Vs = (i, t) => !Di(i, t), gs = { attribute: !0, type: String, converter: _e, reflect: !1, useDefault: !1, hasChanged: Vs };
Symbol.metadata ?? (Symbol.metadata = Symbol("metadata")), J.litPropertyMetadata ?? (J.litPropertyMetadata = /* @__PURE__ */ new WeakMap());
let ft = class extends HTMLElement {
  static addInitializer(t) {
    this._$Ei(), (this.l ?? (this.l = [])).push(t);
  }
  static get observedAttributes() {
    return this.finalize(), this._$Eh && [...this._$Eh.keys()];
  }
  static createProperty(t, e = gs) {
    if (e.state && (e.attribute = !1), this._$Ei(), this.prototype.hasOwnProperty(t) && ((e = Object.create(e)).wrapped = !0), this.elementProperties.set(t, e), !e.noAccessor) {
      const s = Symbol(), n = this.getPropertyDescriptor(t, s, e);
      n !== void 0 && Wi(this.prototype, t, n);
    }
  }
  static getPropertyDescriptor(t, e, s) {
    const { get: n, set: a } = Hi(this.prototype, t) ?? { get() {
      return this[e];
    }, set(r) {
      this[e] = r;
    } };
    return { get: n, set(r) {
      const u = n?.call(this);
      a?.call(this, r), this.requestUpdate(t, u, s);
    }, configurable: !0, enumerable: !0 };
  }
  static getPropertyOptions(t) {
    return this.elementProperties.get(t) ?? gs;
  }
  static _$Ei() {
    if (this.hasOwnProperty(Ct("elementProperties"))) return;
    const t = ji(this);
    t.finalize(), t.l !== void 0 && (this.l = [...t.l]), this.elementProperties = new Map(t.elementProperties);
  }
  static finalize() {
    if (this.hasOwnProperty(Ct("finalized"))) return;
    if (this.finalized = !0, this._$Ei(), this.hasOwnProperty(Ct("properties"))) {
      const e = this.properties, s = [...Li(e), ...Fi(e)];
      for (const n of s) this.createProperty(n, e[n]);
    }
    const t = this[Symbol.metadata];
    if (t !== null) {
      const e = litPropertyMetadata.get(t);
      if (e !== void 0) for (const [s, n] of e) this.elementProperties.set(s, n);
    }
    this._$Eh = /* @__PURE__ */ new Map();
    for (const [e, s] of this.elementProperties) {
      const n = this._$Eu(e, s);
      n !== void 0 && this._$Eh.set(n, e);
    }
    this.elementStyles = this.finalizeStyles(this.styles);
  }
  static finalizeStyles(t) {
    const e = [];
    if (Array.isArray(t)) {
      const s = new Set(t.flat(1 / 0).reverse());
      for (const n of s) e.unshift(hs(n));
    } else t !== void 0 && e.push(hs(t));
    return e;
  }
  static _$Eu(t, e) {
    const s = e.attribute;
    return s === !1 ? void 0 : typeof s == "string" ? s : typeof t == "string" ? t.toLowerCase() : void 0;
  }
  constructor() {
    super(), this._$Ep = void 0, this.isUpdatePending = !1, this.hasUpdated = !1, this._$Em = null, this._$Ev();
  }
  _$Ev() {
    this._$ES = new Promise((t) => this.enableUpdating = t), this._$AL = /* @__PURE__ */ new Map(), this._$E_(), this.requestUpdate(), this.constructor.l?.forEach((t) => t(this));
  }
  addController(t) {
    (this._$EO ?? (this._$EO = /* @__PURE__ */ new Set())).add(t), this.renderRoot !== void 0 && this.isConnected && t.hostConnected?.();
  }
  removeController(t) {
    this._$EO?.delete(t);
  }
  _$E_() {
    const t = /* @__PURE__ */ new Map(), e = this.constructor.elementProperties;
    for (const s of e.keys()) this.hasOwnProperty(s) && (t.set(s, this[s]), delete this[s]);
    t.size > 0 && (this._$Ep = t);
  }
  createRenderRoot() {
    const t = this.shadowRoot ?? this.attachShadow(this.constructor.shadowRootOptions);
    return zi(t, this.constructor.elementStyles), t;
  }
  connectedCallback() {
    this.renderRoot ?? (this.renderRoot = this.createRenderRoot()), this.enableUpdating(!0), this._$EO?.forEach((t) => t.hostConnected?.());
  }
  enableUpdating(t) {
  }
  disconnectedCallback() {
    this._$EO?.forEach((t) => t.hostDisconnected?.());
  }
  attributeChangedCallback(t, e, s) {
    this._$AK(t, s);
  }
  _$ET(t, e) {
    const s = this.constructor.elementProperties.get(t), n = this.constructor._$Eu(t, s);
    if (n !== void 0 && s.reflect === !0) {
      const a = (s.converter?.toAttribute !== void 0 ? s.converter : _e).toAttribute(e, s.type);
      this._$Em = t, a == null ? this.removeAttribute(n) : this.setAttribute(n, a), this._$Em = null;
    }
  }
  _$AK(t, e) {
    const s = this.constructor, n = s._$Eh.get(t);
    if (n !== void 0 && this._$Em !== n) {
      const a = s.getPropertyOptions(n), r = typeof a.converter == "function" ? { fromAttribute: a.converter } : a.converter?.fromAttribute !== void 0 ? a.converter : _e;
      this._$Em = n;
      const u = r.fromAttribute(e, a.type);
      this[n] = u ?? this._$Ej?.get(n) ?? u, this._$Em = null;
    }
  }
  requestUpdate(t, e, s, n = !1, a) {
    if (t !== void 0) {
      const r = this.constructor;
      if (n === !1 && (a = this[t]), s ?? (s = r.getPropertyOptions(t)), !((s.hasChanged ?? Vs)(a, e) || s.useDefault && s.reflect && a === this._$Ej?.get(t) && !this.hasAttribute(r._$Eu(t, s)))) return;
      this.C(t, e, s);
    }
    this.isUpdatePending === !1 && (this._$ES = this._$EP());
  }
  C(t, e, { useDefault: s, reflect: n, wrapped: a }, r) {
    s && !(this._$Ej ?? (this._$Ej = /* @__PURE__ */ new Map())).has(t) && (this._$Ej.set(t, r ?? e ?? this[t]), a !== !0 || r !== void 0) || (this._$AL.has(t) || (this.hasUpdated || s || (e = void 0), this._$AL.set(t, e)), n === !0 && this._$Em !== t && (this._$Eq ?? (this._$Eq = /* @__PURE__ */ new Set())).add(t));
  }
  async _$EP() {
    this.isUpdatePending = !0;
    try {
      await this._$ES;
    } catch (e) {
      Promise.reject(e);
    }
    const t = this.scheduleUpdate();
    return t != null && await t, !this.isUpdatePending;
  }
  scheduleUpdate() {
    return this.performUpdate();
  }
  performUpdate() {
    if (!this.isUpdatePending) return;
    if (!this.hasUpdated) {
      if (this.renderRoot ?? (this.renderRoot = this.createRenderRoot()), this._$Ep) {
        for (const [n, a] of this._$Ep) this[n] = a;
        this._$Ep = void 0;
      }
      const s = this.constructor.elementProperties;
      if (s.size > 0) for (const [n, a] of s) {
        const { wrapped: r } = a, u = this[n];
        r !== !0 || this._$AL.has(n) || u === void 0 || this.C(n, void 0, a, u);
      }
    }
    let t = !1;
    const e = this._$AL;
    try {
      t = this.shouldUpdate(e), t ? (this.willUpdate(e), this._$EO?.forEach((s) => s.hostUpdate?.()), this.update(e)) : this._$EM();
    } catch (s) {
      throw t = !1, this._$EM(), s;
    }
    t && this._$AE(e);
  }
  willUpdate(t) {
  }
  _$AE(t) {
    this._$EO?.forEach((e) => e.hostUpdated?.()), this.hasUpdated || (this.hasUpdated = !0, this.firstUpdated(t)), this.updated(t);
  }
  _$EM() {
    this._$AL = /* @__PURE__ */ new Map(), this.isUpdatePending = !1;
  }
  get updateComplete() {
    return this.getUpdateComplete();
  }
  getUpdateComplete() {
    return this._$ES;
  }
  shouldUpdate(t) {
    return !0;
  }
  update(t) {
    this._$Eq && (this._$Eq = this._$Eq.forEach((e) => this._$ET(e, this[e]))), this._$EM();
  }
  updated(t) {
  }
  firstUpdated(t) {
  }
};
ft.elementStyles = [], ft.shadowRootOptions = { mode: "open" }, ft[Ct("elementProperties")] = /* @__PURE__ */ new Map(), ft[Ct("finalized")] = /* @__PURE__ */ new Map(), Gi?.({ ReactiveElement: ft }), (J.reactiveElementVersions ?? (J.reactiveElementVersions = [])).push("2.1.2");
const Pt = globalThis, ms = (i) => i, se = Pt.trustedTypes, vs = se ? se.createPolicy("lit-html", { createHTML: (i) => i }) : void 0, Xs = "$lit$", X = `lit$${Math.random().toFixed(9).slice(2)}$`, Zs = "?" + X, qi = `<${Zs}>`, dt = document, Bt = () => dt.createComment(""), Ot = (i) => i === null || typeof i != "object" && typeof i != "function", He = Array.isArray, Vi = (i) => He(i) || typeof i?.[Symbol.iterator] == "function", ge = `[ 	
\f\r]`, $t = /<(?:(!--|\/[^a-zA-Z])|(\/?[a-zA-Z][^>\s]*)|(\/?$))/g, ws = /-->/g, bs = />/g, et = RegExp(`>|${ge}(?:([^\\s"'>=/]+)(${ge}*=${ge}*(?:[^ 	
\f\r"'\`<>=]|("|')|))|$)`, "g"), xs = /'/g, ys = /"/g, Ys = /^(?:script|style|textarea|title)$/i, Js = (i) => (t, ...e) => ({ _$litType$: i, strings: t, values: e }), l = Js(1), st = Js(2), wt = Symbol.for("lit-noChange"), v = Symbol.for("lit-nothing"), $s = /* @__PURE__ */ new WeakMap(), ot = dt.createTreeWalker(dt, 129);
function Qs(i, t) {
  if (!He(i) || !i.hasOwnProperty("raw")) throw Error("invalid template strings array");
  return vs !== void 0 ? vs.createHTML(t) : t;
}
const Xi = (i, t) => {
  const e = i.length - 1, s = [];
  let n, a = t === 2 ? "<svg>" : t === 3 ? "<math>" : "", r = $t;
  for (let u = 0; u < e; u++) {
    const o = i[u];
    let d, c, p = -1, g = 0;
    for (; g < o.length && (r.lastIndex = g, c = r.exec(o), c !== null); ) g = r.lastIndex, r === $t ? c[1] === "!--" ? r = ws : c[1] !== void 0 ? r = bs : c[2] !== void 0 ? (Ys.test(c[2]) && (n = RegExp("</" + c[2], "g")), r = et) : c[3] !== void 0 && (r = et) : r === et ? c[0] === ">" ? (r = n ?? $t, p = -1) : c[1] === void 0 ? p = -2 : (p = r.lastIndex - c[2].length, d = c[1], r = c[3] === void 0 ? et : c[3] === '"' ? ys : xs) : r === ys || r === xs ? r = et : r === ws || r === bs ? r = $t : (r = et, n = void 0);
    const m = r === et && i[u + 1].startsWith("/>") ? " " : "";
    a += r === $t ? o + qi : p >= 0 ? (s.push(d), o.slice(0, p) + Xs + o.slice(p) + X + m) : o + X + (p === -2 ? u : m);
  }
  return [Qs(i, a + (i[e] || "<?>") + (t === 2 ? "</svg>" : t === 3 ? "</math>" : "")), s];
};
class zt {
  constructor({ strings: t, _$litType$: e }, s) {
    let n;
    this.parts = [];
    let a = 0, r = 0;
    const u = t.length - 1, o = this.parts, [d, c] = Xi(t, e);
    if (this.el = zt.createElement(d, s), ot.currentNode = this.el.content, e === 2 || e === 3) {
      const p = this.el.content.firstChild;
      p.replaceWith(...p.childNodes);
    }
    for (; (n = ot.nextNode()) !== null && o.length < u; ) {
      if (n.nodeType === 1) {
        if (n.hasAttributes()) for (const p of n.getAttributeNames()) if (p.endsWith(Xs)) {
          const g = c[r++], m = n.getAttribute(p).split(X), h = /([.?@])?(.*)/.exec(g);
          o.push({ type: 1, index: a, name: h[2], strings: m, ctor: h[1] === "." ? Yi : h[1] === "?" ? Ji : h[1] === "@" ? Qi : de }), n.removeAttribute(p);
        } else p.startsWith(X) && (o.push({ type: 6, index: a }), n.removeAttribute(p));
        if (Ys.test(n.tagName)) {
          const p = n.textContent.split(X), g = p.length - 1;
          if (g > 0) {
            n.textContent = se ? se.emptyScript : "";
            for (let m = 0; m < g; m++) n.append(p[m], Bt()), ot.nextNode(), o.push({ type: 2, index: ++a });
            n.append(p[g], Bt());
          }
        }
      } else if (n.nodeType === 8) if (n.data === Zs) o.push({ type: 2, index: a });
      else {
        let p = -1;
        for (; (p = n.data.indexOf(X, p + 1)) !== -1; ) o.push({ type: 7, index: a }), p += X.length - 1;
      }
      a++;
    }
  }
  static createElement(t, e) {
    const s = dt.createElement("template");
    return s.innerHTML = t, s;
  }
}
function bt(i, t, e = i, s) {
  if (t === wt) return t;
  let n = s !== void 0 ? e._$Co?.[s] : e._$Cl;
  const a = Ot(t) ? void 0 : t._$litDirective$;
  return n?.constructor !== a && (n?._$AO?.(!1), a === void 0 ? n = void 0 : (n = new a(i), n._$AT(i, e, s)), s !== void 0 ? (e._$Co ?? (e._$Co = []))[s] = n : e._$Cl = n), n !== void 0 && (t = bt(i, n._$AS(i, t.values), n, s)), t;
}
class Zi {
  constructor(t, e) {
    this._$AV = [], this._$AN = void 0, this._$AD = t, this._$AM = e;
  }
  get parentNode() {
    return this._$AM.parentNode;
  }
  get _$AU() {
    return this._$AM._$AU;
  }
  u(t) {
    const { el: { content: e }, parts: s } = this._$AD, n = (t?.creationScope ?? dt).importNode(e, !0);
    ot.currentNode = n;
    let a = ot.nextNode(), r = 0, u = 0, o = s[0];
    for (; o !== void 0; ) {
      if (r === o.index) {
        let d;
        o.type === 2 ? d = new Ft(a, a.nextSibling, this, t) : o.type === 1 ? d = new o.ctor(a, o.name, o.strings, this, t) : o.type === 6 && (d = new tn(a, this, t)), this._$AV.push(d), o = s[++u];
      }
      r !== o?.index && (a = ot.nextNode(), r++);
    }
    return ot.currentNode = dt, n;
  }
  p(t) {
    let e = 0;
    for (const s of this._$AV) s !== void 0 && (s.strings !== void 0 ? (s._$AI(t, s, e), e += s.strings.length - 2) : s._$AI(t[e])), e++;
  }
}
class Ft {
  get _$AU() {
    return this._$AM?._$AU ?? this._$Cv;
  }
  constructor(t, e, s, n) {
    this.type = 2, this._$AH = v, this._$AN = void 0, this._$AA = t, this._$AB = e, this._$AM = s, this.options = n, this._$Cv = n?.isConnected ?? !0;
  }
  get parentNode() {
    let t = this._$AA.parentNode;
    const e = this._$AM;
    return e !== void 0 && t?.nodeType === 11 && (t = e.parentNode), t;
  }
  get startNode() {
    return this._$AA;
  }
  get endNode() {
    return this._$AB;
  }
  _$AI(t, e = this) {
    t = bt(this, t, e), Ot(t) ? t === v || t == null || t === "" ? (this._$AH !== v && this._$AR(), this._$AH = v) : t !== this._$AH && t !== wt && this._(t) : t._$litType$ !== void 0 ? this.$(t) : t.nodeType !== void 0 ? this.T(t) : Vi(t) ? this.k(t) : this._(t);
  }
  O(t) {
    return this._$AA.parentNode.insertBefore(t, this._$AB);
  }
  T(t) {
    this._$AH !== t && (this._$AR(), this._$AH = this.O(t));
  }
  _(t) {
    this._$AH !== v && Ot(this._$AH) ? this._$AA.nextSibling.data = t : this.T(dt.createTextNode(t)), this._$AH = t;
  }
  $(t) {
    const { values: e, _$litType$: s } = t, n = typeof s == "number" ? this._$AC(t) : (s.el === void 0 && (s.el = zt.createElement(Qs(s.h, s.h[0]), this.options)), s);
    if (this._$AH?._$AD === n) this._$AH.p(e);
    else {
      const a = new Zi(n, this), r = a.u(this.options);
      a.p(e), this.T(r), this._$AH = a;
    }
  }
  _$AC(t) {
    let e = $s.get(t.strings);
    return e === void 0 && $s.set(t.strings, e = new zt(t)), e;
  }
  k(t) {
    He(this._$AH) || (this._$AH = [], this._$AR());
    const e = this._$AH;
    let s, n = 0;
    for (const a of t) n === e.length ? e.push(s = new Ft(this.O(Bt()), this.O(Bt()), this, this.options)) : s = e[n], s._$AI(a), n++;
    n < e.length && (this._$AR(s && s._$AB.nextSibling, n), e.length = n);
  }
  _$AR(t = this._$AA.nextSibling, e) {
    for (this._$AP?.(!1, !0, e); t !== this._$AB; ) {
      const s = ms(t).nextSibling;
      ms(t).remove(), t = s;
    }
  }
  setConnected(t) {
    this._$AM === void 0 && (this._$Cv = t, this._$AP?.(t));
  }
}
class de {
  get tagName() {
    return this.element.tagName;
  }
  get _$AU() {
    return this._$AM._$AU;
  }
  constructor(t, e, s, n, a) {
    this.type = 1, this._$AH = v, this._$AN = void 0, this.element = t, this.name = e, this._$AM = n, this.options = a, s.length > 2 || s[0] !== "" || s[1] !== "" ? (this._$AH = Array(s.length - 1).fill(new String()), this.strings = s) : this._$AH = v;
  }
  _$AI(t, e = this, s, n) {
    const a = this.strings;
    let r = !1;
    if (a === void 0) t = bt(this, t, e, 0), r = !Ot(t) || t !== this._$AH && t !== wt, r && (this._$AH = t);
    else {
      const u = t;
      let o, d;
      for (t = a[0], o = 0; o < a.length - 1; o++) d = bt(this, u[s + o], e, o), d === wt && (d = this._$AH[o]), r || (r = !Ot(d) || d !== this._$AH[o]), d === v ? t = v : t !== v && (t += (d ?? "") + a[o + 1]), this._$AH[o] = d;
    }
    r && !n && this.j(t);
  }
  j(t) {
    t === v ? this.element.removeAttribute(this.name) : this.element.setAttribute(this.name, t ?? "");
  }
}
class Yi extends de {
  constructor() {
    super(...arguments), this.type = 3;
  }
  j(t) {
    this.element[this.name] = t === v ? void 0 : t;
  }
}
class Ji extends de {
  constructor() {
    super(...arguments), this.type = 4;
  }
  j(t) {
    this.element.toggleAttribute(this.name, !!t && t !== v);
  }
}
class Qi extends de {
  constructor(t, e, s, n, a) {
    super(t, e, s, n, a), this.type = 5;
  }
  _$AI(t, e = this) {
    if ((t = bt(this, t, e, 0) ?? v) === wt) return;
    const s = this._$AH, n = t === v && s !== v || t.capture !== s.capture || t.once !== s.once || t.passive !== s.passive, a = t !== v && (s === v || n);
    n && this.element.removeEventListener(this.name, this, s), a && this.element.addEventListener(this.name, this, t), this._$AH = t;
  }
  handleEvent(t) {
    typeof this._$AH == "function" ? this._$AH.call(this.options?.host ?? this.element, t) : this._$AH.handleEvent(t);
  }
}
class tn {
  constructor(t, e, s) {
    this.element = t, this.type = 6, this._$AN = void 0, this._$AM = e, this.options = s;
  }
  get _$AU() {
    return this._$AM._$AU;
  }
  _$AI(t) {
    bt(this, t);
  }
}
const en = Pt.litHtmlPolyfillSupport;
en?.(zt, Ft), (Pt.litHtmlVersions ?? (Pt.litHtmlVersions = [])).push("3.3.3");
const sn = (i, t, e) => {
  const s = e?.renderBefore ?? t;
  let n = s._$litPart$;
  if (n === void 0) {
    const a = e?.renderBefore ?? null;
    s._$litPart$ = n = new Ft(t.insertBefore(Bt(), a), a, void 0, e ?? {});
  }
  return n._$AI(i), n;
};
const Tt = globalThis;
class Qt extends ft {
  constructor() {
    super(...arguments), this.renderOptions = { host: this }, this._$Do = void 0;
  }
  createRenderRoot() {
    var e;
    const t = super.createRenderRoot();
    return (e = this.renderOptions).renderBefore ?? (e.renderBefore = t.firstChild), t;
  }
  update(t) {
    const e = this.render();
    this.hasUpdated || (this.renderOptions.isConnected = this.isConnected), super.update(t), this._$Do = sn(e, this.renderRoot, this.renderOptions);
  }
  connectedCallback() {
    super.connectedCallback(), this._$Do?.setConnected(!0);
  }
  disconnectedCallback() {
    super.disconnectedCallback(), this._$Do?.setConnected(!1);
  }
  render() {
    return wt;
  }
}
Qt._$litElement$ = !0, Qt.finalized = !0, Tt.litElementHydrateSupport?.({ LitElement: Qt });
const nn = Tt.litElementPolyfillSupport;
nn?.({ LitElement: Qt });
(Tt.litElementVersions ?? (Tt.litElementVersions = [])).push("4.2.2");
const an = { value: "—", unit: "" };
function W(i) {
  return typeof i == "number" && Number.isFinite(i);
}
function f(i) {
  if (typeof i == "number") return Number.isFinite(i) ? i : null;
  if (typeof i == "string" && i.trim() !== "") {
    const t = Number(i);
    return Number.isFinite(t) ? t : null;
  }
  return null;
}
function P(i) {
  return typeof i == "boolean" ? i : i === 1 || i === "1" || i === "true" ? !0 : i === 0 || i === "0" || i === "false" ? !1 : null;
}
function G(i) {
  return i.replace(/\.0$/, "");
}
function Me(i, t, e) {
  let s = i, n = 0;
  for (; s >= t && n < e.length - 1; )
    s /= t, n++;
  const a = s >= 100 ? 0 : s >= 10 ? 1 : 2;
  return { value: G(s.toFixed(a)), unit: e[n] };
}
function z(i, t = !0) {
  if (!W(i) || i < 0) return an;
  if (i === 0) return { value: "0", unit: t ? "bps" : "B/s" };
  if (t) {
    const e = i * 8;
    return e < 1e3 ? { value: G(e.toFixed(e < 10 ? 1 : 0)), unit: "bps" } : Me(e, 1e3, ["bps", "Kbps", "Mbps", "Gbps", "Tbps"]);
  }
  return i < 1e3 ? { value: G(i.toFixed(i < 10 ? 1 : 0)), unit: "B/s" } : Me(i, 1e3, ["B/s", "KB/s", "MB/s", "GB/s", "TB/s"]);
}
function O(i) {
  if (!W(i) || i < 0) return "—";
  if (i < 1024) return `${G(i.toFixed(0))} B`;
  const t = Me(i, 1024, ["B", "KiB", "MiB", "GiB", "TiB", "PiB"]);
  return `${t.value} ${t.unit}`;
}
function I(i, t = 1) {
  return W(i) ? `${G(i.toFixed(t))}%` : "—";
}
function _(i, t = 0) {
  return W(i) ? G(i.toFixed(t)) : "—";
}
function it(i) {
  return W(i) ? `${G(i.toFixed(1))} °C` : "—";
}
function F(i) {
  return !W(i) || i <= 0 ? "—" : i >= 1e3 ? `${G((i / 1e3).toFixed(i % 1e3 === 0 ? 0 : 1))} Gbps` : `${G(i.toFixed(0))} Mbps`;
}
function D(i) {
  if (!W(i) || i < 0) return "—";
  const t = Math.floor(i), e = Math.floor(t / 86400), s = Math.floor(t % 86400 / 3600), n = Math.floor(t % 3600 / 60);
  return e > 0 ? `${e}天 ${s}小时` : s > 0 ? `${s}小时 ${n}分` : n > 0 ? `${n}分` : `${t}秒`;
}
function Z(i, t = Date.now()) {
  if (!W(i) || i <= 0) return "—";
  const e = Math.max(0, t - i);
  return e < 5e3 ? "刚刚" : e < 6e4 ? `${Math.floor(e / 1e3)} 秒前` : e < 36e5 ? `${Math.floor(e / 6e4)} 分钟前` : e < 864e5 ? `${Math.floor(e / 36e5)} 小时前` : new Date(i).toLocaleDateString();
}
function ti(i) {
  if (!W(i) || i <= 0) return "—";
  const t = new Date(i);
  return `${String(t.getHours()).padStart(2, "0")}:${String(t.getMinutes()).padStart(2, "0")}:${String(t.getSeconds()).padStart(2, "0")}`;
}
function B(i) {
  if (!W(i) || i <= 0) return "—";
  const t = new Date(i);
  return `${t.getFullYear()}-${String(t.getMonth() + 1).padStart(2, "0")}-${String(t.getDate()).padStart(2, "0")} ${ti(i)}`;
}
function Le(i) {
  if (!i) return "—";
  if (i.includes(":")) {
    const e = i.split(":");
    return `${e[0]}:${e[1] || ""}:••••`;
  }
  const t = i.split(".");
  return t.length === 4 ? `${t[0]}.${t[1]}.*.*` : "••••";
}
function ei(i, t, e) {
  return e ? `设备 ${t.slice(-5).replace(":", "")}` : i || t;
}
function rn(i, t, e) {
  return Math.min(e, Math.max(t, i));
}
const pt = (i) => encodeURIComponent(i || "default"), M = {
  legacySites: {
    key: "legacy.sites",
    surface: "legacy",
    label: "传统站点列表",
    path: "/proxy/network/api/self/sites"
  },
  legacyHealth: (i) => ({
    key: "legacy.health",
    surface: "legacy",
    label: "WAN/系统健康",
    path: `/proxy/network/api/s/${pt(i)}/stat/health`
  }),
  legacyDevices: (i) => ({
    key: "legacy.devices",
    surface: "legacy",
    label: "设备统计",
    path: `/proxy/network/api/s/${pt(i)}/stat/device`
  }),
  legacyClients: (i) => ({
    key: "legacy.clients",
    surface: "legacy",
    label: "在线客户端",
    path: `/proxy/network/api/s/${pt(i)}/stat/sta`
  }),
  legacySysinfo: (i) => ({
    key: "legacy.sysinfo",
    surface: "legacy",
    label: "控制器版本",
    path: `/proxy/network/api/s/${pt(i)}/stat/sysinfo`
  }),
  legacySpeedtest: (i) => ({
    key: "legacy.speedtest",
    surface: "legacy",
    label: "历史测速",
    path: `/proxy/network/v2/api/site/${pt(i)}/speedtest`
  }),
  /** Same aggregated dashboard request the UniFi Network console loads. */
  legacyAggregatedDashboard: (i) => ({
    key: "legacy.traffic",
    surface: "legacy",
    label: "历史流量/线路质量",
    path: `/proxy/network/v2/api/site/${pt(i)}/aggregated-dashboard`
  }),
  integrationInfo: {
    key: "integration.info",
    surface: "integration",
    label: "Integration 版本",
    path: "/proxy/network/integration/v1/info"
  },
  integrationSites: {
    key: "integration.sites",
    surface: "integration",
    label: "Integration 站点",
    path: "/proxy/network/integration/v1/sites"
  },
  integrationDevices: (i) => ({
    key: "integration.devices",
    surface: "integration",
    label: "Integration 设备",
    path: `/proxy/network/integration/v1/sites/${encodeURIComponent(i)}/devices`
  }),
  integrationDevice: (i, t) => ({
    key: "integration.device",
    surface: "integration",
    label: "设备接口详情",
    path: `/proxy/network/integration/v1/sites/${encodeURIComponent(i)}/devices/${encodeURIComponent(t)}`
  }),
  integrationDeviceStats: (i, t) => ({
    key: "integration.deviceStats",
    surface: "integration",
    label: "设备实时统计",
    path: `/proxy/network/integration/v1/sites/${encodeURIComponent(i)}/devices/${encodeURIComponent(t)}/statistics/latest`
  }),
  integrationClients: (i) => ({
    key: "integration.clients",
    surface: "integration",
    label: "Integration 客户端",
    path: `/proxy/network/integration/v1/sites/${encodeURIComponent(i)}/clients`
  }),
  integrationWans: (i) => ({
    key: "integration.wans",
    surface: "integration",
    label: "Integration WAN",
    path: `/proxy/network/integration/v1/sites/${encodeURIComponent(i)}/wans`
  })
}, on = 200;
function N(i) {
  return i ? Array.isArray(i) ? i : Array.isArray(i.data) ? i.data : [] : [];
}
function si(i) {
  const t = N(i);
  return t.length ? t[0] : null;
}
function w(i) {
  if (typeof i != "string") return null;
  const t = i.trim();
  return t && t !== "(none)" ? t : null;
}
function K(i) {
  return String(i ?? "").toLowerCase();
}
function ii(i, t) {
  const e = /* @__PURE__ */ new Map();
  for (const s of i) {
    const n = t(s);
    n && e.set(n, s);
  }
  return e;
}
function ie(i, t) {
  if (typeof t == "number" && Number.isFinite(t)) {
    if (t >= 5.9) return "6";
    if (t >= 4.9) return "5";
    if (t >= 2) return "2.4";
  }
  const e = String(i ?? "").toLowerCase();
  return e === "ng" || e === "2.4" || e === "2g" ? "2.4" : e === "na" || e === "5" || e === "5g" ? "5" : e === "6e" || e === "6" || e === "6g" ? "6" : "unknown";
}
function ks(i) {
  return i ? i.is_11be ? "802.11be" : i.is_11ax ? "802.11ax" : i.is_11ac ? "802.11ac" : i.is_11n ? "802.11n" : null : null;
}
function ln(i) {
  if (!Array.isArray(i)) return [];
  const t = [];
  for (const e of i) {
    const s = f(e?.value);
    s !== null && t.push({
      name: String(e?.name ?? "温度"),
      type: String(e?.type ?? "unknown"),
      celsius: s
    });
  }
  return t;
}
function dn(i) {
  return Array.isArray(i) ? i.filter((t) => t && (t.name || t.mount_point)).map((t) => ({
    name: String(t.name ?? t.mount_point ?? "存储"),
    type: String(t.type ?? "unknown"),
    mountPoint: String(t.mount_point ?? ""),
    usedBytes: f(t.used),
    totalBytes: f(t.size)
  })) : [];
}
function cn(i) {
  const t = i?.uplink ?? i?.last_uplink ?? i?.parent_device ?? null;
  if (t) {
    const e = w(t.uplink_mac) ?? w(t.mac) ?? null;
    return {
      parentMac: K(e) || null,
      parentName: w(t.uplink_device_name) ?? w(t.name) ?? null,
      parentPort: f(t.uplink_remote_port) ?? f(t.port) ?? null,
      parentSpeedMbps: f(t.uplink_speed) ?? f(t.speed) ?? f(t.port_speed) ?? null,
      parentDeviceId: w(t.deviceId) ?? null
    };
  }
  return { parentMac: null, parentName: null, parentPort: null, parentSpeedMbps: null, parentDeviceId: null };
}
function Fe(i) {
  const t = i?.state;
  if (typeof t == "number") return t === 1;
  if (typeof t == "string") {
    const e = t.toUpperCase();
    if (e === "ONLINE" || e === "CONNECTED" || e === "UP") return !0;
    if (e === "OFFLINE" || e === "DISCONNECTED" || e === "DOWN") return !1;
  }
  return typeof i?.online == "boolean" ? i.online : typeof i?.adopted == "boolean" && i.adopted === !1 ? !1 : null;
}
function pn(i) {
  const t = i?.["system-stats"] ?? {}, e = i?.sys_stats ?? {};
  return {
    cpu: f(t.cpu),
    mem: f(t.mem),
    load1: f(e.loadavg_1) ?? f(i?.loadAverage1Min),
    load5: f(e.loadavg_5) ?? f(i?.loadAverage5Min),
    load15: f(e.loadavg_15) ?? f(i?.loadAverage15Min)
  };
}
function ce(i, t) {
  const e = K(w(i?.mac) ?? w(i?.macAddress)), s = pn(i), n = Fe(i);
  return {
    id: String(i?._id ?? i?.id ?? e ?? "unknown"),
    mac: e,
    name: w(i?.name) ?? w(i?.hostname) ?? (e || "未知设备"),
    model: w(i?.model) ?? w(i?.shortname) ?? "未知型号",
    ip: w(i?.ip) ?? w(i?.ipAddress),
    online: n,
    uptimeSec: f(i?.uptime) ?? f(i?.uptimeSec),
    firmware: w(i?.displayable_version) ?? w(i?.version) ?? w(i?.firmwareVersion),
    firmwareUpdatable: P(i?.upgradable) ?? P(i?.firmwareUpdatable),
    cpuPct: s.cpu,
    memPct: s.mem,
    load1: s.load1,
    load5: s.load5,
    load15: s.load15,
    temperatures: ln(i?.temperatures),
    source: t,
    uplink: cn(i),
    state: n === !1 ? "error" : n === !0 ? "ok" : "no-data"
  };
}
function un(i) {
  const t = i?.port_poe === !0, e = i?.poe, s = P(e?.enabled) ?? P(i?.poe_enable) ?? (t ? !1 : null), n = w(e?.state) ?? null;
  return !t && !e ? null : {
    enabled: s === !0,
    powerW: f(e?.powerW) ?? f(i?.poe_power),
    voltageV: f(i?.poe_voltage),
    currentA: f(i?.poe_current) !== null ? f(i?.poe_current) / 1e3 : null,
    poeClass: w(i?.poe_class) ?? w(e?.standard) ?? null,
    state: n
  };
}
function hn(i, t) {
  const e = f(i?.speed) ?? f(i?.speedMbps);
  return t && e !== null && e > 0 ? e : null;
}
function je(i) {
  if (!Array.isArray(i)) return [];
  const t = [];
  for (const e of i) {
    if (!e || typeof e != "object") continue;
    const s = f(e.port_idx) ?? f(e.idx);
    if (s === null) continue;
    const n = P(e.up) ?? String(e.state ?? "").toUpperCase() === "UP", a = un(e);
    t.push({
      idx: s,
      name: w(e.name) ?? `Port ${s}`,
      up: n,
      speedMbps: hn(e, n),
      maxSpeedMbps: f(e.max_speed) ?? f(e.maxSpeedMbps),
      media: w(e.media) ?? w(e.connector),
      connector: w(e.connector) ?? w(e.media),
      isUplink: P(e.is_uplink) ?? !1,
      poe: a,
      rxBps: f(e["rx_bytes-r"]),
      txBps: f(e["tx_bytes-r"]),
      rxErrors: f(e.rx_errors),
      txErrors: f(e.tx_errors),
      rxDropped: f(e.rx_dropped),
      txDropped: f(e.tx_dropped),
      stpState: w(e.stp_state),
      stpRole: w(e.stp_role),
      linkDownCount: f(e.link_down_count),
      macTableCount: f(e.mac_table_count),
      satisfaction: f(e.satisfaction),
      fullDuplex: P(e.full_duplex),
      autoneg: P(e.autoneg),
      sfpFound: P(e.sfp_found)
    });
  }
  return t.sort((e, s) => e.idx - s.idx);
}
function fn(i) {
  const t = Array.isArray(i?.radio_table) ? i.radio_table : [], e = Array.isArray(i?.radio_table_stats) ? i.radio_table_stats : [], s = ii(t, (r) => w(r.name)), n = /* @__PURE__ */ new Map();
  for (const r of e) {
    const u = w(r.name) ?? w(r.radio) ?? "", o = s.get(u), d = ie(w(r.radio) ?? w(o?.radio));
    n.set(d + ":" + u, {
      band: d,
      channel: f(r.channel) ?? f(r.last_channel) ?? f(o?.channel),
      widthMhz: f(r.bw) ?? f(r.last_bw) ?? f(o?.ht),
      utilizationPct: f(r.cu_total),
      txRetriesPct: f(r.tx_retries_pct),
      clients: f(r.num_sta),
      txPower: f(r.tx_power) ?? f(r.last_tx_power),
      standard: ks(o),
      satisfaction: f(r.satisfaction),
      state: w(r.state),
      txPackets: f(r.tx_packets),
      txRetries: f(r.tx_retries),
      userClients: f(r["user-num_sta"]),
      guestClients: f(r["guest-num_sta"])
    });
  }
  for (const r of t) {
    const u = ie(w(r.radio)), o = u + ":" + String(r.name ?? "");
    n.has(o) || n.set(o, {
      band: u,
      channel: f(r.channel),
      widthMhz: f(r.ht),
      utilizationPct: null,
      txRetriesPct: null,
      clients: null,
      txPower: f(r.tx_power),
      standard: ks(r),
      satisfaction: null,
      state: null,
      txPackets: null,
      txRetries: null,
      userClients: null,
      guestClients: null
    });
  }
  const a = { "2.4": 0, 5: 1, 6: 2, unknown: 3 };
  return [...n.values()].sort((r, u) => a[r.band] - a[u.band]);
}
function ni() {
  return {
    status: null,
    wanStatus: null,
    wanIp: null,
    wwwStatus: null,
    vpnStatus: null,
    numAp: null,
    numSw: null,
    numWan: null
  };
}
function gn(i) {
  const t = N(i);
  if (!t.length) return ni();
  const e = ii(t, (c) => w(c.subsystem)), s = e.get("wlan"), n = e.get("wan"), a = e.get("www"), r = e.get("vpn"), u = e.get("lan"), o = t.map((c) => String(c.status ?? "")).filter(Boolean);
  let d = null;
  return o.length && (o.some((c) => /error|down|fail/i.test(c)) ? d = "error" : o.every((c) => /ok|good/i.test(c)) ? d = "ok" : d = "degraded"), {
    status: d,
    wanStatus: w(n?.status),
    wanIp: w(n?.wan_ip),
    wwwStatus: w(a?.status),
    vpnStatus: w(r?.status),
    numAp: f(s?.num_ap),
    numSw: f(u?.num_sw),
    numWan: f(n?.num_gw)
  };
}
function mn(i, t, e) {
  const s = i?.active_geo_info?.[t] ?? i?.last_geo_info?.[t] ?? null, n = w(s?.isp_name) ?? (t === "WAN" ? w(e?.isp_name) : null), a = f(s?.asn) ?? (t === "WAN" ? f(e?.asn) : null);
  return {
    name: n,
    key: a !== null ? String(a) : n,
    asn: a
  };
}
function vn(i, t, e, s, n, a) {
  if (!i) return [];
  const r = N(e).find((b) => String(b.subsystem) === "wan") ?? null, u = i?.uptime_stats ?? r?.uptime_stats ?? {}, o = i?.last_wan_status ?? {}, d = i?.last_wan_interfaces ?? {}, c = Object.keys(i).map((b) => ({ k: b, m: /^wan(\d+)$/.exec(b) })).filter((b) => b.m && i[b.k] && typeof i[b.k] == "object").map((b) => ({ key: b.k, slot: Number(b.m[1]) })).sort((b, k) => b.slot - k.slot), p = [], g = /* @__PURE__ */ new Set();
  for (const { key: b, slot: k } of c) {
    const $ = i[b], T = k === 1 ? "WAN" : `WAN${k}`, A = u?.[T] ?? {}, H = mn(i, T, r), Q = w($.uplink_ifname) ?? w($.ifname) ?? w($.name) ?? b, q = g.has(Q) ? `${Q}#${k}` : Q;
    g.add(q);
    const ct = w($.ip) ?? w(d?.[T]?.ip), di = f((i?.last_downtime_stats ?? {})[T]), Je = Array.isArray($.ipv6) ? $.ipv6.filter((ts) => typeof ts == "string" && ts) : [], ci = f($["rx_bytes-r"]), pi = f($["tx_bytes-r"]), jt = n.observe(q, a, ci, pi, f($.rx_bytes), f($.tx_bytes)), Qe = P($.up), he = w(o?.[T]);
    let L = null;
    Qe === !1 ? L = !1 : Qe === !0 || he === "online" ? L = !0 : he === "offline" ? L = !1 : d?.[T]?.alive === !0 ? L = !0 : d?.[T]?.alive === !1 && (L = !1);
    const ui = H.name, hi = L === !1 ? "error" : jt.rxBps !== null || jt.txBps !== null || ct ? "ok" : "no-data";
    p.push({
      id: q,
      slot: k,
      name: b.toUpperCase(),
      networkGroup: T,
      operator: ui,
      operatorKey: H.key,
      asn: H.asn,
      online: L,
      ipv4: ct,
      ipv6: Je.length ? Je : null,
      rxBps: jt.rxBps,
      txBps: jt.txBps,
      latencyMs: f($.latency) ?? f(A.latency_average),
      lossPct: f($.loss) ?? f($.packet_loss) ?? f(A.loss),
      availabilityPct: f($.availability) ?? f(A.availability),
      linkSpeedMbps: f($.speed),
      media: w($.media),
      portName: w($.name),
      uptimeSec: f(A.uptime),
      downtimeCount: di,
      anomalies: f($.anomalies),
      rxErrors: f($.rx_errors),
      txErrors: f($.tx_errors),
      rxDropped: f($.rx_dropped),
      txDropped: f($.tx_dropped),
      todayRxBytes: null,
      todayTxBytes: null,
      todayTotalBytes: null,
      monthRxBytes: null,
      monthTxBytes: null,
      monthTotalBytes: null,
      lossAvgPct: null,
      lossPeakPct: null,
      qualityHistory: [],
      role: "unknown",
      active: null,
      source: "legacy",
      state: hi,
      detail: L === !1 ? `last_wan_status=${he ?? "unknown"}` : void 0
    });
  }
  const m = t.wanIp;
  if (m)
    for (const b of p) b.active = b.ipv4 ? b.ipv4 === m : !1;
  const h = s.primaryWanId && p.some((b) => b.id === s.primaryWanId) ? s.primaryWanId : p[0]?.id ?? null;
  for (const b of p) b.role = b.id === h ? "primary" : h ? "backup" : "unknown";
  return p;
}
function wn(i, t, e) {
  const s = ce(i, "legacy");
  s.ip = w(i?.lan_ip) ?? s.ip;
  const n = je(i?.port_table), a = n.some((r) => r.poe !== null);
  return {
    ...s,
    networkVersion: w(t?.version),
    osVersion: w(t?.console_display_version) ?? w(i?.version) ?? w(i?.displayable_version),
    storage: dn(i?.storage),
    ports: n,
    poeUsedW: a ? f(i?.total_used_power) : null,
    poeBudgetW: a ? f(i?.total_max_power) : null,
    overheating: P(i?.overheating),
    updateAvailable: P(t?.update_available) ?? P(i?.upgradable),
    vpnStatus: e.vpnStatus,
    activeWanId: null
  };
}
function bn(i) {
  const t = ce(i, "legacy"), e = je(i?.port_table), s = e.some((n) => n.poe !== null);
  return {
    ...t,
    ports: e,
    poeUsedW: s ? f(i?.total_used_power) : null,
    poeBudgetW: s ? f(i?.total_max_power) : null,
    portCount: f(i?.num_ports) ?? (e.length || null),
    generalTemperature: f(i?.general_temperature),
    satisfaction: f(i?.satisfaction),
    fanLevel: f(i?.fan_level),
    overheating: P(i?.overheating),
    clientCount: f(i?.num_sta)
  };
}
function xn(i) {
  const t = ce(i, "legacy"), e = fn(i);
  return {
    ...t,
    radios: e,
    clientCount: f(i?.num_sta) ?? (e.some((s) => s.clients !== null) ? e.reduce((s, n) => s + (n.clients ?? 0), 0) : null),
    wiredClientCount: (() => {
      const s = f(i?.num_sta), n = f(i?.["user-wlan-num-sta"]), a = f(i?.["guest-wlan-num-sta"]);
      return s === null || n === null || a === null ? null : Math.max(0, s - n - a);
    })(),
    satisfaction: f(i?.satisfaction),
    userClients: f(i?.["user-num-sta"]),
    guestClients: f(i?.["guest-num-sta"])
  };
}
function yn(i) {
  const t = P(i?.is_wired) === !0, e = K(w(i?.mac)), s = w(i?.name), n = w(i?.hostname), a = w(i?.radio), r = f(i?.channelWidth) ?? f(i?.channel_width), u = f(i?.tx_rate), o = f(i?.signal);
  return {
    id: String(i?._id ?? i?.user_id ?? e),
    mac: e,
    name: s ?? n,
    hostname: n,
    ip: w(i?.ip) ?? w(i?.last_ip),
    ipv6: Array.isArray(i?.ipv6_addresses) ? i.ipv6_addresses.filter((d) => typeof d == "string") : [],
    wired: t,
    uplinkName: w(i?.last_uplink_name),
    uplinkMac: K(w(i?.last_uplink_mac) ?? w(i?.ap_mac) ?? w(i?.sw_mac) ?? "") || null,
    uplinkPort: f(i?.last_uplink_remote_port) ?? f(i?.sw_port),
    rxBps: f(t ? i?.["wired-rx_bytes-r"] : i?.["rx_bytes-r"]),
    txBps: f(t ? i?.["wired-tx_bytes-r"] : i?.["tx_bytes-r"]),
    linkSpeedMbps: t ? f(i?.wired_rate_mbps) : u !== null ? u / 1e3 : null,
    signalDbm: t ? null : o,
    noiseDbm: t ? null : f(i?.noise),
    band: t ? "unknown" : ie(a),
    channel: t ? null : f(i?.channel),
    widthMhz: t ? null : r,
    essid: w(i?.essid),
    uptimeSec: f(i?.uptime),
    satisfaction: f(i?.satisfaction),
    manufacturer: w(i?.oui),
    network: w(i?.network),
    vlan: f(i?.vlan),
    firstSeen: f(i?.first_seen),
    lastSeen: f(i?.last_seen) ?? f(i?.last_seen_by_usw) ?? null,
    txRetries: f(i?.tx_retries),
    wifiRetryPct: f(i?.wifi_tx_retries_percentage),
    source: "legacy"
  };
}
function $n(i) {
  const t = N(i), e = [];
  for (const s of t) {
    const n = f(s.time);
    n === null || n <= 0 || e.push({
      id: String(s.id ?? `${s.interface_name}-${n}`),
      interfaceName: String(s.interface_name ?? ""),
      wanNetworkGroup: w(s.wan_networkgroup),
      downloadMbps: f(s.download_mbps),
      uploadMbps: f(s.upload_mbps),
      latencyMs: f(s.latency_ms),
      time: n
    });
  }
  return e.sort((s, n) => n.time - s.time), e.slice(0, 200);
}
function Ke(i, t) {
  const e = i.switches, s = i.aps;
  return {
    gateway: i.gateway ? 1 : 0,
    switch: e.length,
    ap: s.length,
    gatewayOnline: i.gateway && i.gateway.online === !0 ? 1 : 0,
    switchOnline: e.filter((n) => n.online === !0).length,
    apOnline: s.filter((n) => n.online === !0).length,
    clientsTotal: t ? t.length : null,
    clientsWired: t ? t.filter((n) => n.wired).length : null,
    clientsWireless: t ? t.filter((n) => !n.wired).length : null
  };
}
function S(i, t, e, s) {
  return {
    supported: i,
    ...t ? { reason: t } : {},
    ...e ? { source: e } : {},
    status: s ?? (i ? "ok" : "no-data")
  };
}
function Ge(i, t, e) {
  const s = i.wans, n = i.clients, a = [...i.gateway?.ports ?? [], ...i.switches.flatMap((o) => o.ports)], r = [...i.gateway?.temperatures ?? [], ...i.switches.flatMap((o) => o.temperatures), ...i.aps.flatMap((o) => o.temperatures)], u = i.aps.flatMap((o) => o.radios);
  return {
    legacy: S(t, t ? void 0 : "传统只读统计接口不可用", "legacy"),
    integration: S(e, e ? void 0 : "官方 Integration API 不可用或未启用", "integration"),
    wanRates: S(s.some((o) => o.rxBps !== null || o.txBps !== null), "控制器未返回 WAN 速率"),
    wanLatency: S(s.some((o) => o.latencyMs !== null), "控制器未返回 WAN 延迟"),
    wanLoss: S(
      s.some((o) => o.lossPct !== null),
      s.some((o) => o.lossPct !== null) ? "控制器 aggregated-dashboard 5 分钟平均丢包" : "聚合接口尚未返回丢包序列",
      void 0,
      s.some((o) => o.lossPct !== null) ? "ok" : "unverified"
    ),
    wanAvailability: S(s.some((o) => o.availabilityPct !== null), "控制器未返回可用率字段"),
    wanIpv6: S(
      s.some((o) => (o.ipv6?.length ?? 0) > 0),
      "WAN 未下发 IPv6 地址",
      void 0,
      s.some((o) => (o.ipv6?.length ?? 0) > 0) ? "ok" : "no-data"
    ),
    linkSpeed: S(s.some((o) => o.linkSpeedMbps !== null), "控制器未返回网口协商速率"),
    poePower: S(a.some((o) => o.poe?.powerW !== null && o.poe?.powerW !== void 0) || i.switches.some((o) => o.poeUsedW !== null), "控制器未返回 PoE 功耗"),
    temperatures: S(r.length > 0, "当前设备未提供温度传感器", void 0, r.length > 0 ? "ok" : "no-data"),
    switchTemperature: S(
      i.switches.some((o) => o.generalTemperature !== null || o.temperatures.length > 0),
      "当前控制器/交换机未返回 general_temperature 或 temperatures",
      void 0,
      i.switches.some((o) => o.generalTemperature !== null || o.temperatures.length > 0) ? "ok" : "no-data"
    ),
    apSatisfaction: S(
      i.aps.some((o) => o.satisfaction !== null || o.radios.some((d) => d.satisfaction !== null && d.satisfaction >= 0)),
      "AP 顶层与 radio 均未返回有效满意度",
      void 0,
      i.aps.some((o) => o.satisfaction !== null || o.radios.some((d) => d.satisfaction !== null && d.satisfaction >= 0)) ? "ok" : "no-data"
    ),
    radios: S(u.length > 0, "未发现无线射频"),
    radioUtilization: S(u.some((o) => o.utilizationPct !== null), "控制器未返回信道利用率"),
    clientTraffic: S(n.some((o) => o.rxBps !== null || o.txBps !== null), "控制器未返回客户端速率"),
    clientSignal: S(n.some((o) => o.signalDbm !== null), "控制器未返回客户端信号"),
    topology: S(
      [...i.switches, ...i.aps].some((o) => o.uplink.parentMac || o.uplink.parentDeviceId) || i.clients.some((o) => o.uplinkMac),
      "控制器未提供可靠上联关系"
    ),
    speedtest: S(i.speedtests.length > 0, "控制器没有历史测速记录"),
    storage: S((i.gateway?.storage.length ?? 0) > 0, "控制器未返回存储信息"),
    vpn: S(
      i.health.vpnStatus !== null && i.health.vpnStatus !== "unknown",
      "当前 REST /stat/vpn 返回 404，health.vpn.status=unknown；官方 Integration 客户端接口可能含 VPN 连接，但本环境无 VPN 可验证，未伪造在线数",
      void 0,
      "unsupported"
    ),
    sfpOptical: S(
      !1,
      "当前控制器 port_table 仅返回 sfp_found（开关 SFP+ 端口为 false）；无光功率/温度/电压/厂商诊断字段；UCG SFP+ 端口无 sfp_found。未安装光模块，无法验证 DDM",
      void 0,
      "unsupported"
    ),
    wanTraffic: S(
      !1,
      "聚合接口尚未返回 WAN 流量",
      void 0,
      "unverified"
    ),
    wanTrafficToday: S(!1, "聚合接口尚未返回今日 WAN 流量", void 0, "unverified"),
    wanTrafficMonth: S(!1, "聚合接口尚未返回本月 WAN 流量", void 0, "unverified"),
    wanQualityHistory: S(!1, "聚合接口尚未返回线路质量序列", void 0, "unverified"),
    wanFailoverHistory: S(!1, "聚合接口尚未返回 failover 历史", void 0, "unverified")
  };
}
function ai(i = Date.now()) {
  return {
    fetchedAt: i,
    legacyFetchedAt: null,
    integrationFetchedAt: null,
    site: null,
    gateway: null,
    switches: [],
    aps: [],
    wans: [],
    clients: [],
    counts: {
      gateway: null,
      switch: null,
      ap: null,
      gatewayOnline: null,
      switchOnline: null,
      apOnline: null,
      clientsTotal: null,
      clientsWired: null,
      clientsWireless: null
    },
    health: ni(),
    speedtests: [],
    failoverHistory: [],
    trafficFetchedAt: null,
    capabilities: {},
    warnings: [],
    partial: !0
  };
}
function kn(i, t, e, s = Date.now()) {
  const n = ai(s), a = N(i.devices), r = Array.isArray(i.clients?.data) || Array.isArray(i.clients), u = r ? N(i.clients) : null, o = gn(i.health), d = si(i.sysinfo);
  a.length || n.warnings.push("未取得设备统计（stat/device）"), N(i.health).length || n.warnings.push("未取得健康状态（stat/health）"), n.health = o, n.site = { id: t.site, name: t.site, internalReference: t.site };
  const c = a.find((m) => ["udm", "ugw", "usg"].includes(String(m.type))) ?? null, p = a.filter((m) => String(m.type) === "usw"), g = a.filter((m) => String(m.type) === "uap");
  if (n.gateway = c ? wn(c, d, o) : null, n.switches = p.map(bn), n.aps = g.map(xn), n.wans = vn(c, o, i.health, t, e, s), n.gateway) {
    const m = n.wans.find((h) => h.active === !0) ?? null;
    n.gateway.activeWanId = m?.id ?? null;
  }
  return n.wans.length || n.warnings.push("未发现 WAN 接口字段"), n.clients = u ? u.map(yn) : [], n.speedtests = $n(i.speedtest), n.counts = Ke(n, u ? n.clients : null), n.legacyFetchedAt = s, n.partial = !a.length || !n.wans.length, n.capabilities = Ge(n, !0, !1), r || n.warnings.push("未取得在线客户端（stat/sta）"), n;
}
function Se(i) {
  const t = Array.isArray(i?.features) ? i.features.map((s) => String(s)) : [], e = String(i?.name ?? i?.model ?? "").toLowerCase();
  return /ucg|udm|usg|gateway|dream machine|cloud gateway/.test(e) ? "gateway" : t.includes("accessPoint") ? "ap" : (t.includes("switching"), "switch");
}
function ne(i) {
  const t = i?.interfaces?.ports;
  return Array.isArray(t) ? je(t.map((e) => ({
    ...e,
    port_idx: e.idx,
    up: String(e.state ?? "").toUpperCase() === "UP",
    speed: e.speedMbps,
    port_poe: !!e.poe,
    poe_enable: e.poe?.enabled,
    poe_power: e.poe?.powerW
  }))) : [];
}
function Ce(i) {
  const t = i?.interfaces?.radios;
  return Array.isArray(t) ? t.map((e) => ({
    band: ie(null, f(e.frequencyGHz)),
    channel: f(e.channel),
    widthMhz: f(e.channelWidthMHz),
    utilizationPct: null,
    txRetriesPct: null,
    clients: null,
    txPower: null,
    standard: w(e.wlanStandard),
    satisfaction: null,
    state: null,
    txPackets: null,
    txRetries: null,
    userClients: null,
    guestClients: null
  })).sort((e, s) => ({ "2.4": 0, 5: 1, 6: 2, unknown: 3 })[e.band] - { "2.4": 0, 5: 1, 6: 2, unknown: 3 }[s.band]) : [];
}
function An(i, t, e) {
  t && (i.cpuPct === null && (i.cpuPct = f(t.cpuUtilizationPct)), i.memPct === null && (i.memPct = f(t.memoryUtilizationPct)), i.load1 === null && (i.load1 = f(t.loadAverage1Min)), i.load5 === null && (i.load5 = f(t.loadAverage5Min)), i.load15 === null && (i.load15 = f(t.loadAverage15Min)), i.uptimeSec === null && (i.uptimeSec = f(t.uptimeSec))), e?.uplink?.deviceId && !i.uplink.parentDeviceId && (i.uplink.parentDeviceId = w(e.uplink.deviceId));
}
function _n(i, t) {
  const e = /* @__PURE__ */ new Map();
  for (const s of i) e.set(s.idx, s);
  for (const s of t) {
    const n = e.get(s.idx);
    if (!n) {
      e.set(s.idx, s);
      continue;
    }
    n.speedMbps === null && (n.speedMbps = s.speedMbps), n.maxSpeedMbps === null && (n.maxSpeedMbps = s.maxSpeedMbps), n.media === null && (n.media = s.media), n.connector === null && (n.connector = s.connector), n.poe === null ? n.poe = s.poe : s.poe && n.poe.powerW === null && (n.poe.powerW = s.poe.powerW);
  }
  return [...e.values()].sort((s, n) => s.idx - n.idx);
}
function Mn(i, t) {
  const e = /* @__PURE__ */ new Map();
  for (const n of i) e.set(n.band, n);
  for (const n of t) {
    const a = e.get(n.band);
    if (!a) {
      e.set(n.band, n);
      continue;
    }
    a.channel === null && (a.channel = n.channel), a.widthMhz === null && (a.widthMhz = n.widthMhz), a.standard === null && (a.standard = n.standard);
  }
  const s = { "2.4": 0, 5: 1, 6: 2, unknown: 3 };
  return [...e.values()].sort((n, a) => s[n.band] - s[a.band]);
}
function ri(i, t, e, s) {
  const n = {
    ...i,
    _id: i.id,
    name: i.name,
    model: i.model,
    ip: i.ipAddress,
    state: i.state,
    version: i.firmwareVersion,
    upgradable: i.firmwareUpdatable,
    uptime: t?.uptimeSec,
    "system-stats": {
      cpu: t?.cpuUtilizationPct,
      mem: t?.memoryUtilizationPct
    },
    sys_stats: {
      loadavg_1: t?.loadAverage1Min,
      loadavg_5: t?.loadAverage5Min,
      loadavg_15: t?.loadAverage15Min
    },
    uplink: e?.uplink
  }, a = ce(n, "integration");
  return a.id = String(i.id ?? a.id), a.firmware = w(i.firmwareVersion), a.firmwareUpdatable = P(i.firmwareUpdatable), a.online = Fe(i), a.state = a.online === !1 ? "error" : a.online === !0 ? "ok" : "no-data", a;
}
function Sn(i, t, e, s = Date.now()) {
  if (!t || !t.devices && !t.clients && !t.sites && !t.wans) return i;
  const n = N(t.devices), a = t.details ?? {}, r = t.stats ?? {}, u = N(t.sites), o = u.find((h) => String(h.internalReference) === e.site) ?? u[0] ?? null;
  o && (i.site = {
    id: String(o.id),
    name: w(o.name) ?? e.site,
    internalReference: w(o.internalReference) ?? e.site
  });
  const d = /* @__PURE__ */ new Map();
  i.gateway && d.set(i.gateway.mac, i.gateway);
  for (const h of i.switches) d.set(h.mac, h);
  for (const h of i.aps) d.set(h.mac, h);
  for (const h of n) {
    const b = K(w(h.macAddress)), k = Se(h), $ = a[String(h.id)], T = r[String(h.id)], A = d.get(b);
    if (A) {
      A.online === null && (A.online = Fe(h), A.state = A.online === !1 ? "error" : A.online === !0 ? "ok" : "no-data"), A.firmware === null && (A.firmware = w(h.firmwareVersion)), A.firmwareUpdatable === null && (A.firmwareUpdatable = P(h.firmwareUpdatable));
      const q = w(h.model);
      if (q && (/^[A-Z0-9.]+$/.test(A.model) || A.model.length <= 8) && (A.model = q), An(A, T, $), A instanceof Object && "ports" in A) {
        const ct = ne($);
        A.ports = _n(A.ports, ct);
      }
      if ("radios" in A) {
        const ct = Ce($);
        A.radios = Mn(A.radios, ct);
      }
      !A.uplink.parentDeviceId && $?.uplink?.deviceId && (A.uplink.parentDeviceId = w($.uplink.deviceId));
      continue;
    }
    const H = ri(h, T, $), Q = ne($);
    if (k === "gateway") {
      const q = {
        ...H,
        networkVersion: null,
        osVersion: H.firmware,
        storage: [],
        ports: Q,
        poeUsedW: null,
        poeBudgetW: null,
        overheating: null,
        updateAvailable: H.firmwareUpdatable,
        vpnStatus: null,
        activeWanId: null
      };
      i.gateway || (i.gateway = q);
    } else k === "ap" ? i.aps.push({
      ...H,
      radios: Ce($),
      clientCount: null,
      wiredClientCount: null,
      satisfaction: null,
      userClients: null,
      guestClients: null
    }) : i.switches.push({
      ...H,
      ports: Q,
      poeUsedW: null,
      poeBudgetW: null,
      portCount: Q.length || null,
      generalTemperature: null,
      satisfaction: null,
      fanLevel: null,
      overheating: null,
      clientCount: null
    });
  }
  const c = /* @__PURE__ */ new Map();
  for (const h of n) c.set(String(h.id), K(w(h.macAddress)));
  const p = [i.gateway, ...i.switches, ...i.aps].filter(Boolean);
  for (const h of p)
    h.uplink.parentDeviceId && !h.uplink.parentMac && (h.uplink.parentMac = c.get(h.uplink.parentDeviceId) ?? null);
  const g = new Map(i.clients.map((h) => [h.mac, h])), m = N(t.clients);
  for (const h of m) {
    const b = K(w(h.macAddress)), k = g.get(b);
    if (k) {
      k.name || (k.name = w(h.name)), k.ip || (k.ip = w(h.ipAddress)), !k.uplinkMac && h.uplinkDeviceId && (k.uplinkMac = c.get(String(h.uplinkDeviceId)) ?? null);
      continue;
    }
    const $ = w(h.connectedAt), T = $ ? Date.parse($) : NaN;
    i.clients.push({
      id: String(h.id ?? b),
      mac: b,
      name: w(h.name),
      hostname: null,
      ip: w(h.ipAddress),
      ipv6: [],
      wired: String(h.type ?? "").toUpperCase() === "WIRED",
      uplinkName: null,
      uplinkMac: h.uplinkDeviceId ? c.get(String(h.uplinkDeviceId)) ?? null : null,
      uplinkPort: null,
      rxBps: null,
      txBps: null,
      linkSpeedMbps: null,
      signalDbm: null,
      noiseDbm: null,
      band: "unknown",
      channel: null,
      widthMhz: null,
      essid: null,
      uptimeSec: Number.isFinite(T) ? Math.max(0, (s - T) / 1e3) : null,
      satisfaction: null,
      manufacturer: null,
      network: null,
      vlan: null,
      firstSeen: null,
      lastSeen: null,
      txRetries: null,
      wifiRetryPct: null,
      source: "integration"
    });
  }
  if (!i.wans.length) {
    const h = N(t.wans);
    i.wans = h.map((b, k) => ({
      id: String(b.id ?? b.name ?? `wan-${k + 1}`),
      slot: k + 1,
      name: w(b.name) ?? `WAN${k + 1}`,
      networkGroup: null,
      operator: null,
      operatorKey: null,
      asn: null,
      online: null,
      ipv4: null,
      ipv6: null,
      rxBps: null,
      txBps: null,
      latencyMs: null,
      lossPct: null,
      availabilityPct: null,
      linkSpeedMbps: null,
      media: null,
      portName: null,
      uptimeSec: null,
      downtimeCount: null,
      anomalies: null,
      rxErrors: null,
      txErrors: null,
      rxDropped: null,
      txDropped: null,
      todayRxBytes: null,
      todayTxBytes: null,
      todayTotalBytes: null,
      monthRxBytes: null,
      monthTxBytes: null,
      monthTotalBytes: null,
      lossAvgPct: null,
      lossPeakPct: null,
      qualityHistory: [],
      role: k === 0 ? "primary" : "backup",
      active: null,
      source: "integration",
      state: "unsupported",
      detail: "Integration API 只返回 WAN 名称"
    }));
  }
  return i.clients.sort((h, b) => Number(b.wired) - Number(h.wired) || (h.name ?? h.mac).localeCompare(b.name ?? b.mac)), i.counts = Ke(i, i.clients), i.integrationFetchedAt = s, i.legacyFetchedAt || (i.fetchedAt = s), i.partial = !i.legacyFetchedAt || !n.length, i.capabilities = Ge(i, !!i.legacyFetchedAt, !0), t.info?.applicationVersion && (i.capabilities.integration.reason = `Integration API ${t.info.applicationVersion}`), i.warnings = i.warnings.filter((h) => !h.includes("Integration")), i;
}
function Cn(i, t, e = Date.now()) {
  const s = ai(e);
  s.site = { id: t.site, name: t.site, internalReference: t.site };
  const n = N(i.devices), a = i.details ?? {}, r = i.stats ?? {}, u = n.filter((p) => !p.uplink);
  let o = null;
  u.length === 1 ? o = u[0] : o = n.find((p) => Se(p) === "gateway") ?? null;
  for (const p of n) {
    const g = o && String(p.id) === String(o.id) ? "gateway" : Se(p), m = K(w(p.macAddress));
    if (m && s.gateway?.mac === m || s.switches.some((b) => b.mac === m) || s.aps.some((b) => b.mac === m)) continue;
    const h = ri(p, r[String(p.id)], a[String(p.id)]);
    g === "gateway" ? s.gateway = {
      ...h,
      networkVersion: null,
      osVersion: h.firmware,
      storage: [],
      ports: ne(a[String(p.id)]),
      poeUsedW: null,
      poeBudgetW: null,
      overheating: null,
      updateAvailable: h.firmwareUpdatable,
      vpnStatus: null,
      activeWanId: null
    } : g === "ap" ? s.aps.push({
      ...h,
      radios: Ce(a[String(p.id)]),
      clientCount: null,
      wiredClientCount: null,
      satisfaction: null,
      userClients: null,
      guestClients: null
    }) : s.switches.push({
      ...h,
      ports: ne(a[String(p.id)]),
      poeUsedW: null,
      poeBudgetW: null,
      portCount: null,
      generalTemperature: null,
      satisfaction: null,
      fanLevel: null,
      overheating: null,
      clientCount: null
    });
  }
  const d = N(i.wans);
  s.wans = d.map((p, g) => ({
    id: String(p.id ?? p.name ?? `wan-${g + 1}`),
    slot: g + 1,
    name: w(p.name) ?? `WAN${g + 1}`,
    networkGroup: null,
    operator: null,
    operatorKey: null,
    asn: null,
    online: null,
    ipv4: null,
    ipv6: null,
    rxBps: null,
    txBps: null,
    latencyMs: null,
    lossPct: null,
    availabilityPct: null,
    linkSpeedMbps: null,
    media: null,
    portName: null,
    uptimeSec: null,
    downtimeCount: null,
    anomalies: null,
    rxErrors: null,
    txErrors: null,
    rxDropped: null,
    txDropped: null,
    todayRxBytes: null,
    todayTxBytes: null,
    todayTotalBytes: null,
    monthRxBytes: null,
    monthTxBytes: null,
    monthTotalBytes: null,
    lossAvgPct: null,
    lossPeakPct: null,
    qualityHistory: [],
    role: g === 0 ? "primary" : "backup",
    active: null,
    source: "integration",
    state: "unsupported",
    detail: "Integration API 只返回 WAN 名称"
  }));
  const c = N(i.clients);
  return s.clients = c.map((p) => {
    const g = Date.parse(String(p.connectedAt ?? ""));
    return {
      id: String(p.id ?? p.macAddress),
      mac: K(w(p.macAddress)),
      name: w(p.name),
      hostname: null,
      ip: w(p.ipAddress),
      ipv6: [],
      wired: String(p.type ?? "").toUpperCase() === "WIRED",
      uplinkName: null,
      uplinkMac: null,
      uplinkPort: null,
      rxBps: null,
      txBps: null,
      linkSpeedMbps: null,
      signalDbm: null,
      noiseDbm: null,
      band: "unknown",
      channel: null,
      widthMhz: null,
      essid: null,
      uptimeSec: Number.isFinite(g) ? Math.max(0, (e - g) / 1e3) : null,
      satisfaction: null,
      manufacturer: null,
      network: null,
      vlan: null,
      firstSeen: null,
      lastSeen: null,
      txRetries: null,
      wifiRetryPct: null,
      source: "integration"
    };
  }), s.counts = Ke(s, s.clients), s.integrationFetchedAt = e, s.partial = !0, s.capabilities = Ge(s, !1, !0), s.warnings.push("传统只读统计接口不可用，WAN 速率/延迟/PoE 功耗/温度等指标不可用"), s;
}
function Pn(i, t) {
  for (const s of i.wans) {
    s.name = t.wanAliases[s.id] ?? t.wanAliases[s.name] ?? s.name;
    const n = s.operatorKey ?? s.operator ?? "";
    s.operator = t.operatorAliases[n] ?? t.operatorAliases[s.operator ?? ""] ?? s.operator;
  }
  const e = [i.gateway, ...i.switches, ...i.aps].filter(Boolean);
  for (const s of e)
    s.name = t.deviceAliases[s.mac] ?? s.name;
}
function Tn(i) {
  const t = si(i);
  return {
    networkVersion: w(t?.version),
    updateAvailable: P(t?.update_available)
  };
}
function Pe(i) {
  const t = f(i);
  return t !== null && t >= 0 ? t : null;
}
function En(i, t) {
  return i !== null && t !== null ? i + t : null;
}
function xt(i) {
  const t = i?.wan_activity?.activity_by_network_group;
  return t && typeof t == "object" ? t : {};
}
function As(i, t) {
  const e = xt(i)?.[t]?.summary;
  return { rx: Pe(e?.rx_bytes), tx: Pe(e?.tx_bytes) };
}
function _s(i, t) {
  const e = xt(i)?.[t]?.history;
  if (!Array.isArray(e)) return null;
  for (let s = e.length - 1; s >= 0; s--) {
    const n = f(e[s]?.avg_packet_loss_pct);
    if (n !== null) return n;
  }
  return null;
}
function Ms(i, t) {
  const e = xt(i)?.[t]?.history;
  if (!Array.isArray(e)) return { avg: null, peak: null };
  const s = e.map((n) => f(n?.avg_packet_loss_pct)).filter((n) => n !== null);
  return s.length ? { avg: s.reduce((n, a) => n + a, 0) / s.length, peak: Math.max(...s) } : { avg: null, peak: null };
}
function Ss(i, t) {
  const e = xt(i)?.[t]?.history;
  return Array.isArray(e) ? e.map((s) => ({
    timestamp: f(s?.timestamp) ?? 0,
    lossPct: f(s?.avg_packet_loss_pct),
    latencyMs: f(s?.avg_latency_ms),
    maxLatencyMs: f(s?.max_latency_ms),
    rxBps: f(s?.avg_rx_rate_bps),
    txBps: f(s?.avg_tx_rate_bps)
  })).filter((s) => s.timestamp > 0).sort((s, n) => s.timestamp - n.timestamp) : [];
}
function Cs(i) {
  const t = {};
  for (const e of Array.isArray(i?.wan?.wan_details) ? i.wan.wan_details : []) {
    const s = String(e?.network_group ?? "");
    s && (t[s] = Pe(e?.stats?.monthly_bytes));
  }
  return t;
}
function In(i) {
  const t = /* @__PURE__ */ new Map(), e = [];
  for (const d of Array.isArray(i?.wan_history?.wan_history_details) ? i.wan_history.wan_history_details : []) {
    const c = String(d?.network_group ?? ""), p = Array.isArray(d?.health_history) ? d.health_history : [];
    for (const g of p) {
      const m = f(g?.timestamp);
      if (m !== null && (e.push(m), g?.failover_wan_active === !0 || g?.wan2_failover_active === !0)) {
        const h = t.get(m) ?? /* @__PURE__ */ new Set();
        h.add(c), t.set(m, h);
      }
    }
  }
  if (!t.size) return [];
  const s = [...new Set(e)].sort((d, c) => d - c), n = s.slice(1).map((d, c) => d - s[c]).filter((d) => d > 0);
  n.sort((d, c) => d - c);
  const a = n.length ? n[Math.floor(n.length / 2)] : 0, r = Math.max(10 * 6e4, a * 1.8), u = [...t.entries()].sort((d, c) => d[0] - c[0]), o = [];
  for (const [d, c] of u) {
    const p = o[o.length - 1];
    p && d - p.end <= r ? (p.end = d, p.activeGroups = [.../* @__PURE__ */ new Set([...p.activeGroups, ...c])]) : o.push({ at: d, end: d, activeGroups: [...c], source: "aggregated-dashboard.wan_history.health_history" });
  }
  return o;
}
function Nn(i, t, e, s = Date.now()) {
  const n = xt(i), a = xt(t), r = { ...Cs(i), ...Cs(t) }, u = /* @__PURE__ */ new Set([...Object.keys(n), ...Object.keys(a), ...Object.keys(r)]), o = {};
  for (const d of u) {
    const c = As(i, d), p = As(t, d), g = _s(i, d), m = _s(e, d), h = Ms(i, d), b = Ms(e, d), k = h.avg !== null || h.peak !== null ? h : b, $ = Ss(e, d), T = $.length ? $ : Ss(i, d), A = p.rx !== null && p.tx !== null ? p.rx + p.tx : r[d] ?? null;
    o[d] = {
      todayRxBytes: c.rx,
      todayTxBytes: c.tx,
      todayTotalBytes: En(c.rx, c.tx),
      monthRxBytes: p.rx,
      monthTxBytes: p.tx,
      monthTotalBytes: A,
      lossPct: g ?? m,
      lossAvgPct: k.avg,
      lossPeakPct: k.peak,
      qualityHistory: T
    };
  }
  return { wans: o, failoverHistory: In(e), weekAvailable: !!e, fetchedAt: s };
}
function ut(i, t) {
  return {
    supported: i,
    status: i ? "ok" : "unverified",
    source: "legacy",
    ...t ? { reason: t } : {}
  };
}
function Rn(i, t) {
  for (const r of i.wans) {
    const u = r.networkGroup ?? r.name?.toUpperCase() ?? "", o = t.wans[u] ?? t.wans[r.name] ?? t.wans[r.id];
    o && (r.todayRxBytes = o.todayRxBytes, r.todayTxBytes = o.todayTxBytes, r.todayTotalBytes = o.todayTotalBytes, r.monthRxBytes = o.monthRxBytes, r.monthTxBytes = o.monthTxBytes, r.monthTotalBytes = o.monthTotalBytes, o.lossPct !== null && (r.lossPct = o.lossPct), r.lossAvgPct = o.lossAvgPct, r.lossPeakPct = o.lossPeakPct, r.qualityHistory = o.qualityHistory);
  }
  i.failoverHistory = t.failoverHistory, i.trafficFetchedAt = t.fetchedAt;
  const e = i.wans.some((r) => r.lossPct !== null), s = i.wans.some((r) => r.todayTotalBytes !== null), n = i.wans.some((r) => r.monthTotalBytes !== null), a = i.wans.some((r) => r.qualityHistory.length > 0);
  i.capabilities.wanLoss = ut(e, e ? "控制器 aggregated-dashboard 5 分钟平均丢包" : "聚合接口未返回丢包序列"), i.capabilities.wanTrafficToday = ut(s, s ? "控制器 aggregated-dashboard，按本地日边界" : "聚合接口未返回今日 WAN 流量"), i.capabilities.wanTrafficMonth = ut(n, n ? "控制器 aggregated-dashboard，按本地月边界" : "聚合接口未返回本月 WAN 流量"), i.capabilities.wanTraffic = ut(s || n, s || n ? "控制器 aggregated-dashboard" : "聚合接口未返回 WAN 流量"), i.capabilities.wanQualityHistory = ut(a, a ? "控制器 aggregated-dashboard 线路质量序列" : "聚合接口未返回线路质量序列"), i.capabilities.wanFailoverHistory = ut(
    t.weekAvailable,
    t.weekAvailable ? "控制器 health_history failover 标记；不使用 downtime 次数" : "聚合接口未返回 7 天 failover 历史"
  );
}
class x extends Error {
  constructor(t) {
    super(t.message), this.name = "AppError", this.kind = t.kind, this.status = t.status ?? null, this.endpoint = t.endpoint, this.detail = t.detail, this.retryAfterMs = t.retryAfterMs ?? null, this.cause = t.cause;
  }
  /** Stable, key-free string for diagnostics. */
  toDiagnostic() {
    return `${this.kind}${this.status ? `(${this.status})` : ""}: ${this.message}`;
  }
}
function j(i) {
  let t = String(i ?? "");
  return t = t.replace(/(Bearer)\s+[A-Za-z0-9._~+/=-]+/gi, "$1 [redacted]"), t = t.replace(/(X-API-Key|X-API-KEY|api[-_]?key|Authorization|token|cookie)\s*[:=]\s*[^\s,;"']+/gi, "$1: [redacted]"), t = t.replace(/\b[A-Za-z0-9_-]{28,}\b/g, "[redacted]"), t;
}
function gt(i) {
  try {
    const t = new URL(i);
    for (const e of [...t.searchParams.keys()])
      /key|token|secret|pass/i.test(e) && t.searchParams.set(e, "[redacted]");
    return t.toString();
  } catch {
    return j(i);
  }
}
function Un(i) {
  if (typeof i != "string") return !1;
  const t = i.trimStart().slice(0, 200).toLowerCase();
  return t.startsWith("<!doctype html") || t.startsWith("<html") || t.includes("<body") || t.startsWith("<");
}
function Bn(i, t) {
  const e = i, s = String(e?.message ?? i ?? ""), n = j(s), a = e?.type;
  return /No permission to access/i.test(s) ? new x({
    kind: "permission",
    message: "微应用没有访问该地址的权限（networkDomains）",
    endpoint: t,
    detail: n,
    cause: i
  }) : /tls:|x509|certificate (is valid|signed|has expired)|failed to verify certificate|unknown authority/i.test(s) ? new x({
    kind: "tls",
    message: "HTTPS 证书校验失败",
    endpoint: t,
    detail: n,
    cause: i
  }) : /no such host|lookup .* on .*:53|server misbehaving/i.test(s) ? new x({ kind: "dns", message: "无法解析网关主机名", endpoint: t, detail: n, cause: i }) : /context deadline exceeded|timeout|timed out|ETIMEDOUT/i.test(s) ? new x({ kind: "timeout", message: "请求超时", endpoint: t, detail: n, cause: i }) : /connection refused|network is unreachable|no route to host|dial tcp|ECONNREFUSED|EHOSTUNREACH|ENETUNREACH/i.test(s) ? new x({ kind: "network", message: "无法连接到网关", endpoint: t, detail: n, cause: i }) : /template proxy/i.test(s) || a === "microApp" ? new x({ kind: "proxy", message: "Sun-Panel 网络代理返回错误", endpoint: t, detail: n, cause: i }) : new x({ kind: "unknown", message: "请求失败", endpoint: t, detail: n, cause: i });
}
function On(i, t, e, s) {
  if (Un(t))
    return new x({
      kind: "html",
      message: `网关返回了 HTML 页面（HTTP ${i}），不是 JSON 接口响应`,
      status: i,
      endpoint: e,
      detail: typeof t == "string" ? t.slice(0, 180) : void 0
    });
  if (i === 401) {
    const n = typeof t == "string" ? t : JSON.stringify(t ?? {});
    return new x({
      kind: "auth",
      message: "API Key 无效或已失效",
      status: i,
      endpoint: e,
      detail: j(n).slice(0, 240)
    });
  }
  return i === 403 ? new x({ kind: "permission", message: "API Key 权限不足", status: i, endpoint: e }) : i === 404 ? new x({ kind: "not-found", message: "接口或站点不存在", status: i, endpoint: e }) : i === 429 ? new x({ kind: "rate-limit", message: "请求过于频繁，已触发限流", status: i, endpoint: e, retryAfterMs: s }) : i >= 500 ? new x({
    kind: "upstream",
    message: i === 502 || i === 503 || i === 504 ? "UniFi 服务暂时不可用或正在启动" : `网关返回 HTTP ${i}`,
    status: i,
    endpoint: e
  }) : new x({ kind: "http", message: `HTTP ${i}`, status: i, endpoint: e });
}
function zn(i) {
  switch (i.kind) {
    case "auth":
      return "ERR_AUTH";
    case "permission":
      return "ERR_PERMISSION";
    case "tls":
      return "ERR_TLS";
    case "dns":
      return "ERR_DNS";
    case "network":
      return "ERR_NETWORK";
    case "timeout":
      return "ERR_TIMEOUT";
    case "proxy":
      return "ERR_PROXY";
    case "html":
      return "ERR_HTML";
    case "rate-limit":
      return "ERR_RATE_LIMIT";
    case "not-found":
      return "ERR_NOT_FOUND";
    case "config":
      return "ERR_CONFIG";
    case "upstream":
      return "ERR_UPSTREAM";
    default:
      return "ERR_UNKNOWN";
  }
}
function Dn(i) {
  return !["auth", "permission", "config", "not-found"].includes(i.kind);
}
const Ps = "{{apiKey}}", Wn = "unifiAuth.apiKey";
function Et(i) {
  const t = String(i || "").trim();
  if (!t) throw new x({ kind: "config", message: "未配置 UniFi 网关地址" });
  let e;
  try {
    e = new URL(t);
  } catch {
    throw new x({ kind: "config", message: "网关地址格式无效" });
  }
  if (e.protocol !== "https:" && e.protocol !== "http:")
    throw new x({ kind: "config", message: "网关地址只支持 http/https" });
  if (e.username || e.password)
    throw new x({ kind: "config", message: "网关地址不能包含用户名或密码" });
  return `${e.protocol}//${e.host}`;
}
function Hn(i, t, e) {
  const s = String(t || "");
  if (!s.startsWith("/") || s.startsWith("//") || s.includes("://") || s.includes("\\"))
    throw new x({ kind: "config", message: "非法接口路径", detail: s });
  const n = Et(i), a = new URL(n + s);
  if (a.origin !== n) throw new x({ kind: "config", message: "接口路径越界", detail: s });
  if (e)
    for (const [r, u] of Object.entries(e))
      u == null || u === "" || a.searchParams.set(r, String(u));
  return a.toString();
}
function Ln(i) {
  if (i && typeof i == "object") {
    const t = i;
    if ("status" in t && ("data" in t || "statusText" in t)) {
      const e = typeof t.status == "number" ? t.status : Number(t.status ?? 200);
      return { status: Number.isFinite(e) ? e : 200, data: t.data };
    }
    if ("data" in t && !("status" in t) && Object.keys(t).length <= 3)
      return { status: 200, data: t.data };
  }
  return { status: 200, data: i };
}
function Fn(i, t, e) {
  if (i == null) return null;
  if (typeof i != "string") return i;
  const s = i.trim();
  if (!s) return null;
  if (s.startsWith("<"))
    throw new x({
      kind: "html",
      message: `网关返回了 HTML 页面（HTTP ${e}），不是 JSON 接口响应`,
      status: e,
      endpoint: gt(t),
      detail: s.slice(0, 180)
    });
  try {
    return JSON.parse(s);
  } catch {
    throw new x({
      kind: "json",
      message: "网关返回了无法解析的响应",
      status: e,
      endpoint: gt(t),
      detail: j(s).slice(0, 180)
    });
  }
}
function jn(i, t, e) {
  if (!i || typeof i != "object") return;
  const s = i.meta;
  if (s && s.rc === "error") {
    const n = String(s.msg ?? "UniFi API error"), a = /NoSiteContext|api\.err\.NoSiteContext/i.test(n) ? "not-found" : "http";
    throw new x({
      kind: a,
      message: a === "not-found" ? "站点不存在（NoSiteContext）" : `UniFi 接口错误：${n}`,
      status: e,
      endpoint: gt(t),
      detail: j(n)
    });
  }
}
class me {
  constructor(t) {
    this.inflight = /* @__PURE__ */ new Map(), this.ctx = t;
  }
  async get(t, e) {
    const s = Hn(t, e.path, e.query), n = this.inflight.get(s);
    if (n) return n;
    const a = this.execute(s, e);
    this.inflight.set(s, a);
    try {
      return await a;
    } finally {
      this.inflight.delete(s);
    }
  }
  async execute(t, e) {
    const s = Math.max(1e3, e.timeoutMs ?? 15e3), n = Date.now(), a = String(e.candidateKey ?? "").trim(), r = {
      Accept: "application/json",
      "X-API-Key": a || Ps
    };
    let u = null;
    const o = new Promise((m, h) => {
      u = this.ctx.api.timer.setTimeout(() => {
        h(new x({ kind: "timeout", message: "请求超时", endpoint: gt(t) }));
      }, s);
    });
    let d;
    try {
      d = await Promise.race([
        this.ctx.api.network.request({
          request: { targetUrl: t, method: "GET", headers: r },
          ...a ? {} : {
            templateReplacements: [
              { placeholder: Ps, fields: ["headers"], dataNodeKey: Wn }
            ]
          }
        }),
        o
      ]);
    } catch (m) {
      throw m instanceof x ? m : Bn(m, gt(t));
    } finally {
      u !== null && this.ctx.api.timer.clearTimeout(u);
    }
    const { status: c, data: p } = Ln(d), g = Fn(p, t, c);
    if (c >= 400) throw On(c, g, gt(t));
    return jn(g, t, c), { data: g, status: c, durationMs: Date.now() - n, url: t };
  }
}
const Kn = 0.5, Gn = 300;
function qt(i) {
  return typeof i == "number" && Number.isFinite(i) ? i : null;
}
class qn {
  constructor() {
    this.state = /* @__PURE__ */ new Map();
  }
  /**
   * @param reportedRxBps controller-reported bytes/sec (preferred)
   * @param reportedTxBps controller-reported bytes/sec (preferred)
   * @param rxBytes cumulative received bytes (fallback)
   * @param txBytes cumulative transmitted bytes (fallback)
   */
  observe(t, e, s, n, a, r) {
    const u = qt(s), o = qt(n), d = qt(a), c = qt(r), p = this.state.get(t);
    if (u !== null || o !== null)
      return this.state.set(t, { rx: d, tx: c, at: e }), {
        rxBps: u !== null && u >= 0 ? u : null,
        txBps: o !== null && o >= 0 ? o : null,
        computed: !1
      };
    if (!p || d === null || c === null)
      return this.state.set(t, { rx: d, tx: c, at: e }), { rxBps: null, txBps: null, computed: !1 };
    const g = (e - p.at) / 1e3;
    return !Number.isFinite(g) || g < Kn || g > Gn ? (this.state.set(t, { rx: d, tx: c, at: e }), { rxBps: null, txBps: null, computed: !1 }) : p.rx === null || p.tx === null || d < p.rx || c < p.tx ? (this.state.set(t, { rx: d, tx: c, at: e }), { rxBps: null, txBps: null, computed: !1 }) : (this.state.set(t, { rx: d, tx: c, at: e }), {
      rxBps: (d - p.rx) / g,
      txBps: (c - p.tx) / g,
      computed: !0
    });
  }
  reset(t) {
    t ? this.state.delete(t) : this.state.clear();
  }
}
const ae = "1.1.1", ve = "unifi:snapshot:v3", Vt = "unifiConfig", Xt = "settings", Ts = "unifiAuth", Es = "apiKey", E = {
  version: 1,
  host: "https://unifi.local",
  site: "default",
  integrationSiteId: null,
  fastIntervalSec: 5,
  slowIntervalSec: 30,
  clientsIntervalSec: 30,
  primaryWanId: null,
  wanAliases: {},
  operatorAliases: {},
  deviceAliases: {},
  widgetModules: ["wan", "devices", "gateway", "clients", "poe", "updated", "speedtest"],
  defaultTab: "overview",
  maskIp: !0,
  hideClientNames: !1,
  showWanAsn: !1,
  theme: "auto",
  showBits: !0,
  recordHistory: !0,
  apiKeyConfigured: !1
}, Te = ["wan", "devices", "gateway", "clients", "poe", "updated", "speedtest"], Vn = 5, Xn = 60, Zn = 15, Yn = 300, Jn = 10, Qn = 300, we = 1440, ta = 80, ea = 30, sa = 3e5, ia = 9e5, na = 3e5, aa = 18e5, be = 25e3, ra = 6e4, oa = 2e4, la = {
  "legacy.health": "传统健康状态",
  "legacy.devices": "传统设备统计",
  "legacy.clients": "传统客户端",
  "legacy.sysinfo": "控制器版本",
  "legacy.speedtest": "历史测速",
  "legacy.traffic.day": "今日 WAN 流量/丢包",
  "legacy.traffic.month": "本月 WAN 流量",
  "legacy.traffic.week": "7 天线路质量/故障切换",
  "legacy.sites": "传统站点列表",
  "integration.info": "Integration 版本",
  "integration.sites": "Integration 站点",
  "integration.devices": "Integration 设备",
  "integration.clients": "Integration 客户端",
  "integration.wans": "Integration WAN",
  "integration.detail": "Integration 设备详情"
};
function xe(i, t, e, s) {
  const n = typeof i == "number" ? Math.round(i) : Number(i);
  return Number.isFinite(n) ? rn(n, t, e) : s;
}
function Zt(i) {
  const t = i && typeof i == "object" ? i : {}, e = {
    ...E,
    ...t,
    version: 1,
    host: typeof t.host == "string" && t.host.trim() ? t.host.trim() : E.host,
    site: typeof t.site == "string" && t.site.trim() ? t.site.trim() : E.site,
    integrationSiteId: typeof t.integrationSiteId == "string" && t.integrationSiteId ? t.integrationSiteId : null,
    fastIntervalSec: xe(t.fastIntervalSec, Vn, Xn, E.fastIntervalSec),
    slowIntervalSec: xe(t.slowIntervalSec, Zn, Yn, E.slowIntervalSec),
    clientsIntervalSec: xe(t.clientsIntervalSec, Jn, Qn, E.clientsIntervalSec),
    primaryWanId: typeof t.primaryWanId == "string" && t.primaryWanId ? t.primaryWanId : null,
    wanAliases: ye(t.wanAliases),
    operatorAliases: ye(t.operatorAliases),
    deviceAliases: ye(t.deviceAliases),
    widgetModules: Array.isArray(t.widgetModules) ? t.widgetModules.map(String).filter((a) => Te.includes(a)) : [...E.widgetModules],
    defaultTab: ["overview", "wan", "gateway", "switch", "ap", "clients", "topology"].includes(t.defaultTab) ? t.defaultTab : E.defaultTab,
    maskIp: t.maskIp !== !1,
    hideClientNames: t.hideClientNames === !0,
    showWanAsn: t.showWanAsn === !0,
    theme: t.theme === "dark" || t.theme === "light" ? t.theme : "auto",
    showBits: t.showBits !== !1,
    recordHistory: t.recordHistory !== !1,
    apiKeyConfigured: t.apiKeyConfigured === !0
  };
  e.widgetModules.length || (e.widgetModules = [...E.widgetModules]);
  const s = ["wan", "devices", "gateway", "clients", "updated"], n = [...e.widgetModules].sort();
  return n.length === s.length && n.every((a, r) => a === [...s].sort()[r]) && (e.widgetModules = [...E.widgetModules]), e;
}
function ye(i) {
  const t = {};
  if (!i || typeof i != "object") return t;
  for (const [e, s] of Object.entries(i)) {
    if (typeof e != "string" || !e || typeof s != "string") continue;
    const n = s.trim().slice(0, 40);
    n && (t[e] = n);
  }
  return t;
}
function Is() {
  return Object.entries(la).map(([i, t]) => ({
    key: i,
    label: t,
    ok: !1,
    status: null,
    lastSuccessAt: null,
    lastAttemptAt: null,
    error: null,
    durationMs: null
  }));
}
const nt = class nt {
  constructor() {
    this.apis = [], this.leader = null, this.client = null, this.listeners = /* @__PURE__ */ new Set(), this.state = {
      settings: { ...E },
      snapshot: null,
      history: [],
      endpoints: Is(),
      initialized: !1,
      loading: !1,
      stale: !0,
      lastSuccessAt: null,
      lastError: null,
      appVersion: ae,
      activeTab: E.defaultTab
    }, this.tracker = new qn(), this.resources = /* @__PURE__ */ new Map(), this.resourceFlight = /* @__PURE__ */ new Map(), this.resourceErrors = /* @__PURE__ */ new Map(), this.lastRaw = {}, this.lastIntegration = {}, this.lastDevicesAt = null, this.lastClientsAt = null, this.lastIntegrationAt = null, this.lastSpeedtestAt = null, this.lastSysinfoAt = null, this.lastTrafficRaw = null, this.lastTrafficData = null, this.bootstrapped = !1, this.bootstrapping = null, this.schedulerStarted = !1, this.refreshingAll = !1, this.rebuildChain = Promise.resolve(), this.fastTimer = null, this.clientsTimer = null, this.slowTimer = null, this.integrationTimer = null, this.speedtestTimer = null, this.trafficTimer = null, this.hiddenTimer = null, this.persistTimer = null, this.visibilityHandler = null, this.onlineHandler = null, this.offlineHandler = null;
  }
  static get() {
    return nt.shared || (nt.shared = new nt()), nt.shared;
  }
  // ---------------------------------------------------------------- lifecycle
  attach(t) {
    this.apis.includes(t) || this.apis.push(t), (!this.leader || !this.apis.includes(this.leader)) && (this.leader = t, this.client = null, this.stopTimers(), this.bootstrapped && this.startScheduler()), !this.bootstrapped && !this.bootstrapping && (this.bootstrapping = this.bootstrap().catch((e) => {
      this.setError(e instanceof x ? e : new x({ kind: "unknown", message: "初始化失败", cause: e }));
    }).finally(() => {
      this.bootstrapping = null;
    }));
  }
  detach(t) {
    this.apis = this.apis.filter((e) => e !== t), this.leader === t && (this.stopTimers(), this.leader = this.apis[0] ?? null, this.leader && this.bootstrapped && this.startScheduler()), this.apis.length || (this.stopTimers(), this.removeGlobalListeners(), this.persistNow());
  }
  subscribe(t) {
    return this.listeners.add(t), t(this.state), () => this.listeners.delete(t);
  }
  getState() {
    return this.state;
  }
  setActiveTab(t) {
    this.state.activeTab = t, t === "clients" && this.lastClientsAt && Date.now() - this.lastClientsAt > 1e4 && this.refreshClients(!1), this.emit();
  }
  emit() {
    this.state = { ...this.state, endpoints: this.state.endpoints.map((t) => ({ ...t })) };
    for (const t of [...this.listeners])
      try {
        t(this.state);
      } catch (e) {
        console.error("[UniFi] listener failed", e);
      }
  }
  setError(t) {
    this.state.lastError = t, this.state.loading = !1, this.emit();
  }
  api() {
    if (!this.leader) throw new x({ kind: "config", message: "微应用尚未挂载" });
    return this.leader;
  }
  http() {
    return this.client || (this.client = new me({ api: this.api() })), this.client;
  }
  // ------------------------------------------------------------------ bootstrap
  async bootstrap() {
    const t = await this.loadSettings();
    if (this.state.settings = t, await this.restoreCache(), this.bootstrapped = !0, this.state.initialized = !0, this.addGlobalListeners(), this.emit(), !t.apiKeyConfigured) {
      this.state.lastError = new x({ kind: "config", message: "尚未配置 UniFi API Key" }), this.emit();
      return;
    }
    this.startScheduler(), await this.refreshAll(!0);
  }
  async loadSettings() {
    try {
      const t = await this.api().dataNode.user.getByKey(Vt, Xt);
      return Zt(t);
    } catch {
      return { ...E };
    }
  }
  async restoreCache() {
    try {
      const t = await this.api().localCache.user.get(ve);
      if (!t || t.v !== 1 || !t.snapshot) return;
      const e = Date.now() - (t.savedAt || 0);
      if (!Number.isFinite(e) || e < 0 || e > 24 * 36e5) return;
      this.state.snapshot = t.snapshot, this.state.history = Array.isArray(t.history) ? t.history.slice(-we) : [], this.state.stale = !0, this.state.lastSuccessAt = t.snapshot.fetchedAt || null;
    } catch {
    }
  }
  // ------------------------------------------------------------------ scheduler
  startScheduler() {
    if (!this.leader || this.schedulerStarted || !this.state.settings.apiKeyConfigured) return;
    this.schedulerStarted = !0;
    const t = this.state.settings.fastIntervalSec * 1e3, e = this.state.settings.clientsIntervalSec * 1e3, s = this.state.settings.slowIntervalSec * 1e3;
    if (typeof document < "u" && document.hidden) {
      this.startHiddenTimer();
      return;
    }
    this.fastTimer = this.api().timer.setInterval(() => void this.tickFast(), t), this.clientsTimer = this.api().timer.setInterval(() => void this.refreshClients(!1), e), this.slowTimer = this.api().timer.setInterval(() => void this.refreshSysinfo(!1), s), this.integrationTimer = this.api().timer.setInterval(() => void this.refreshIntegration(!1), sa), this.speedtestTimer = this.api().timer.setInterval(() => void this.refreshSpeedtest(!1), ia), this.trafficTimer = this.api().timer.setInterval(() => void this.refreshTraffic(!1), na);
  }
  startHiddenTimer() {
    this.hiddenTimer === null && (this.hiddenTimer = this.api().timer.setInterval(() => void this.refreshHidden(), ra));
  }
  stopTimers() {
    const t = this.leader, e = (s) => {
      if (s !== null && t)
        try {
          t.timer.clearInterval(s);
        } catch {
        }
      return null;
    };
    if (this.fastTimer = e(this.fastTimer), this.clientsTimer = e(this.clientsTimer), this.slowTimer = e(this.slowTimer), this.integrationTimer = e(this.integrationTimer), this.speedtestTimer = e(this.speedtestTimer), this.trafficTimer = e(this.trafficTimer), this.hiddenTimer = e(this.hiddenTimer), this.persistTimer !== null && t) {
      try {
        t.timer.clearTimeout(this.persistTimer);
      } catch {
      }
      this.persistTimer = null;
    }
    this.schedulerStarted = !1;
  }
  addGlobalListeners() {
    typeof document < "u" && document.addEventListener && !this.visibilityHandler && (this.visibilityHandler = () => {
      this.bootstrapped && (document.hidden ? (this.stopTimers(), this.startHiddenTimer()) : (this.stopTimers(), this.startScheduler(), this.refreshAll(!0)));
    }, document.addEventListener("visibilitychange", this.visibilityHandler)), typeof window < "u" && window.addEventListener && (this.onlineHandler || (this.onlineHandler = () => {
      this.resetBackoff(), this.refreshAll(!0);
    }, window.addEventListener("online", this.onlineHandler)), this.offlineHandler || (this.offlineHandler = () => {
      this.state.stale = !0, this.state.lastError = new x({ kind: "network", message: "浏览器处于离线状态" }), this.emit();
    }, window.addEventListener("offline", this.offlineHandler)));
  }
  removeGlobalListeners() {
    typeof document < "u" && this.visibilityHandler && (document.removeEventListener("visibilitychange", this.visibilityHandler), this.visibilityHandler = null), typeof window < "u" && (this.onlineHandler && window.removeEventListener("online", this.onlineHandler), this.offlineHandler && window.removeEventListener("offline", this.offlineHandler), this.onlineHandler = null, this.offlineHandler = null);
  }
  // ------------------------------------------------------------------ resources
  resource(t) {
    let e = this.resources.get(t);
    return e || (e = { lastAttemptAt: null, lastSuccessAt: null, status: null, error: null, durationMs: null, failures: 0, nextAllowedAt: 0 }, this.resources.set(t, e)), e;
  }
  canRun(t, e) {
    return e ? !0 : Date.now() >= this.resource(t).nextAllowedAt;
  }
  endpointUpdate(t, e) {
    const s = this.state.endpoints.findIndex((n) => n.key === t);
    s < 0 || (this.state.endpoints[s] = { ...this.state.endpoints[s], ...e });
  }
  endpointOk(t, e, s) {
    const n = this.resource(t), a = Date.now();
    n.failures = 0, n.nextAllowedAt = 0, n.lastAttemptAt = a, n.lastSuccessAt = a, n.status = e, n.error = null, n.durationMs = s, this.resourceErrors.delete(t), this.endpointUpdate(t, {
      ok: !0,
      status: e,
      lastSuccessAt: a,
      lastAttemptAt: a,
      error: null,
      durationMs: s
    });
  }
  endpointError(t, e) {
    const s = this.resource(t), n = Date.now();
    s.failures += 1, s.lastAttemptAt = n, s.status = e.status, s.error = j(e.toDiagnostic()), s.durationMs = null, this.resourceErrors.set(t, e);
    const a = Dn(e) ? 5e3 * Math.pow(2, Math.min(6, s.failures - 1)) : 3e5;
    s.nextAllowedAt = n + Math.min(3e5, a) + Math.floor(Math.random() * 400), this.endpointUpdate(t, {
      ok: !1,
      status: e.status,
      lastAttemptAt: n,
      error: s.error
    });
  }
  resetBackoff() {
    for (const t of this.resources.values())
      t.failures = 0, t.nextAllowedAt = 0;
  }
  async fetchResource(t, e, s, n = 15e3, a) {
    if (!this.canRun(t, s)) return null;
    const r = this.resourceFlight.get(t);
    if (r) return r;
    const u = (async () => {
      try {
        const o = await this.http().get(this.state.settings.host, { path: e, query: a, timeoutMs: n });
        return this.endpointOk(t, o.status, o.durationMs), o;
      } catch (o) {
        const d = o instanceof x ? o : new x({ kind: "unknown", message: "请求失败", cause: o });
        throw this.endpointError(t, d), d;
      } finally {
        this.resourceFlight.delete(t);
      }
    })();
    return this.resourceFlight.set(t, u), u;
  }
  // ------------------------------------------------------------------ refresh
  async refreshAll(t = !0) {
    if (this.refreshingAll) return;
    if (!this.state.settings.apiKeyConfigured) {
      this.state.lastError = new x({ kind: "config", message: "尚未配置 UniFi API Key" }), this.emit();
      return;
    }
    this.refreshingAll = !0, this.state.loading = !0, this.emit();
    const e = this.state.settings.site, s = [], n = Date.now();
    s.push(this.fetchResource("legacy.health", M.legacyHealth(e).path, t).then((o) => {
      o && (this.lastRaw.health = o.data);
    })), s.push(this.fetchResource("legacy.devices", M.legacyDevices(e).path, t).then((o) => {
      o && (this.lastRaw.devices = o.data, this.lastDevicesAt = n);
    })), s.push(this.fetchResource("legacy.clients", M.legacyClients(e).path, t).then((o) => {
      o && (this.lastRaw.clients = o.data, this.lastClientsAt = n);
    })), s.push(this.fetchResource("legacy.sysinfo", M.legacySysinfo(e).path, t).then((o) => {
      o && (this.lastRaw.sysinfo = o.data, this.lastSysinfoAt = n);
    })), s.push(this.fetchResource("legacy.speedtest", M.legacySpeedtest(e).path, t, 2e4).then((o) => {
      o && (this.lastRaw.speedtest = o.data, this.lastSpeedtestAt = n);
    })), s.push(this.fetchIntegration(t).then(async () => {
      this.state.settings.integrationSiteId && !this.lastIntegration.devices && await this.fetchIntegration(t);
    }));
    const a = await Promise.allSettled(s), r = a.filter((o) => o.status === "rejected").length;
    if (this.refreshingAll = !1, this.lastRaw.devices || this.lastRaw.health)
      await this.rebuild();
    else if (this.lastIntegration.devices)
      await this.rebuild();
    else {
      const o = a.find((c) => c.status === "rejected"), d = o?.reason instanceof x ? o.reason : new x({ kind: "unknown", message: "无法获取 UniFi 数据", cause: o?.reason });
      this.state.loading = !1, this.state.stale = !0, this.state.lastError = d, this.emit();
      return;
    }
    const u = this.resourceErrors.get("legacy.devices");
    u ? (this.state.lastError = u, this.state.stale = !0) : r === a.length && (this.state.stale = !0), this.state.loading = !1, this.emit(), this.schedulePersist(), this.refreshTraffic(t);
  }
  async tickFast() {
    if (typeof document < "u" && document.hidden || !this.state.settings.apiKeyConfigured || !this.leader) return;
    const t = this.state.settings.site, e = Date.now(), [s, n] = await Promise.allSettled([
      this.fetchResource("legacy.health", M.legacyHealth(t).path, !1),
      this.fetchResource("legacy.devices", M.legacyDevices(t).path, !1)
    ]);
    let a = !1;
    if (s.status === "fulfilled" && s.value && (this.lastRaw.health = s.value.data), n.status === "fulfilled" && n.value && (this.lastRaw.devices = n.value.data, this.lastDevicesAt = e, a = !0), a)
      this.state.lastSuccessAt = e, this.state.stale = !1, this.state.lastError = null, await this.rebuild(), this.schedulePersist();
    else {
      const r = n.status === "rejected" ? n.reason : null;
      r instanceof x && (this.state.lastError = r), this.state.stale = !0, this.emit();
    }
  }
  async refreshClients(t) {
    if (!this.state.settings.apiKeyConfigured || !this.leader || typeof document < "u" && document.hidden && !t) return;
    const e = this.state.settings.site;
    try {
      const s = await this.fetchResource("legacy.clients", M.legacyClients(e).path, t);
      if (!s) return;
      this.lastRaw.clients = s.data, this.lastClientsAt = Date.now(), await this.rebuild();
    } catch {
    }
  }
  async refreshSysinfo(t) {
    if (!this.state.settings.apiKeyConfigured || !this.leader || typeof document < "u" && document.hidden && !t) return;
    const e = this.state.settings.site;
    try {
      const s = await this.fetchResource("legacy.sysinfo", M.legacySysinfo(e).path, t);
      if (!s) return;
      this.lastRaw.sysinfo = s.data, this.lastSysinfoAt = Date.now();
      const n = Tn(s.data);
      this.state.snapshot?.gateway && (this.state.snapshot.gateway.networkVersion = n.networkVersion ?? this.state.snapshot.gateway.networkVersion, n.updateAvailable !== null && (this.state.snapshot.gateway.updateAvailable = n.updateAvailable), this.emit());
    } catch {
    }
  }
  async refreshSpeedtest(t) {
    if (!this.state.settings.apiKeyConfigured || !this.leader || typeof document < "u" && document.hidden && !t) return;
    const e = this.state.settings.site;
    try {
      const s = await this.fetchResource("legacy.speedtest", M.legacySpeedtest(e).path, t, 2e4);
      if (!s) return;
      this.lastRaw.speedtest = s.data, this.lastSpeedtestAt = Date.now(), await this.rebuild();
    } catch {
    }
  }
  async refreshTraffic(t) {
    if (!this.state.settings.apiKeyConfigured || !this.leader || typeof document < "u" && document.hidden && !t) return;
    const e = Date.now(), s = new Date(e);
    s.setHours(0, 0, 0, 0);
    const n = new Date(e), a = new Date(n.getFullYear(), n.getMonth(), 1, 0, 0, 0, 0), r = Math.max(300, Math.floor((e - s.getTime()) / 1e3)), u = Math.max(300, Math.floor((e - a.getTime()) / 1e3)), o = this.state.settings.site, d = M.legacyAggregatedDashboard(o).path, c = t || !this.lastTrafficRaw?.month || !this.lastTrafficRaw?.week || e - this.lastTrafficRaw.longAt > aa, p = [
      this.fetchResource("legacy.traffic.day", d, t, be, { historySeconds: r })
    ];
    c && (p.push(this.fetchResource("legacy.traffic.month", d, t, be, { historySeconds: u })), p.push(this.fetchResource("legacy.traffic.week", d, t, be, { historySeconds: 604800 })));
    const g = await Promise.allSettled(p), m = g[0]?.status === "fulfilled" ? g[0].value?.data : null, h = c && g[1]?.status === "fulfilled" ? g[1].value?.data : this.lastTrafficRaw?.month, b = c && g[2]?.status === "fulfilled" ? g[2].value?.data : this.lastTrafficRaw?.week;
    if (!m && !h && !b) return;
    const k = c && !!h && !!b;
    this.lastTrafficRaw = {
      day: m ?? this.lastTrafficRaw?.day,
      month: h,
      week: b,
      fetchedAt: e,
      longAt: k ? e : this.lastTrafficRaw?.longAt ?? 0
    }, this.lastTrafficData = Nn(this.lastTrafficRaw.day, h, b, e), this.state.snapshot && await this.rebuild();
  }
  async refreshIntegration(t) {
    !this.state.settings.apiKeyConfigured || !this.leader || typeof document < "u" && document.hidden && !t || (await this.fetchIntegration(t), (this.lastIntegration.devices || this.lastIntegration.sites) && await this.rebuild());
  }
  async fetchIntegration(t) {
    const e = this.state.settings.integrationSiteId, s = !this.lastRaw.devices, n = await Promise.allSettled([
      this.fetchResource("integration.info", M.integrationInfo.path, t, 1e4),
      this.fetchResource("integration.sites", M.integrationSites.path, t, 1e4),
      e ? this.fetchResource("integration.devices", M.integrationDevices(e).path, t, 15e3) : Promise.resolve(null),
      e ? this.fetchResource("integration.clients", M.integrationClients(e).path, t, 15e3, { limit: on }) : Promise.resolve(null),
      e ? this.fetchResource("integration.wans", M.integrationWans(e).path, t, 1e4) : Promise.resolve(null)
    ]), [a, r, u, o, d] = n;
    if (a.status === "fulfilled" && a.value && (this.lastIntegration.info = a.value.data), r.status === "fulfilled" && r.value) {
      this.lastIntegration.sites = r.value.data;
      const c = (r.value.data?.data ?? []).find((p) => String(p.internalReference) === this.state.settings.site);
      c?.id && c.id !== this.state.settings.integrationSiteId && (this.state.settings = { ...this.state.settings, integrationSiteId: String(c.id) });
    }
    if (u.status === "fulfilled" && u.value && (this.lastIntegration.devices = u.value.data), o.status === "fulfilled" && o.value && (this.lastIntegration.clients = o.value.data), d.status === "fulfilled" && d.value && (this.lastIntegration.wans = d.value.data), this.lastIntegrationAt = Date.now(), s) {
      const c = this.lastIntegration.devices?.data ?? [], p = {}, g = {}, m = c.filter((h) => h.id).slice(0, 12);
      await Promise.allSettled(m.map(async (h) => {
        const b = String(h.id), [k, $] = await Promise.allSettled([
          this.fetchResource(`integration.detail.${b}`, M.integrationDevice(e ?? "", b).path, t, 12e3),
          this.fetchResource(`integration.stats.${b}`, M.integrationDeviceStats(e ?? "", b).path, t, 12e3)
        ]);
        k.status === "fulfilled" && k.value && (p[b] = k.value.data), $.status === "fulfilled" && $.value && (g[b] = $.value.data);
      })), this.lastIntegration.details = p, this.lastIntegration.stats = g;
    }
  }
  async refreshHidden() {
    if (!this.state.settings.apiKeyConfigured || !this.leader || typeof document < "u" && !document.hidden) return;
    const t = this.state.settings.site, e = Date.now(), [s, n, a] = await Promise.allSettled([
      this.fetchResource("legacy.health", M.legacyHealth(t).path, !1),
      this.fetchResource("legacy.devices", M.legacyDevices(t).path, !1),
      this.fetchResource("legacy.clients", M.legacyClients(t).path, !1)
    ]);
    s.status === "fulfilled" && s.value && (this.lastRaw.health = s.value.data), n.status === "fulfilled" && n.value && (this.lastRaw.devices = n.value.data, this.lastDevicesAt = e), a.status === "fulfilled" && a.value && (this.lastRaw.clients = a.value.data, this.lastClientsAt = e), n.status === "fulfilled" && n.value && (this.state.lastSuccessAt = e, this.state.stale = !1, await this.rebuild(), this.schedulePersist());
  }
  // ------------------------------------------------------------------ rebuild
  scheduleRebuild() {
    return this.rebuildChain = this.rebuildChain.then(() => this.rebuild()).catch(() => {
    }), this.rebuildChain;
  }
  async rebuild() {
    if (!this.lastRaw.devices && !this.lastRaw.health && !this.lastIntegration.devices) return;
    const t = this.state.settings, e = this.lastDevicesAt ?? Date.now();
    let s;
    this.lastRaw.devices || this.lastRaw.health ? s = kn(this.lastRaw, t, this.tracker, e) : s = Cn(this.lastIntegration, t), this.lastIntegration.devices || this.lastIntegration.sites ? s = Sn(s, this.lastIntegration, t, Date.now()) : s.capabilities, !this.lastRaw.speedtest && this.state.snapshot && (s.speedtests = this.state.snapshot.speedtests), Pn(s, t), this.lastTrafficData && Rn(s, this.lastTrafficData), s.warnings = [...new Set(s.warnings)], s.counts.clientsTotal === null && this.state.snapshot?.counts.clientsTotal !== null && this.lastRaw.clients === void 0 && (s.counts = { ...s.counts, clientsTotal: this.state.snapshot?.counts.clientsTotal ?? null, clientsWired: this.state.snapshot?.counts.clientsWired ?? null, clientsWireless: this.state.snapshot?.counts.clientsWireless ?? null }), this.state.snapshot = s, this.state.lastSuccessAt = e, this.lastRaw.devices && (this.state.stale = !1, this.state.lastError = null), this.appendHistory(s, e), this.emit();
  }
  appendHistory(t, e) {
    if (!this.state.settings.recordHistory) {
      this.state.history = [];
      return;
    }
    const s = this.state.history;
    for (const r of t.wans) {
      if (r.rxBps === null && r.txBps === null && r.latencyMs === null && r.online === null) continue;
      const u = [...s].reverse().find((o) => o.wanId === r.id);
      u && e - u.t < 2e3 || s.push({
        t: e,
        wanId: r.id,
        rxBps: r.rxBps,
        txBps: r.txBps,
        latencyMs: r.latencyMs,
        online: r.online
      });
    }
    const n = /* @__PURE__ */ new Map();
    for (const r of s) {
      const u = n.get(r.wanId) ?? [];
      u.push(r), n.set(r.wanId, u);
    }
    const a = [];
    for (const r of n.values()) a.push(...r.slice(-180));
    a.sort((r, u) => r.t - u.t), this.state.history = a.slice(-we);
  }
  // ------------------------------------------------------------------ persistence
  schedulePersist() {
    this.persistTimer !== null || !this.leader || (this.persistTimer = this.leader.timer.setTimeout(() => {
      this.persistTimer = null, this.persistNow();
    }, oa));
  }
  async persistNow() {
    if (!(!this.leader || !this.state.snapshot))
      try {
        const t = {
          ...this.state.snapshot,
          clients: this.state.snapshot.clients.slice(0, ta),
          speedtests: this.state.snapshot.speedtests.slice(0, ea)
        }, e = {
          v: 1,
          savedAt: Date.now(),
          snapshot: t,
          history: this.state.history.slice(-we)
        };
        await this.leader.localCache.user.set(ve, e, 3600);
      } catch {
      }
  }
  // ------------------------------------------------------------------ settings
  async saveSettings(t, e = !0) {
    const s = this.state.settings, n = Zt({ ...s, ...t });
    n.host = Et(n.host);
    const a = n.host !== s.host, r = n.site !== s.site || n.integrationSiteId !== s.integrationSiteId;
    return await this.api().dataNode.user.setByKey(Vt, Xt, n), this.state.settings = n, this.resetBackoff(), (a || r) && this.resetData(), this.stopTimers(), this.startScheduler(), this.emit(), e && n.apiKeyConfigured && this.refreshAll(!0), n;
  }
  async saveApiKey(t) {
    const e = String(t || "").trim();
    if (!e) throw new x({ kind: "config", message: "API Key 不能为空" });
    if (e.length < 8 || /\s/.test(e))
      throw new x({ kind: "config", message: "API Key 格式不正确" });
    await this.api().dataNode.user.setByKey(Ts, Es, e);
    const s = Zt({ ...this.state.settings, apiKeyConfigured: !0 });
    await this.api().dataNode.user.setByKey(Vt, Xt, s), this.state.settings = s, this.resetBackoff(), this.stopTimers(), this.startScheduler(), this.emit(), this.refreshAll(!0);
  }
  async clearApiKey() {
    await this.api().dataNode.user.delByKey(Ts, Es);
    const t = Zt({ ...this.state.settings, apiKeyConfigured: !1 });
    await this.api().dataNode.user.setByKey(Vt, Xt, t), this.state.settings = t, this.stopTimers(), this.state.lastError = new x({ kind: "config", message: "API Key 已清除" }), this.emit();
  }
  resetData() {
    this.lastRaw = {}, this.lastIntegration = {}, this.lastDevicesAt = null, this.lastClientsAt = null, this.lastIntegrationAt = null, this.lastSpeedtestAt = null, this.lastSysinfoAt = null, this.lastTrafficRaw = null, this.lastTrafficData = null, this.tracker.reset(), this.state.snapshot = null, this.state.history = [], this.state.stale = !0, this.state.lastSuccessAt = null, this.state.lastError = null, this.resources.clear(), this.state.endpoints = Is();
    try {
      this.api().localCache.user.del(ve);
    } catch {
    }
    this.emit();
  }
  // ------------------------------------------------------------------ connection test
  async testConnection(t, e) {
    let s;
    try {
      s = Et(t);
    } catch (g) {
      return { ok: !1, checks: [{ name: "地址格式", ok: !1, status: null, message: (g instanceof x ? g : new x({ kind: "config", message: "地址格式无效" })).message }], sites: [], degraded: !1 };
    }
    const n = String(e ?? "").trim();
    if (!n && !this.state.settings.apiKeyConfigured)
      return {
        ok: !1,
        checks: [{ name: "API Key", ok: !1, status: null, message: "尚未保存 API Key，请先输入或保存" }],
        sites: [],
        degraded: !1
      };
    const r = [], u = new me({ api: this.api() }), o = this.state.settings.site;
    try {
      const g = await u.get(s, { path: M.integrationInfo.path, candidateKey: n || void 0, timeoutMs: 1e4 }), m = String(g.data?.applicationVersion ?? "");
      r.push({ name: "官方 Integration API", ok: !0, status: g.status, message: m ? `Network ${m}` : "可用" });
    } catch (g) {
      const m = g instanceof x ? g : new x({ kind: "unknown", message: "请求失败" });
      r.push({ name: "官方 Integration API", ok: !1, status: m.status, message: `${m.message}${m.kind === "auth" ? "" : "（可降级）"}` });
    }
    try {
      const g = await u.get(s, { path: M.legacyHealth(o).path, candidateKey: n || void 0, timeoutMs: 1e4 }), m = (g.data?.data ?? []).find((h) => h?.subsystem === "wan");
      r.push({ name: "传统只读接口", ok: !0, status: g.status, message: m?.status ? `WAN ${m.status}` : "可用" });
    } catch (g) {
      const m = g instanceof x ? g : new x({ kind: "unknown", message: "请求失败" });
      r.push({ name: "传统只读接口", ok: !1, status: m.status, message: m.message });
    }
    let d = [];
    try {
      const g = await u.get(s, { path: M.legacySites.path, candidateKey: n || void 0, timeoutMs: 1e4 });
      d = (g.data?.data ?? []).map((m) => ({ name: String(m.name ?? ""), label: String(m.desc ?? m.name ?? ""), source: "legacy" })).filter((m) => m.name), r.push({ name: "站点发现", ok: d.length > 0, status: g.status, message: d.length ? `${d.length} 个站点` : "未发现站点" });
    } catch (g) {
      const m = g instanceof x ? g : new x({ kind: "unknown", message: "请求失败" });
      r.push({ name: "站点发现", ok: !1, status: m.status, message: m.message });
    }
    const c = r.find((g) => g.name === "传统只读接口")?.ok === !0, p = r.find((g) => g.name === "官方 Integration API")?.ok === !0;
    return {
      ok: c || p,
      checks: r,
      sites: d,
      degraded: !c || !p
    };
  }
  async discoverSites(t, e) {
    const s = Et(t || this.state.settings.host), n = String(e ?? "").trim(), a = new me({ api: this.api() }), r = [];
    try {
      const u = await a.get(s, { path: M.legacySites.path, candidateKey: n || void 0, timeoutMs: 12e3 });
      for (const o of u.data?.data ?? []) {
        const d = String(o.name ?? "");
        d && r.push({ name: d, label: String(o.desc ?? d), source: "legacy" });
      }
    } catch {
    }
    try {
      const u = await a.get(s, { path: M.integrationSites.path, candidateKey: n || void 0, timeoutMs: 12e3 });
      for (const o of u.data?.data ?? []) {
        const d = String(o.internalReference ?? "");
        d && !r.some((c) => c.name === d) && r.push({ name: d, label: String(o.name ?? d), source: "integration" });
      }
    } catch {
    }
    return r;
  }
  // ------------------------------------------------------------------ diagnostics
  exportDiagnostics() {
    const t = this.state.settings, e = this.state.snapshot;
    return {
      app: "UniFi Network Monitor",
      version: ae,
      exportedAt: (/* @__PURE__ */ new Date()).toISOString(),
      runtime: {
        userAgent: typeof navigator < "u" ? navigator.userAgent : "unknown",
        language: typeof navigator < "u" ? navigator.language : "unknown",
        online: typeof navigator < "u" ? navigator.onLine : null,
        hidden: typeof document < "u" ? document.hidden : null
      },
      connection: {
        host: da(t.host),
        site: t.site,
        integrationSiteId: t.integrationSiteId ? "[uuid]" : null,
        apiKeyConfigured: t.apiKeyConfigured,
        intervals: {
          fastSec: t.fastIntervalSec,
          slowSec: t.slowIntervalSec,
          clientsSec: t.clientsIntervalSec
        }
      },
      snapshot: e ? {
        fetchedAt: e.fetchedAt,
        legacyFetchedAt: e.legacyFetchedAt,
        integrationFetchedAt: e.integrationFetchedAt,
        partial: e.partial,
        site: e.site ? { name: e.site.name, internalReference: e.site.internalReference } : null,
        gateway: e.gateway ? { model: e.gateway.model, firmware: e.gateway.firmware, networkVersion: e.gateway.networkVersion } : null,
        counts: e.counts,
        wanCount: e.wans.length,
        clientCount: e.clients.length,
        capabilities: e.capabilities,
        warnings: e.warnings
      } : null,
      endpoints: this.state.endpoints.map((s) => ({
        key: s.key,
        label: s.label,
        ok: s.ok,
        status: s.status,
        lastSuccessAt: s.lastSuccessAt,
        lastAttemptAt: s.lastAttemptAt,
        durationMs: s.durationMs,
        error: s.error ? j(s.error) : null
      })),
      lastError: this.state.lastError ? {
        kind: this.state.lastError.kind,
        status: this.state.lastError.status,
        message: j(this.state.lastError.message),
        detail: this.state.lastError.detail ? j(this.state.lastError.detail) : null
      } : null,
      cache: {
        historyPoints: this.state.history.length,
        snapshotAgeSec: e ? Math.round((Date.now() - e.fetchedAt) / 1e3) : null
      }
    };
  }
  get lastErrorKey() {
    return this.state.lastError ? zn(this.state.lastError) : null;
  }
};
nt.shared = null;
let Ee = nt;
function da(i) {
  try {
    const t = new URL(i), e = t.hostname;
    if (/^\d+\.\d+\.\d+\.\d+$/.test(e)) {
      const s = e.split(".");
      return `${t.protocol}//${s[0]}.${s[1]}.*.*${t.port ? `:${t.port}` : ""}`;
    }
    return `${t.protocol}//${e}${t.port ? `:${t.port}` : ""}`;
  } catch {
    return "[invalid]";
  }
}
function Dt() {
  return Ee.get();
}
const pe = Lt`
  :host {
    --sp-bg: rgba(16, 17, 22, 0.52);
    --sp-bg-strong: rgba(16, 17, 22, 0.82);
    --sp-surface: rgba(255, 255, 255, 0.045);
    --sp-surface-hover: rgba(255, 255, 255, 0.085);
    --sp-border: rgba(255, 255, 255, 0.16);
    --sp-border-soft: rgba(255, 255, 255, 0.09);
    --sp-text: #ffffff;
    --sp-muted: rgba(255, 255, 255, 0.64);
    --sp-faint: rgba(255, 255, 255, 0.4);
    --sp-down: #4da3ff;
    --sp-up: #37d67a;
    --sp-ok: #37d67a;
    --sp-warn: #ffb020;
    --sp-bad: #ff5c5c;
    --sp-radius: 14px;
    --sp-radius-sm: 9px;
    --sp-mono: ui-monospace, SFMono-Regular, "SF Mono", Menlo, Consolas, monospace;
    display: block;
    box-sizing: border-box;
    color: var(--sp-text);
    font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", "PingFang SC", "Hiragino Sans GB", "Microsoft YaHei", sans-serif;
    font-size: 13px;
    line-height: 1.45;
    -webkit-font-smoothing: antialiased;
    text-rendering: optimizeLegibility;
  }
  :host([data-theme="light"]) {
    --sp-bg: rgba(255, 255, 255, 0.72);
    --sp-bg-strong: rgba(255, 255, 255, 0.94);
    --sp-surface: rgba(16, 17, 22, 0.045);
    --sp-surface-hover: rgba(16, 17, 22, 0.075);
    --sp-border: rgba(16, 17, 22, 0.14);
    --sp-border-soft: rgba(16, 17, 22, 0.08);
    --sp-text: #171a21;
    --sp-muted: rgba(23, 26, 33, 0.62);
    --sp-faint: rgba(23, 26, 33, 0.4);
    --sp-down: #1976e8;
    --sp-up: #129a55;
    --sp-ok: #129a55;
    --sp-warn: #c77a00;
    --sp-bad: #d33a3a;
  }
  * { box-sizing: border-box; }
  .ic { width: 1em; height: 1em; display: inline-block; vertical-align: -0.13em; flex: none; }
  .muted { color: var(--sp-muted); }
  .faint { color: var(--sp-faint); }
  .mono { font-family: var(--sp-mono); }
  .num { font-variant-numeric: tabular-nums; font-feature-settings: "tnum"; }
  .row { display: flex; align-items: center; gap: 8px; }
  .between { display: flex; align-items: center; justify-content: space-between; gap: 8px; }
  .col { display: flex; flex-direction: column; gap: 6px; }
  .grow { flex: 1 1 auto; min-width: 0; }
  .truncate { overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
  .surface {
    background: var(--sp-surface);
    border: 1px solid var(--sp-border-soft);
    border-radius: var(--sp-radius-sm);
  }
  .badge {
    display: inline-flex; align-items: center; gap: 4px;
    padding: 1px 7px; border-radius: 999px;
    font-size: 11px; line-height: 18px; white-space: nowrap;
    border: 1px solid var(--sp-border-soft); color: var(--sp-muted);
  }
  .badge.ok { color: var(--sp-ok); border-color: color-mix(in srgb, var(--sp-ok) 36%, transparent); }
  .badge.warn { color: var(--sp-warn); border-color: color-mix(in srgb, var(--sp-warn) 36%, transparent); }
  .badge.bad { color: var(--sp-bad); border-color: color-mix(in srgb, var(--sp-bad) 36%, transparent); }
  .dot { width: 7px; height: 7px; border-radius: 50%; background: var(--sp-faint); flex: none; }
  .dot.ok { background: var(--sp-ok); box-shadow: 0 0 0 3px color-mix(in srgb, var(--sp-ok) 18%, transparent); }
  .dot.warn { background: var(--sp-warn); box-shadow: 0 0 0 3px color-mix(in srgb, var(--sp-warn) 18%, transparent); }
  .dot.bad { background: var(--sp-bad); box-shadow: 0 0 0 3px color-mix(in srgb, var(--sp-bad) 18%, transparent); }
  .btn {
    appearance: none; border: 1px solid var(--sp-border); background: var(--sp-surface);
    color: var(--sp-text); border-radius: 8px; padding: 5px 10px; font-size: 12px;
    cursor: pointer; display: inline-flex; align-items: center; gap: 5px;
    transition: background .15s ease, border-color .15s ease;
  }
  .btn:hover { background: var(--sp-surface-hover); border-color: var(--sp-border); }
  .btn:focus-visible { outline: 2px solid var(--sp-down); outline-offset: 2px; }
  .btn.primary { background: color-mix(in srgb, var(--sp-down) 24%, transparent); border-color: color-mix(in srgb, var(--sp-down) 50%, transparent); }
  .btn.danger { color: var(--sp-bad); border-color: color-mix(in srgb, var(--sp-bad) 40%, transparent); }
  .btn:disabled { opacity: .5; cursor: default; }
  .input, .select {
    appearance: none; width: 100%; background: rgba(0,0,0,.22); color: var(--sp-text);
    border: 1px solid var(--sp-border); border-radius: 8px; padding: 6px 9px; font-size: 12px;
    font-family: inherit; min-height: 30px;
  }
  :host([data-theme="light"]) .input, :host([data-theme="light"]) .select { background: rgba(255,255,255,.7); }
  .input:focus, .select:focus { outline: none; border-color: var(--sp-down); }
  .input::placeholder { color: var(--sp-faint); }
  .label { font-size: 11px; color: var(--sp-muted); margin-bottom: 3px; display: block; }
  .sep { height: 1px; background: var(--sp-border-soft); margin: 10px 0; }
  .scroll { overflow: auto; scrollbar-width: thin; scrollbar-color: rgba(255,255,255,.22) transparent; }
  .scroll::-webkit-scrollbar { width: 6px; height: 6px; }
  .scroll::-webkit-scrollbar-thumb { background: rgba(255,255,255,.2); border-radius: 3px; }
  .table { width: 100%; border-collapse: collapse; font-size: 12px; }
  .table th { text-align: left; font-weight: 500; color: var(--sp-muted); font-size: 11px; padding: 6px 8px; border-bottom: 1px solid var(--sp-border-soft); white-space: nowrap; }
  .table td { padding: 6px 8px; border-bottom: 1px solid var(--sp-border-soft); vertical-align: middle; }
  .table tr:hover td { background: var(--sp-surface); }
  .table .right { text-align: right; }
  .empty { color: var(--sp-faint); font-size: 12px; padding: 14px 4px; text-align: center; }
  .banner {
    display: flex; align-items: flex-start; gap: 8px; padding: 8px 10px;
    border: 1px solid color-mix(in srgb, var(--sp-warn) 35%, transparent);
    background: color-mix(in srgb, var(--sp-warn) 10%, transparent);
    border-radius: 10px; color: var(--sp-text); font-size: 12px;
  }
  .banner.bad { border-color: color-mix(in srgb, var(--sp-bad) 40%, transparent); background: color-mix(in srgb, var(--sp-bad) 10%, transparent); }
  .skeleton {
    background: linear-gradient(90deg, rgba(255,255,255,.06), rgba(255,255,255,.12), rgba(255,255,255,.06));
    background-size: 200% 100%; animation: shimmer 1.4s ease infinite; border-radius: 6px;
  }
  @keyframes shimmer { to { background-position: -200% 0; } }

  /* dependency-free chart primitives (widget + dashboard) */
  .chart { position: relative; width: 100%; min-width: 0; }
  .chart svg { display: block; width: 100%; height: 100%; overflow: visible; }
  .chart-empty {
    display: flex; align-items: center; justify-content: center;
    color: var(--sp-faint); font-size: 10px;
    border: 1px dashed var(--sp-border-soft); border-radius: 7px;
    background: rgba(255,255,255,.015);
  }
  .blocks { display: flex; gap: 2px; height: 9px; width: 100%; margin-top: 4px; }
  .block { flex: 1 1 0; min-width: 1px; border-radius: 2px; background: rgba(255,255,255,.12); }
  .block.ok { background: var(--sp-ok); }
  .block.warn { background: var(--sp-warn); }
  .block.bad { background: var(--sp-bad); }
  .block.unknown { background: rgba(255,255,255,.12); }
  .span-all { grid-column: 1 / -1; min-width: 0; }

  @media (prefers-reduced-motion: reduce) {
    .skeleton { animation: none; }
    .btn { transition: none; }
  }
`;
function ca(i) {
  const t = i.match(/^rgba?\(\s*([\d.]+)[,\s]+([\d.]+)[,\s]+([\d.]+)(?:\s*[,/]\s*([\d.%]+))?\s*\)$/i);
  if (!t) return null;
  let e = 1;
  return t[4] !== void 0 && (e = t[4].endsWith("%") ? Number(t[4].slice(0, -1)) / 100 : Number(t[4])), { r: Number(t[1]), g: Number(t[2]), b: Number(t[3]), a: Number.isFinite(e) ? e : 1 };
}
function pa({ r: i, g: t, b: e }) {
  const s = (n) => {
    const a = n / 255;
    return a <= 0.03928 ? a / 12.92 : Math.pow((a + 0.055) / 1.055, 2.4);
  };
  return 0.2126 * s(i) + 0.7152 * s(t) + 0.0722 * s(e);
}
function ua(i, t) {
  if (typeof window > "u" || typeof getComputedStyle != "function") return t;
  let e = i ?? null;
  for (let s = 0; e && s < 8; s++) {
    try {
      const n = getComputedStyle(e), a = n.backgroundColor;
      if (a && a !== "transparent") {
        const r = ca(a);
        if (r && r.a >= 0.15)
          return pa(r) < 0.45;
      }
      n.backgroundImage && n.backgroundImage !== "none" && n.backgroundImage.startsWith("linear-gradient");
    } catch {
    }
    e = e.parentElement;
  }
  return t;
}
function ue(i, t, e) {
  return i === "dark" ? "dark" : i === "light" ? "light" : ua(e, t) ? "dark" : "light";
}
function y(i) {
  switch (i) {
    case "gateway":
    case "router":
      return l`<svg class="ic" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><rect x="3" y="11" width="18" height="8" rx="2"/><path d="M7 15h.01M11 15h.01M7 7l3 3M17 7l-3 3M7 7V4M17 7V4"/></svg>`;
    case "switch":
      return l`<svg class="ic" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><rect x="3" y="6" width="18" height="12" rx="2"/><path d="M7 10h.01M11 10h.01M15 10h.01M7 14h10"/></svg>`;
    case "ap":
      return l`<svg class="ic" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><circle cx="12" cy="12" r="2.2"/><path d="M8.5 8.5a5 5 0 0 0 0 7M15.5 8.5a5 5 0 0 1 0 7M5.5 5.5a9 9 0 0 0 0 13M18.5 5.5a9 9 0 0 1 0 13"/></svg>`;
    case "wired":
      return l`<svg class="ic" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><rect x="3" y="9" width="10" height="7" rx="1.5"/><path d="M13 12h4a3 3 0 0 0 3-3V6M6 9V6h4v3M8 16v3"/></svg>`;
    case "wifi":
      return l`<svg class="ic" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M2.5 8.5a15 15 0 0 1 19 0M5.5 12a10.5 10.5 0 0 1 13 0M8.5 15.5a6 6 0 0 1 7 0"/><circle cx="12" cy="19" r="1"/></svg>`;
    case "download":
      return l`<svg class="ic" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M12 3v12M7 10l5 5 5-5M4 20h16"/></svg>`;
    case "upload":
      return l`<svg class="ic" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M12 21V9M7 14l5-5 5 5M4 4h16"/></svg>`;
    case "globe":
      return l`<svg class="ic" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><circle cx="12" cy="12" r="9"/><path d="M3 12h18M12 3a15 15 0 0 1 0 18M12 3a15 15 0 0 0 0 18"/></svg>`;
    case "activity":
      return l`<svg class="ic" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M3 12h4l2.5-7 5 14 2.5-7h4"/></svg>`;
    case "thermometer":
      return l`<svg class="ic" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M10 14.5V5a2 2 0 1 1 4 0v9.5a4 4 0 1 1-4 0Z"/><path d="M12 9v7"/></svg>`;
    case "cpu":
      return l`<svg class="ic" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><rect x="6" y="6" width="12" height="12" rx="2"/><rect x="9" y="9" width="6" height="6" rx="1"/><path d="M9 2v4M15 2v4M9 18v4M15 18v4M2 9h4M2 15h4M18 9h4M18 15h4"/></svg>`;
    case "memory":
      return l`<svg class="ic" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><rect x="3" y="7" width="18" height="10" rx="1.5"/><path d="M7 11v2M11 11v2M15 11v2M5 17v2M9 17v2M13 17v2M17 17v2"/></svg>`;
    case "clock":
      return l`<svg class="ic" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 2"/></svg>`;
    case "refresh":
      return l`<svg class="ic" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M20 12a8 8 0 1 1-2.34-5.66M20 4v5h-5"/></svg>`;
    case "settings":
      return l`<svg class="ic" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><circle cx="12" cy="12" r="3"/><path d="M19.4 15a1.7 1.7 0 0 0 .34 1.88l.06.06a2 2 0 1 1-2.83 2.83l-.06-.06A1.7 1.7 0 0 0 15 19.4a1.7 1.7 0 0 0-1 1.55V21a2 2 0 1 1-4 0v-.09A1.7 1.7 0 0 0 9 19.4a1.7 1.7 0 0 0-1.88.34l-.06.06a2 2 0 1 1-2.83-2.83l.06-.06A1.7 1.7 0 0 0 4.6 15a1.7 1.7 0 0 0-1.55-1H3a2 2 0 1 1 0-4h.09A1.7 1.7 0 0 0 4.6 9a1.7 1.7 0 0 0-.34-1.88l-.06-.06a2 2 0 1 1 2.83-2.83l.06.06A1.7 1.7 0 0 0 9 4.6 1.7 1.7 0 0 0 10 3.05V3a2 2 0 1 1 4 0v.09A1.7 1.7 0 0 0 15 4.6a1.7 1.7 0 0 0 1.88-.34l.06-.06a2 2 0 1 1 2.83 2.83l-.06.06A1.7 1.7 0 0 0 19.4 9c.12.34.4.62.73.75H21a2 2 0 1 1 0 4h-.09c-.34.12-.62.4-.75.73Z"/></svg>`;
    case "warning":
      return l`<svg class="ic" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M12 3 2.5 20h19L12 3Z"/><path d="M12 9v5M12 17.5h.01"/></svg>`;
    case "check":
      return l`<svg class="ic" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="m4 12.5 5 5L20 6.5"/></svg>`;
    case "search":
      return l`<svg class="ic" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><circle cx="11" cy="11" r="7"/><path d="m16.5 16.5 4 4"/></svg>`;
    case "eye":
      return l`<svg class="ic" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M2 12s3.5-6 10-6 10 6 10 6-3.5 6-10 6-10-6-10-6Z"/><circle cx="12" cy="12" r="2.5"/></svg>`;
    case "eyeOff":
      return l`<svg class="ic" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M3 3l18 18M10.6 6.2A10.8 10.8 0 0 1 12 6c6.5 0 10 6 10 6a17 17 0 0 1-3 3.6M6.4 6.5A17 17 0 0 0 2 12s3.5 6 10 6a10 10 0 0 0 4-.8"/><path d="M9.9 9.9a3 3 0 0 0 4.2 4.2"/></svg>`;
    case "external":
      return l`<svg class="ic" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M14 4h6v6M20 4l-9 9M18 14v5a1 1 0 0 1-1 1H5a1 1 0 0 1-1-1V7a1 1 0 0 1 1-1h5"/></svg>`;
    case "shield":
      return l`<svg class="ic" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M12 3 5 6v5c0 4.5 3 8 7 10 4-2 7-5.5 7-10V6l-7-3Z"/><path d="m9 12 2 2 4-4"/></svg>`;
    case "bolt":
      return l`<svg class="ic" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M13 2 4 14h6l-1 8 9-12h-6l1-8Z"/></svg>`;
    case "signal":
      return l`<svg class="ic" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M4 20v-3M9 20v-6M14 20v-9M19 20V7"/></svg>`;
    case "chevron":
      return l`<svg class="ic" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="m9 6 6 6-6 6"/></svg>`;
    case "info":
      return l`<svg class="ic" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><circle cx="12" cy="12" r="9"/><path d="M12 11v5M12 8h.01"/></svg>`;
    case "close":
      return l`<svg class="ic" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M6 6l12 12M18 6 6 18"/></svg>`;
    case "link":
      return l`<svg class="ic" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M10 13a5 5 0 0 0 7 0l2-2a5 5 0 0 0-7-7l-1 1"/><path d="M14 11a5 5 0 0 0-7 0l-2 2a5 5 0 0 0 7 7l1-1"/></svg>`;
    default:
      return l`<svg class="ic" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><circle cx="12" cy="12" r="9"/></svg>`;
  }
}
let ha = 0;
function fa(i, t = 120) {
  if (i.length <= t) return i;
  const e = Math.ceil(i.length / t), s = [];
  for (let n = 0; n < i.length; n += e) s.push(i[n]);
  return s[s.length - 1] !== i[i.length - 1] && s.push(i[i.length - 1]), s;
}
function ga(i) {
  let t = 0;
  for (const e of i) for (const s of e.values) typeof s == "number" && Number.isFinite(s) && s > t && (t = s);
  return t;
}
function ma(i, t) {
  const e = i.length;
  if (!e) return "";
  const s = 100, n = 100, a = e > 1 ? s / (e - 1) : s, r = 6;
  let u = "", o = !1;
  for (let d = 0; d < e; d++) {
    const c = i[d];
    if (typeof c != "number" || !Number.isFinite(c)) {
      o = !1;
      continue;
    }
    const p = e > 1 ? d * a : s, g = n - r - Math.max(0, Math.min(1, c / t)) * (n - r * 2);
    u += `${o ? "L" : "M"}${p.toFixed(2)},${g.toFixed(2)}`, o = !0;
  }
  return u;
}
function va(i, t) {
  const e = i.length;
  if (!e) return "";
  const s = 100, n = 100, a = e > 1 ? s / (e - 1) : s, r = 6;
  let u = -1, o = -1, d = "";
  for (let c = 0; c < e; c++) {
    const p = i[c];
    if (typeof p != "number" || !Number.isFinite(p)) continue;
    const g = e > 1 ? c * a : s, m = n - r - Math.max(0, Math.min(1, p / t)) * (n - r * 2);
    u < 0 ? (u = g, d = `M${g.toFixed(2)},${m.toFixed(2)}`) : d += `L${g.toFixed(2)},${m.toFixed(2)}`, o = g;
  }
  return u < 0 || o < 0 ? "" : `${d}L${o.toFixed(2)},${n}L${u.toFixed(2)},${n}Z`;
}
function kt(i, t = {}) {
  const e = i.map((c) => ({ ...c, values: fa(c.values) })), s = Math.max(t.minMax ?? 0, ga(e)) || 1, n = `ug${++ha}`, a = e.some((c) => c.values.some((p) => typeof p == "number" && Number.isFinite(p))), r = t.height ?? 46;
  if (!a)
    return l`<div class="chart-empty" style=${`height:${r}px`}>收集中…</div>`;
  const u = st`${[25, 50, 75].map((c) => st`<line x1="0" y1=${c} x2="100" y2=${c} style="stroke:var(--sp-border-soft)" stroke-width="0.5" vector-effect="non-scaling-stroke"></line>`)}`, o = st`${e.map((c) => c.fill ? st`<path d=${va(c.values, s)} fill=${`url(#${n})`} stroke="none"></path>` : "")}`, d = st`${e.map((c) => st`<path d=${ma(c.values, s)} fill="none" style=${`stroke:${c.color}`} stroke-width="1.6" stroke-linejoin="round" stroke-linecap="round" vector-effect="non-scaling-stroke"></path>`)}`;
  return l`
    <div class="chart" style=${`height:${r}px`} role="img" aria-label=${t.ariaLabel ?? "趋势图"}>
      <svg viewBox="0 0 100 100" preserveAspectRatio="none" aria-hidden="true">
        ${st`<defs><linearGradient id=${n} x1="0" y1="0" x2="0" y2="1">
          <stop offset="0%" style="stop-color:var(--sp-down)" stop-opacity="0.30"></stop>
          <stop offset="100%" style="stop-color:var(--sp-down)" stop-opacity="0"></stop>
        </linearGradient></defs>`}
        ${u}
        ${o}
        ${d}
      </svg>
    </div>
  `;
}
function wa(i, t = 60) {
  const e = [...i];
  for (; e.length < t; ) e.unshift(null);
  const s = e.slice(-t);
  return l`
    <div class="blocks" role="img" aria-label="线路可用性历史">
      ${s.map((n) => n ? n.online === !1 ? l`<span class="block bad"></span>` : n.latencyMs !== null && n.latencyMs > 150 ? l`<span class="block warn"></span>` : n.online === !0 ? l`<span class="block ok"></span>` : l`<span class="block unknown"></span>` : l`<span class="block unknown"></span>`)}
    </div>
  `;
}
function U(i) {
  return i === !0 ? "ok" : i === !1 ? "bad" : "";
}
function oi(i) {
  return i === !0 ? "在线" : i === !1 ? "离线" : "未知";
}
function qe(i) {
  if (!i) return "";
  switch (i.kind) {
    case "config":
      return i.message || "配置不完整";
    case "auth":
      return "API Key 无效或已失效";
    case "permission":
      return "权限不足或网络白名单不允许";
    case "tls":
      return "HTTPS 证书校验失败";
    case "dns":
      return "无法解析网关主机名";
    case "network":
      return "无法连接到 UniFi 网关";
    case "timeout":
      return "请求超时";
    case "proxy":
      return "Sun-Panel 网络代理错误";
    case "html":
      return "网关返回了 HTML 页面";
    case "rate-limit":
      return "请求被限流";
    case "not-found":
      return "站点或接口不存在";
    case "upstream":
      return "UniFi 服务暂时不可用";
    case "json":
      return "响应解析失败";
    default:
      return i.message || "未知错误";
  }
}
function li(i) {
  if (!i) return "";
  switch (i.kind) {
    case "tls":
      return "Sun-Panel 代理无法校验 UCG 的自签名证书。请让容器信任该证书，并使用证书里的 unifi.local 主机名（详见 docs/INSTALL.md）。不要关闭全局证书校验。";
    case "auth":
      return "在 UniFi → Integrations 创建新的 API Key，然后在设置中重新保存。";
    case "permission":
      return "确认 API Key 具有读取权限，且微应用 networkDomains 允许访问该网关。";
    case "dns":
      return "检查网关地址是否正确；自签名证书场景请使用 unifi.local 并在容器内添加主机映射。";
    case "network":
      return "检查 UCG 地址、端口、防火墙与局域网连通性。";
    case "timeout":
      return "网关响应较慢，应用会自动退避重试。";
    case "config":
      return "打开设置，填写网关地址并保存 API Key。";
    default:
      return "应用会保留上次成功数据并自动重试。";
  }
}
function R(i) {
  return i.name || `WAN${i.slot}`;
}
function ba(i) {
  if (!i) return { rx: null, tx: null };
  let t = null, e = null;
  for (const s of i.wans)
    s.rxBps !== null && (t = (t ?? 0) + s.rxBps), s.txBps !== null && (e = (e ?? 0) + s.txBps);
  return { rx: t, tx: e };
}
function It(i) {
  if (!i) return { usedW: null, budgetW: null };
  let t = null, e = null;
  for (const s of i.switches)
    s.poeUsedW !== null && (t = (t ?? 0) + s.poeUsedW), s.poeBudgetW !== null && (e = (e ?? 0) + s.poeBudgetW);
  return { usedW: t, budgetW: e };
}
function te(i) {
  const t = i?.gateway?.temperatures ?? [];
  return t.length ? t.find((s) => /cpu/i.test(s.name) || /cpu/i.test(s.type))?.celsius ?? Math.max(...t.map((s) => s.celsius)) : null;
}
function Wt(i, t, e = 180) {
  return i.filter((s) => s.wanId === t).slice(-e);
}
function xa(i, t, e = 60) {
  return Wt(i, t, e).map((n) => ({ online: n.online, latencyMs: n.latencyMs }));
}
function ya(i, t) {
  const e = Wt(i, t, 180);
  let s = 0, n = 0, a = !1, r = 0;
  for (let u = 1; u < e.length; u++) {
    const o = e[u - 1], d = e[u], c = (d.t - o.t) / 1e3;
    !Number.isFinite(c) || c <= 0 || c > 60 || (o.rxBps !== null && d.rxBps !== null && (s += (o.rxBps + d.rxBps) / 2 * c, a = !0), o.txBps !== null && d.txBps !== null && (n += (o.txBps + d.txBps) / 2 * c, a = !0), r += c);
  }
  return { rxBytes: a ? s : null, txBytes: a ? n : null, seconds: r };
}
function $a(i, t) {
  return i ? i.speedtests.filter((s) => !!(t.portName && s.interfaceName === t.portName || t.networkGroup && s.wanNetworkGroup === t.networkGroup))[0] ?? null : null;
}
const Ns = [
  { id: "overview", label: "概览" },
  { id: "wan", label: "WAN" },
  { id: "gateway", label: "网关" },
  { id: "switch", label: "交换机" },
  { id: "ap", label: "AP" },
  { id: "clients", label: "客户端" },
  { id: "topology", label: "拓扑" }
], Ve = class Ve extends le {
  constructor() {
    super(...arguments), this.store = null, this.unsub = null, this.state = null, this.inited = !1, this.tab = "overview", this.clientSearch = "", this.clientFilter = "all", this.clientSort = "rate", this.selectedSwitchMac = null, this.selectedApMac = null, this.selectedPort = null, this.showSpeedtestHistory = !1, this.speedtestWan = "all", this.speedtestFrom = "", this.speedtestTo = "", this.speedtestPage = 0, this.speedtestSort = "desc", this.initialTabApplied = !1;
  }
  onInitialized(t) {
    this.tryInit();
    const e = t?.customParam?.tab;
    e && Ns.some((s) => s.id === e) && (this.tab = e);
  }
  updated(t) {
    super.updated(t), t?.has?.("spCtx") && this.tryInit(), this.applyTheme();
  }
  tryInit() {
    if (this.inited) return;
    const t = this.spCtx?.api;
    !t || !t.network || !t.timer || (this.inited = !0, this.store = Dt(), this.store.attach(t), this.unsub = this.store.subscribe((e) => {
      this.state = e, this.tab === "overview" && e.settings.defaultTab && !this.initialTabApplied && (this.tab = e.settings.defaultTab), this.initialTabApplied = !0, this.applyTheme(), this.requestUpdate();
    }));
  }
  onDisconnected() {
    this.unsub?.(), this.unsub = null, this.store && this.spCtx?.api && this.store.detach(this.spCtx.api), this.store = null, this.inited = !1;
  }
  applyTheme() {
    const t = this.state?.settings.theme ?? "auto", e = ue(t, this.spCtx?.darkMode !== !1, this.parentElement);
    this.setAttribute("data-theme", e);
  }
  settings() {
    return this.state?.settings ?? Dt().getState().settings;
  }
  ip(t) {
    return this.settings().maskIp ? Le(t) : t ?? "—";
  }
  cname(t) {
    return ei(t.name ?? t.hostname, t.mac, this.settings().hideClientNames);
  }
  rate(t, e) {
    const s = z(t, this.settings().showBits);
    return l`<span class="rate ${e}">${y(e === "down" ? "download" : "upload")}<b class="num">${s.value}</b><span class="u">${s.unit}</span></span>`;
  }
  openSettings() {
    try {
      this.spCtx.api.window.open({
        componentName: "unifi-settings",
        title: "UniFi 监控设置",
        customParam: { mode: "app" },
        windowConfig: { width: 760, height: 780, showFullscreenBtn: !1, resize: !0, move: !0 }
      });
    } catch {
    }
  }
  setTab(t) {
    this.tab = t, this.store?.setActiveTab(t), this.requestUpdate();
  }
  openClient(t) {
    try {
      this.spCtx.api.window.open({
        componentName: "unifi-client-detail",
        title: "客户端详情",
        customParam: { clientId: t.id },
        windowConfig: { width: 760, height: 760, showFullscreenBtn: !0, resize: !0, move: !0, background: "#0f1015", backgroundDark: "#0f1015", headerTextColor: "#ffffff", headerTextColorDark: "#ffffff" }
      });
    } catch {
    }
  }
  openSpeedtest(t = "all") {
    this.showSpeedtestHistory = !0, this.speedtestWan = t, this.speedtestPage = 0, this.requestUpdate();
  }
  speedtestWanOptions() {
    const t = this.state?.snapshot, e = /* @__PURE__ */ new Map();
    for (const s of t?.wans ?? []) {
      const n = s.networkGroup ?? s.portName;
      n && e.set(n, `${R(s)} · ${s.operator ?? "未知"}`);
    }
    for (const s of t?.speedtests ?? []) {
      const n = s.wanNetworkGroup ?? s.interfaceName;
      n && !e.has(n) && e.set(n, n);
    }
    return [...e.entries()].map(([s, n]) => ({ value: s, label: n }));
  }
  filteredSpeedtests() {
    const t = this.state?.snapshot?.speedtests ?? [], e = this.speedtestFrom ? (/* @__PURE__ */ new Date(`${this.speedtestFrom}T00:00:00`)).getTime() : null, s = this.speedtestTo ? (/* @__PURE__ */ new Date(`${this.speedtestTo}T23:59:59.999`)).getTime() : null;
    return t.filter((n) => this.speedtestWan === "all" || n.wanNetworkGroup === this.speedtestWan || n.interfaceName === this.speedtestWan).filter((n) => e === null || n.time >= e).filter((n) => s === null || n.time <= s).sort((n, a) => this.speedtestSort === "asc" ? n.time - a.time : a.time - n.time);
  }
  card(t, e, s) {
    return l`
      <section class="card">
        <div class="card-hd"><h3>${t}</h3><div class="row">${s ?? v}</div></div>
        ${e}
      </section>
    `;
  }
  cap(t) {
    return this.state?.snapshot?.capabilities[t] ?? { supported: !1, reason: "暂无能力信息" };
  }
  statusDot(t) {
    return l`<span class="dot ${U(t)}" title=${oi(t)}></span>`;
  }
  // ------------------------------------------------------------------ header
  renderHeader() {
    const t = this.state?.snapshot, e = t?.wans ?? [], s = e.some((a) => a.online === !0), n = this.state?.loading;
    return l`
      <header class="head">
        <div class="head-left">
          <span class="logo">${y("router")}</span>
          <div class="col" style="gap:1px">
            <div class="row" style="gap:7px">
              <h1>UniFi 网络监控</h1>
              ${t ? l`<span class="badge ${s ? "ok" : e.length ? "bad" : ""}">${s ? "在线" : e.length ? "异常" : "未连接"}</span>` : ""}
              ${this.state?.stale && t ? l`<span class="badge warn">陈旧数据</span>` : ""}
            </div>
            <div class="sub muted">
              ${t?.gateway ? t.gateway.model === t.gateway.name ? t.gateway.model : `${t.gateway.model} · ${t.gateway.name}` : this.settings().host}
              ${t?.site ? l` · 站点 ${t.site.name}` : v}
            </div>
          </div>
        </div>
        <div class="head-right">
          <span class="muted updated" title=${t ? B(t.fetchedAt) : ""}>
            ${t ? `更新于 ${Z(t.fetchedAt)}` : "等待数据"}
          </span>
          <button class="btn" title="立即刷新" ?disabled=${n} @click=${() => void this.store?.refreshAll(!0)}>
            ${y("refresh")} ${n ? "刷新中" : "刷新"}
          </button>
          <button class="btn" title="设置" @click=${() => this.openSettings()}>${y("settings")} 设置</button>
        </div>
      </header>
    `;
  }
  renderTabs() {
    const t = this.state?.snapshot, e = t?.counts;
    return l`
      <nav class="tabs" role="tablist">
        ${Ns.map((s) => {
      const n = s.id === "wan" && t ? `WAN (${t.wans.length})` : s.id === "clients" && e?.clientsTotal !== null && e?.clientsTotal !== void 0 ? `客户端 ${e.clientsTotal}` : s.label;
      return l`<button class="tab ${this.tab === s.id ? "active" : ""}" role="tab" aria-selected=${this.tab === s.id ? "true" : "false"} @click=${() => this.setTab(s.id)}>${n}</button>`;
    })}
      </nav>
    `;
  }
  renderBanner() {
    const t = this.state?.lastError;
    if (!t) return v;
    const e = !!this.state?.snapshot;
    return l`
      <div class="banner ${e ? "" : "bad"}">
        ${y("warning")}
        <div class="grow">
          <div><b>${qe(t)}</b>${e ? l`<span class="muted"> · 当前显示上次成功数据</span>` : ""}</div>
          <div class="muted hint">${li(t)}</div>
        </div>
        ${e ? l`<button class="btn" @click=${() => void this.store?.refreshAll(!0)}>重试</button>` : l`<button class="btn primary" @click=${() => this.openSettings()}>打开设置</button>`}
      </div>
    `;
  }
  // ------------------------------------------------------------------ overview
  renderOverview() {
    const t = this.state?.snapshot;
    if (!t) return this.renderEmpty("尚无监控数据", "点击右上角“设置”配置网关与 API Key，或点击“刷新”。");
    const e = t.wans, s = It(t), n = te(t);
    return l`
      <div class="overview">
        <div class="ov-wans">
          ${e.map((a) => this.renderWanCard(a))}
          ${e.length ? v : this.renderEmpty("未发现 WAN 接口", "控制器没有返回 WAN 字段，或该接口不可用。")}
        </div>
        <div class="ov-grid">
          ${this.card("设备概览", l`
            <div class="dev-summary">
              ${this.deviceStat("gateway", "网关", t.counts.gatewayOnline, t.counts.gateway)}
              ${this.deviceStat("switch", "交换机", t.counts.switchOnline, t.counts.switch)}
              ${this.deviceStat("ap", "AP", t.counts.apOnline, t.counts.ap)}
            </div>
            <div class="sep"></div>
            <div class="between">
              <span class="muted">终端</span>
              <span class="row">
                <span class="badge">${y("wired")} 有线 ${t.counts.clientsWired ?? "—"}</span>
                <span class="badge">${y("wifi")} 无线 ${t.counts.clientsWireless ?? "—"}</span>
              </span>
            </div>
            <div class="ratio" title="有线 / 无线 终端比例">
              <span class="ratio-wired" style=${`width:${this.clientRatio()}%`}></span>
            </div>
          `)}
          ${this.card("网关", t.gateway ? l`
            <div class="kv"><span>型号</span><b>${t.gateway.model}</b></div>
            <div class="kv"><span>固件</span><b>${t.gateway.firmware ?? "—"}</b></div>
            <div class="kv"><span>Network</span><b>${t.gateway.networkVersion ?? "—"}</b></div>
            <div class="kv"><span>运行时间</span><b>${D(t.gateway.uptimeSec)}</b></div>
            <div class="bars">
              ${this.miniBar("CPU", t.gateway.cpuPct)}
              ${this.miniBar("内存", t.gateway.memPct)}
            </div>
            <div class="kv"><span>温度</span><b>${n !== null ? it(n) : "—"}</b></div>
            <div class="kv"><span>PoE 总计</span><b>${s.usedW !== null ? `${_(s.usedW, 1)} / ${s.budgetW !== null ? _(s.budgetW, 0) : "—"} W` : "—"}</b></div>
          ` : this.renderEmpty("未发现网关", "设备统计中没有 UDM/UCG/USG 类型设备。"))}
          ${this.card("AP 与交换机", l`
            <div class="mini-list">
              ${t.aps.slice(0, 4).map((a) => l`
                <div class="mini-row">
                  ${this.statusDot(a.online)}
                  <span class="grow truncate">${a.name}</span>
                  <span class="muted">${a.clientCount !== null ? `${a.clientCount} 终端` : "—"}</span>
                  <span class="faint">${a.radios.map((r) => r.band).join("/") || "—"}</span>
                </div>
              `)}
              ${t.switches.slice(0, 2).map((a) => l`
                <div class="mini-row">
                  ${this.statusDot(a.online)}
                  <span class="grow truncate">${a.name}</span>
                  <span class="muted">${a.ports.filter((r) => r.up).length}/${a.ports.length} 端口</span>
                  <span class="faint">${a.poeUsedW !== null ? `${_(a.poeUsedW, 1)}W` : "—"}</span>
                </div>
              `)}
              ${!t.aps.length && !t.switches.length ? l`<div class="empty">未发现 AP/交换机</div>` : v}
            </div>
          `)}
          <div class="span-all">${this.card("历史测速", this.renderSpeedtestTable(t.speedtests.slice(0, 4), !1), l`<span class="faint">只读 · 共 ${t.speedtests.length} 条</span><button class="btn" @click=${(a) => {
      a.stopPropagation(), this.openSpeedtest();
    }}>查看全部</button>`)}</div>
        </div>
      </div>
    `;
  }
  clientRatio() {
    const t = this.state?.snapshot?.counts;
    return !t || !t.clientsTotal ? 0 : Math.round((t.clientsWired ?? 0) / t.clientsTotal * 100);
  }
  deviceStat(t, e, s, n) {
    return l`
      <div class="dev-stat">
        <span class="dev-ic">${y(t)}</span>
        <div class="col" style="gap:0">
          <span class="muted">${e}</span>
          <b>${s ?? "—"}<span class="faint"> / ${n ?? "—"}</span></b>
        </div>
      </div>
    `;
  }
  miniBar(t, e) {
    const s = e === null ? 0 : Math.max(0, Math.min(100, e));
    return l`
      <div class="bar-line">
        <span class="muted">${t}</span>
        <div class="bar"><span style=${`width:${s}%`}></span></div>
        <b class="num">${e !== null ? Math.round(e) + "%" : "—"}</b>
      </div>
    `;
  }
  renderWanCard(t) {
    const e = Wt(this.state?.history ?? [], t.id, 60), s = Math.max(1, ...e.map((n) => (n.rxBps ?? 0) * 8));
    return l`
      <section class="card wan-card" @click=${() => this.setTab("wan")}>
        <div class="card-hd">
          <div class="row">
            ${this.statusDot(t.online)}
            <h3>${R(t)}</h3>
            <span class="muted ellipsis">${t.operator ?? "未知运营商"}</span>
            ${t.active ? l`<span class="badge ok">当前承载</span>` : t.role === "primary" ? l`<span class="badge">主用</span>` : l`<span class="badge">备用</span>`}
          </div>
          <span class="faint">${t.online === !0 ? "在线" : t.online === !1 ? "离线" : "状态未知"}</span>
        </div>
        <div class="wan-big">
          <div class="big"><span class="muted">${y("download")} 下载</span>${this.rate(t.rxBps, "down")}</div>
          <div class="big"><span class="muted">${y("upload")} 上传</span>${this.rate(t.txBps, "up")}</div>
        </div>
        ${kt([
      { values: e.map((n) => (n.rxBps ?? null) === null ? null : n.rxBps * 8), color: "var(--sp-down)", fill: !0 },
      { values: e.map((n) => (n.txBps ?? null) === null ? null : n.txBps * 8), color: "var(--sp-up)" }
    ], { height: 38, ariaLabel: `${R(t)} 最近速率`, minMax: s })}
        <div class="wan-foot">
          <span>${y("activity")} ${t.latencyMs !== null ? `${Math.round(t.latencyMs)} ms` : "延迟 —"}</span>
          <span>${t.availabilityPct !== null ? `可用率 ${I(t.availabilityPct)}` : "可用率 —"}</span>
          <span title="网口协商速率，不是宽带签约速率">${F(t.linkSpeedMbps)}</span>
          <span class="mono">${this.ip(t.ipv4)}</span>
        </div>
      </section>
    `;
  }
  // ------------------------------------------------------------------ WAN
  renderWan() {
    const t = this.state?.snapshot;
    return t ? t.wans.length ? l`
      <div class="wan-page">
        ${t.wans.map((e) => this.renderWanDetail(e))}
        <div class="note">
          ${y("info")}
          <span>“网口协商”是 WAN 口与光猫/交换机之间的链路速率，不等于运营商签约带宽；历史测速只读取控制器已有记录，应用不会主动测速。</span>
        </div>
      </div>
    ` : this.renderEmpty("未发现 WAN 接口", "控制器没有返回 WAN 字段。") : this.renderEmpty("尚无数据", "请先完成连接配置。");
  }
  renderWanDetail(t) {
    const e = this.state?.history ?? [], s = Wt(e, t.id, 120), n = Math.max(1, ...s.map((p) => (p.rxBps ?? 0) * 8)), a = ya(e, t.id), r = xa(e, t.id, 60), u = this.settings().fastIntervalSec, o = Math.max(1, Math.round(r.length * u / 60)), d = this.state?.snapshot?.speedtests.filter((p) => t.portName && p.interfaceName === t.portName || t.networkGroup && p.wanNetworkGroup === t.networkGroup) ?? [], c = t.qualityHistory ?? [];
    return l`
      <section class="card wan-detail">
        <div class="card-hd">
          <div class="row">
            ${this.statusDot(t.online)}
            <h3>${R(t)}</h3>
            <span class="muted">${t.operator ?? "未知运营商"}</span>
            ${t.active ? l`<span class="badge ok">当前承载</span>` : v}
            <span class="badge">${t.role === "primary" ? "主用（按设置）" : t.role === "backup" ? "备用（按设置）" : "角色未知"}</span>
          </div>
          <span class="mono muted">${t.id}</span>
        </div>
        <div class="wan-metrics">
          <div class="metric-lg"><span class="muted">下载</span>${this.rate(t.rxBps, "down")}</div>
          <div class="metric-lg"><span class="muted">上传</span>${this.rate(t.txBps, "up")}</div>
          <div class="metric-lg"><span class="muted">延迟</span><b class="num">${t.latencyMs !== null ? `${Math.round(t.latencyMs)} ms` : "—"}</b></div>
          <div class="metric-lg"><span class="muted">可用率</span><b class="num">${I(t.availabilityPct)}</b></div>
          <div class="metric-lg"><span class="muted" title=${this.cap("wanLoss").reason ?? ""}>丢包（5分钟）</span><b class="num">${t.lossPct !== null ? I(t.lossPct, 2) : "未获取"}</b></div>
          <div class="metric-lg"><span class="muted" title="网口协商速率，不是宽带签约速率">网口协商</span><b class="num">${F(t.linkSpeedMbps)}</b></div>
        </div>
        <div class="chart-box">
          <div class="between">
            <span class="muted">速率趋势（本应用采样）</span>
            <span class="row legend"><i class="sw down"></i>下载 <i class="sw up"></i>上传</span>
          </div>
          ${kt([
      { values: s.map((p) => p.rxBps === null ? null : p.rxBps * 8), color: "var(--sp-down)", fill: !0 },
      { values: s.map((p) => p.txBps === null ? null : p.txBps * 8), color: "var(--sp-up)" }
    ], { height: 96, minMax: n, ariaLabel: `${R(t)} 速率趋势` })}
        </div>
        <div class="kv-grid">
          <div class="kv"><span>WAN 接口</span><b class="mono">${t.portName ?? "—"} · ${t.id}</b></div>
          <div class="kv"><span>网络组</span><b>${t.networkGroup ?? "—"}</b></div>
          <div class="kv"><span>介质</span><b>${t.media ?? "—"}</b></div>
          <div class="kv"><span>IPv4</span><b class="mono">${this.ip(t.ipv4)}</b></div>
          <div class="kv"><span>IPv6</span><b class="mono">${t.ipv6 && t.ipv6.length ? this.settings().maskIp ? `${t.ipv6[0].split(":").slice(0, 2).join(":")}:••••` : t.ipv6[0] : "未下发"}</b></div>
          <div class="kv"><span>ASN</span><b>${t.asn !== null ? this.settings().showWanAsn ? String(t.asn) : "已隐藏（设置中开启）" : "—"}</b></div>
          <div class="kv"><span>WAN 运行时长</span><b>${D(t.uptimeSec)}</b></div>
          <div class="kv"><span>停机统计（次数）</span><b>${t.downtimeCount !== null ? String(t.downtimeCount) : "—"}</b></div>
          <div class="kv"><span>异常计数</span><b>${t.anomalies !== null ? String(t.anomalies) : "—"}</b></div>
          <div class="kv"><span>RX / TX 错误</span><b>${t.rxErrors !== null || t.txErrors !== null ? `${t.rxErrors ?? "—"} / ${t.txErrors ?? "—"}` : "—"}</b></div>
          <div class="kv"><span>RX / TX 丢弃</span><b>${t.rxDropped !== null || t.txDropped !== null ? `${t.rxDropped ?? "—"} / ${t.txDropped ?? "—"}` : "—"}</b></div>
          <div class="kv"><span>本次运行下载</span><b>${a.rxBytes !== null ? O(a.rxBytes) : "—"}</b></div>
          <div class="kv"><span>本次运行上传</span><b>${a.txBytes !== null ? O(a.txBytes) : "—"}</b></div>
        </div>
        <div class="sub-block">
          <div class="between"><span class="muted">控制器流量统计</span><span class="faint">按本地日/月边界 · 仅 WAN 侧</span></div>
          <div class="kv-grid">
            <div class="kv"><span>今日下载</span><b class="num">${O(t.todayRxBytes)}</b></div>
            <div class="kv"><span>今日上传</span><b class="num">${O(t.todayTxBytes)}</b></div>
            <div class="kv"><span>今日合计</span><b class="num">${O(t.todayTotalBytes)}</b></div>
            <div class="kv"><span>本月下载</span><b class="num">${O(t.monthRxBytes)}</b></div>
            <div class="kv"><span>本月上传</span><b class="num">${O(t.monthTxBytes)}</b></div>
            <div class="kv"><span>本月合计</span><b class="num">${O(t.monthTotalBytes)}</b></div>
          </div>
        </div>
        <div class="sub-block">
          <div class="between">
            <span class="muted">近 7 天线路质量</span>
            <span class="faint">${t.lossAvgPct != null ? `24h 丢包均值 ${I(t.lossAvgPct, 2)} · 峰值 ${I(t.lossPeakPct ?? null, 2)}` : "丢包序列未获取"}</span>
          </div>
          ${c.length ? l`
            ${kt([{ values: c.map((p) => p.lossPct), color: "var(--sp-warn)", fill: !0 }], { height: 54, minMax: Math.max(1, ...c.map((p) => p.lossPct ?? 0)), ariaLabel: `${R(t)} 近 7 天丢包` })}
            <div class="chips">
              <span class="chip">延迟 ${c.filter((p) => p.latencyMs !== null).length ? `${Math.min(...c.filter((p) => p.latencyMs !== null).map((p) => p.latencyMs))}–${Math.max(...c.filter((p) => p.latencyMs !== null).map((p) => p.latencyMs))} ms` : "—"}</span>
              <span class="chip">采样 ${c.length} 个控制器桶</span>
            </div>
          ` : l`<div class="empty">控制器未返回线路质量序列</div>`}
        </div>
        <div class="sub-block">
          <div class="between"><span class="muted">故障切换历史</span><span class="faint">近 7 天 · failover 标记（不是 downtime 次数）</span></div>
          ${this.renderFailoverHistory(t)}
        </div>
        <div class="sub-block">
          <div class="between"><span class="muted">线路可用性色块</span><span class="faint">最近 ${o} 分钟（本应用运行期间）</span></div>
          ${wa(r, 60)}
        </div>
        <div class="sub-block">
          <div class="between">
            <span class="muted">历史测速</span>
            <span class="row"><span class="faint">只读已有记录 · 共 ${d.length} 条</span><button class="btn" @click=${(p) => {
      p.stopPropagation(), this.openSpeedtest(t.networkGroup ?? t.portName ?? "all");
    }}>查看全部</button></span>
          </div>
          ${this.renderSpeedtestTable(d.slice(0, 8), !0)}
        </div>
        <div class="note">
          ${y("info")}
          <span>今日/本月流量来自 UniFi 控制台同源的 aggregated-dashboard（按本地日/月边界，仅 WAN 侧，不含 LAN 本地流量）；丢包为控制器 5 分钟桶均值，不代表可用率。上方“本次运行”仅为应用运行期间的采样积分。</span>
        </div>
      </section>
    `;
  }
  renderFailoverHistory(t) {
    const e = (this.state?.snapshot?.failoverHistory ?? []).filter((s) => {
      const n = t.networkGroup ?? t.name;
      return s.activeGroups.includes(n);
    });
    if (!e.length) {
      const s = this.state?.snapshot?.capabilities.wanFailoverHistory?.supported === !0;
      return l`<div class="empty">${s ? "近 7 天控制器未报告该 WAN 的 failover 标记" : "控制器 failover 历史未获取"}</div>`;
    }
    return l`
      <div class="between"><span class="faint">共 ${e.length} 次</span><span class="faint">最近 ${B(e[e.length - 1].at)}</span></div>
      <div class="chips">
        ${e.slice(-3).reverse().map((s) => l`<span class="chip">${B(s.at)}${s.end !== s.at ? `–${B(s.end)}` : ""} · ${s.activeGroups.join(" / ")} 接管</span>`)}
      </div>
    `;
  }
  renderSpeedtestTable(t, e) {
    return t.length ? l`
      <div class="table-wrap">
        <table class="table">
          <thead><tr><th>时间</th>${e ? l`<th>WAN</th>` : v}<th class="right">下载</th><th class="right">上传</th><th class="right">延迟</th></tr></thead>
          <tbody>
            ${t.map((s) => l`<tr>
              <td class="mono">${B(s.time)}</td>
              ${e ? l`<td class="mono">${s.wanNetworkGroup ?? s.interfaceName}</td>` : v}
              <td class="right num">${s.downloadMbps !== null ? `${_(s.downloadMbps, s.downloadMbps < 10 ? 1 : 0)} Mbps` : "—"}</td>
              <td class="right num">${s.uploadMbps !== null ? `${_(s.uploadMbps, s.uploadMbps < 10 ? 1 : 0)} Mbps` : "—"}</td>
              <td class="right num">${s.latencyMs !== null ? `${_(s.latencyMs, 0)} ms` : "—"}</td>
            </tr>`)}
          </tbody>
        </table>
      </div>
    ` : l`<div class="empty">暂无历史测速记录</div>`;
  }
  // ------------------------------------------------------------------ gateway
  renderGateway() {
    const t = this.state?.snapshot, e = t?.gateway;
    return e ? (It(t), l`
      <div class="detail-page">
        ${this.card("设备信息", l`
          <div class="kv-grid">
            <div class="kv"><span>名称</span><b>${e.name}</b></div>
            <div class="kv"><span>型号</span><b>${e.model}</b></div>
            <div class="kv"><span>IP</span><b class="mono">${this.ip(e.ip)}</b></div>
            <div class="kv"><span>状态</span><b>${e.online === !0 ? "在线" : e.online === !1 ? "离线" : "未知"}</b></div>
            <div class="kv"><span>UniFi OS</span><b>${e.osVersion ?? e.firmware ?? "—"}</b></div>
            <div class="kv"><span>Network</span><b>${e.networkVersion ?? "—"}</b></div>
            <div class="kv"><span>运行时间</span><b>${D(e.uptimeSec)}</b></div>
            <div class="kv"><span>固件更新</span><b>${e.updateAvailable === !0 ? "有可用更新" : e.updateAvailable === !1 ? "已是最新" : "未知"}</b></div>
            <div class="kv"><span>VPN</span><b>${t?.health.vpnStatus && t.health.vpnStatus !== "unknown" ? t.health.vpnStatus : "当前 REST 未获取（/stat/vpn 404；WS 未验证）"}</b></div>
            <div class="kv"><span>过温</span><b>${e.overheating === !0 ? "是" : e.overheating === !1 ? "否" : "—"}</b></div>
          </div>
        `)}
        ${this.card("资源", l`
          <div class="res-grid">
            <div class="res"><span class="muted">CPU</span><b class="num">${e.cpuPct !== null ? Math.round(e.cpuPct) + "%" : "—"}</b><div class="bar"><span style=${`width:${Math.max(0, Math.min(100, e.cpuPct ?? 0))}%`}></span></div></div>
            <div class="res"><span class="muted">内存</span><b class="num">${e.memPct !== null ? Math.round(e.memPct) + "%" : "—"}</b><div class="bar"><span style=${`width:${Math.max(0, Math.min(100, e.memPct ?? 0))}%`}></span></div></div>
            <div class="res"><span class="muted">负载 1/5/15</span><b class="num">${e.load1 !== null ? _(e.load1, 2) : "—"} / ${e.load5 !== null ? _(e.load5, 2) : "—"} / ${e.load15 !== null ? _(e.load15, 2) : "—"}</b></div>
            <div class="res"><span class="muted">PoE（网关）</span><b class="num">${e.poeUsedW !== null ? `${_(e.poeUsedW, 1)} / ${e.poeBudgetW !== null ? _(e.poeBudgetW, 0) : "—"} W` : "不支持"}</b></div>
          </div>
          <div class="sub-block">
            <span class="muted">温度</span>
            ${e.temperatures.length ? l`<div class="chips">${e.temperatures.map((s) => l`<span class="chip">${s.name} ${it(s.celsius)}</span>`)}</div>` : l`<div class="empty">控制器未提供温度传感器</div>`}
          </div>
          <div class="sub-block">
            <span class="muted">存储</span>
            ${e.storage.length ? e.storage.map((s) => l`
              <div class="bar-line">
                <span class="muted">${s.name} <span class="faint">${s.mountPoint}</span></span>
                <div class="bar"><span style=${`width:${s.totalBytes ? Math.min(100, (s.usedBytes ?? 0) / s.totalBytes * 100) : 0}%`}></span></div>
                <b class="num">${s.usedBytes !== null ? O(s.usedBytes) : "—"} / ${s.totalBytes !== null ? O(s.totalBytes) : "—"}</b>
              </div>
            `) : l`<div class="empty">未提供存储信息</div>`}
          </div>
        `)}
        ${this.card(`端口（${e.ports.filter((s) => s.up).length}/${e.ports.length} 在线）`, this.renderPorts(e.ports, "网关"))}
      </div>
    `) : this.renderEmpty("未发现网关", "设备统计中没有 UDM/UCG/USG 类型设备。");
  }
  // ------------------------------------------------------------------ switch
  renderSwitch() {
    const t = this.state?.snapshot;
    if (!t?.switches.length) return this.renderEmpty("未发现交换机", "设备统计中没有 USW 类型设备。");
    const e = t.switches.find((s) => s.mac === this.selectedSwitchMac) ?? t.switches[0];
    return l`
      <div class="detail-page">
        ${t.switches.length > 1 ? l`<div class="selector">${t.switches.map((s) => l`<button class="btn ${s.mac === e.mac ? "primary" : ""}" @click=${() => {
      this.selectedSwitchMac = s.mac, this.requestUpdate();
    }}>${s.name}</button>`)}</div>` : v}
        ${this.card("设备信息", l`
          <div class="kv-grid">
            <div class="kv"><span>名称</span><b>${e.name}</b></div>
            <div class="kv"><span>型号</span><b>${e.model}</b></div>
            <div class="kv"><span>IP</span><b class="mono">${this.ip(e.ip)}</b></div>
            <div class="kv"><span>状态</span><b>${e.online === !0 ? "在线" : e.online === !1 ? "离线" : "未知"}</b></div>
            <div class="kv"><span>固件</span><b>${e.firmware ?? "—"}</b></div>
            <div class="kv"><span>运行时间</span><b>${D(e.uptimeSec)}</b></div>
            <div class="kv"><span>端口</span><b>${e.ports.filter((s) => s.up).length} / ${e.ports.length} 在线</b></div>
            <div class="kv"><span>终端</span><b>${e.clientCount !== null ? String(e.clientCount) : "—"}</b></div>
            <div class="kv"><span>满意度</span><b>${e.satisfaction !== null && e.satisfaction >= 0 ? I(e.satisfaction) : e.satisfaction === -1 ? "该交换机无评分" : "当前接口未返回"}</b></div>
            <div class="kv"><span>风扇</span><b>${e.fanLevel !== null ? String(e.fanLevel) : "—"}</b></div>
            <div class="kv"><span>过温</span><b>${e.overheating === !0 ? "是" : e.overheating === !1 ? "否" : "—"}</b></div>
            <div class="kv"><span>PoE</span><b>${e.poeUsedW !== null ? `${_(e.poeUsedW, 1)} / ${e.poeBudgetW !== null ? _(e.poeBudgetW, 0) : "—"} W` : "—"}</b></div>
          </div>
          <div class="res-grid" style="margin-top:8px">
            <div class="res"><span class="muted">CPU</span><b class="num">${e.cpuPct !== null ? Math.round(e.cpuPct) + "%" : "—"}</b></div>
            <div class="res"><span class="muted">内存</span><b class="num">${e.memPct !== null ? Math.round(e.memPct) + "%" : "—"}</b></div>
            <div class="res"><span class="muted">负载 1/5/15</span><b class="num">${e.load1 !== null ? _(e.load1, 2) : "—"} / ${e.load5 !== null ? _(e.load5, 2) : "—"} / ${e.load15 !== null ? _(e.load15, 2) : "—"}</b></div>
            <div class="res"><span class="muted">一般温度</span><b class="num">${e.generalTemperature !== null ? it(e.generalTemperature) : e.temperatures.length ? it(Math.max(...e.temperatures.map((s) => s.celsius))) : "该设备未提供温度"}</b></div>
            <div class="res"><span class="muted">满意度</span><b class="num">${e.satisfaction !== null && e.satisfaction >= 0 ? I(e.satisfaction) : "当前接口未返回"}</b></div>
          </div>
        `)}
        ${this.card(`端口（${e.ports.filter((s) => s.up).length}/${e.ports.length}）`, this.renderPorts(e.ports, e.name))}
      </div>
    `;
  }
  // ------------------------------------------------------------------ AP
  renderAp() {
    const t = this.state?.snapshot;
    if (!t?.aps.length) return this.renderEmpty("未发现 AP", "设备统计中没有 UAP 类型设备。");
    const e = this.selectedApMac ? t.aps.find((n) => n.mac === this.selectedApMac) ?? null : null, s = e ? [e] : t.aps;
    return l`
      <div class="detail-page">
        ${t.aps.length > 1 ? l`<div class="selector"><button class="btn ${this.selectedApMac ? "" : "primary"}" @click=${() => {
      this.selectedApMac = null, this.requestUpdate();
    }}>全部</button>${t.aps.map((n) => l`<button class="btn ${n.mac === this.selectedApMac ? "primary" : ""}" @click=${() => {
      this.selectedApMac = n.mac, this.requestUpdate();
    }}>${n.name}</button>`)}</div>` : v}
        <div class="ap-grid">
          ${s.map((n) => this.renderApCard(n))}
        </div>
      </div>
    `;
  }
  renderApCard(t) {
    return this.card(t.name, l`
      <div class="kv-grid">
        <div class="kv"><span>型号</span><b>${t.model}</b></div>
        <div class="kv"><span>IP</span><b class="mono">${this.ip(t.ip)}</b></div>
        <div class="kv"><span>状态</span><b>${t.online === !0 ? "在线" : t.online === !1 ? "离线" : "未知"}</b></div>
        <div class="kv"><span>固件</span><b>${t.firmware ?? "—"}</b></div>
        <div class="kv"><span>运行时间</span><b>${D(t.uptimeSec)}</b></div>
        <div class="kv"><span>终端</span><b>${t.clientCount !== null ? String(t.clientCount) : "—"}</b></div>
        <div class="kv"><span>用户 / 访客</span><b>${t.userClients !== null || t.guestClients !== null ? `${t.userClients ?? "—"} / ${t.guestClients ?? "—"}` : "—"}</b></div>
        <div class="kv"><span>有线终端</span><b>${t.wiredClientCount !== null ? String(t.wiredClientCount) : "统计口径未返回"}</b></div>
        <div class="kv"><span>整体满意度</span><b>${t.satisfaction !== null && t.satisfaction >= 0 ? I(t.satisfaction) : t.satisfaction === -1 ? "该 AP 无评分" : "当前接口未返回"}</b></div>
        <div class="kv"><span>CPU</span><b>${t.cpuPct !== null ? Math.round(t.cpuPct) + "%" : "—"}</b></div>
        <div class="kv"><span>内存</span><b>${t.memPct !== null ? Math.round(t.memPct) + "%" : "—"}</b></div>
        <div class="kv wide"><span>负载 1/5/15</span><b>${t.load1 !== null ? _(t.load1, 2) : "—"} / ${t.load5 !== null ? _(t.load5, 2) : "—"} / ${t.load15 !== null ? _(t.load15, 2) : "—"}</b></div>
        <div class="kv"><span>温度</span><b>${t.temperatures.length ? it(Math.max(...t.temperatures.map((e) => e.celsius))) : "该设备未提供温度"}</b></div>
      </div>
      <div class="radio-grid">
        ${t.radios.length ? t.radios.map((e) => this.renderRadio(e)) : l`<div class="empty">未发现射频</div>`}
      </div>
    `);
  }
  renderRadio(t) {
    const e = t.utilizationPct;
    return t.state === "INIT" || t.channel === 0 && (t.clients ?? 0) === 0 && (t.txPower ?? 0) === 0 ? l`
        <div class="radio disabled">
          <div class="between">
            <span class="row"><span class="badge">${t.band === "unknown" ? "未知" : t.band + " GHz"}</span><b>${t.standard ?? ""}</b></span>
            <span class="badge">未启用</span>
          </div>
          <div class="muted" style="font-size:10px;margin-top:4px">该射频未广播（控制器返回 ${t.state ?? "INIT"}）</div>
        </div>
      ` : l`
      <div class="radio">
        <div class="between">
          <span class="row"><span class="badge">${t.band === "unknown" ? "未知" : t.band + " GHz"}</span><b>${t.standard ?? ""}</b></span>
          <span class="faint">${t.state ?? ""}</span>
        </div>
        <div class="kv"><span>信道 / 宽度</span><b class="num">${t.channel ?? "—"} / ${t.widthMhz !== null ? t.widthMhz + " MHz" : "—"}</b></div>
        <div class="kv"><span>终端</span><b class="num">${t.clients ?? "—"}</b></div>
        <div class="kv"><span>发送功率</span><b class="num">${t.txPower !== null ? t.txPower + " dBm" : "—"}</b></div>
        <div class="bar-line">
          <span class="muted">利用率</span>
          <div class="bar"><span style=${`width:${e !== null ? Math.max(0, Math.min(100, e)) : 0}%`}></span></div>
          <b class="num">${e !== null ? Math.round(e) + "%" : "不支持"}</b>
        </div>
        <div class="kv"><span>重传率</span><b class="num">${t.txRetriesPct !== null ? I(t.txRetriesPct) : "不支持"}</b></div>
        <div class="kv"><span>满意度</span><b class="num">${t.satisfaction !== null && t.satisfaction >= 0 ? String(t.satisfaction) : "该 radio 无评分"}</b></div>
        <div class="kv"><span>发送 / 重传包</span><b class="num">${t.txPackets !== null || t.txRetries !== null ? `${t.txPackets ?? "—"} / ${t.txRetries ?? "—"}` : "—"}</b></div>
        <div class="kv"><span>用户 / 访客终端</span><b class="num">${t.userClients !== null || t.guestClients !== null ? `${t.userClients ?? "—"} / ${t.guestClients ?? "—"}` : "—"}</b></div>
      </div>
    `;
  }
  // ------------------------------------------------------------------ clients
  filteredClients() {
    const t = this.state?.snapshot?.clients ?? [], e = this.clientSearch.trim().toLowerCase();
    let s = t.filter((n) => this.clientFilter === "wired" && !n.wired || this.clientFilter === "wireless" && n.wired || ["2.4", "5", "6"].includes(this.clientFilter) && n.band !== this.clientFilter ? !1 : e ? `${n.name ?? ""} ${n.hostname ?? ""} ${n.ip ?? ""} ${n.mac}`.toLowerCase().includes(e) : !0);
    return s = [...s].sort((n, a) => {
      switch (this.clientSort) {
        case "signal":
          return (a.signalDbm ?? -999) - (n.signalDbm ?? -999);
        case "name":
          return this.cname(n).localeCompare(this.cname(a));
        case "uptime":
          return (a.uptimeSec ?? -1) - (n.uptimeSec ?? -1);
        default:
          return (a.rxBps ?? 0) + (a.txBps ?? 0) - ((n.rxBps ?? 0) + (n.txBps ?? 0));
      }
    }), s.slice(0, 200);
  }
  renderClients() {
    const t = this.state?.snapshot;
    if (!t) return this.renderEmpty("尚无客户端数据", "请先完成连接配置。");
    const e = t.counts.clientsTotal, s = this.filteredClients();
    return l`
      <div class="detail-page">
        ${this.card("客户端", l`
          <div class="client-kpi">
            <div><span class="muted">总数</span><b>${e ?? "—"}</b></div>
            <div><span class="muted">有线</span><b>${t.counts.clientsWired ?? "—"}</b></div>
            <div><span class="muted">无线</span><b>${t.counts.clientsWireless ?? "—"}</b></div>
          </div>
          <div class="filters">
            <div class="search">
              ${y("search")}
              <input class="input" placeholder="搜索名称 / IP / MAC" .value=${this.clientSearch} @input=${(n) => {
      this.clientSearch = n.target.value, this.requestUpdate();
    }} />
            </div>
            <div class="chips">
              ${["all", "wired", "wireless", "2.4", "5", "6"].map((n) => l`<button class="btn ${this.clientFilter === n ? "primary" : ""}" @click=${() => {
      this.clientFilter = n, this.requestUpdate();
    }}>${n === "all" ? "全部" : n === "wired" ? "有线" : n === "wireless" ? "无线" : n + "G"}</button>`)}
            </div>
            <select class="select sort" .value=${this.clientSort} @change=${(n) => {
      this.clientSort = n.target.value, this.requestUpdate();
    }}>
              <option value="rate">按速率</option>
              <option value="signal">按信号</option>
              <option value="name">按名称</option>
              <option value="uptime">按在线时长</option>
            </select>
          </div>
          ${s.length ? l`
            <div class="table-wrap">
              <table class="table clients">
                <thead><tr><th>名称</th><th>类型</th><th>IP</th><th>上联</th><th class="right">下载</th><th class="right">上传</th><th class="right">信号</th><th>频段</th><th class="right">在线</th></tr></thead>
                <tbody>
                  ${s.map((n) => l`<tr class="clickable" title="点击查看客户端完整详情" @click=${() => this.openClient(n)}>
                    <td><span class="truncate" title=${n.name ?? n.mac}>${this.cname(n)}</span><div class="faint mono tiny">${n.mac}</div></td>
                    <td><span class="badge">${n.wired ? l`${y("wired")} 有线` : l`${y("wifi")} 无线`}</span></td>
                    <td class="mono">${this.ip(n.ip)}</td>
                    <td class="truncate" title=${n.uplinkName ?? ""}>${n.uplinkName ?? n.uplinkMac ?? "—"}</td>
                    <td class="right">${this.rate(n.rxBps, "down")}</td>
                    <td class="right">${this.rate(n.txBps, "up")}</td>
                    <td class="right num">${n.signalDbm !== null ? `${n.signalDbm} dBm` : "—"}</td>
                    <td>${n.wired || n.band === "unknown" ? "—" : n.band + "G"}${n.essid ? l`<div class="faint tiny truncate">${n.essid}</div>` : v}</td>
                    <td class="right num">${D(n.uptimeSec)}</td>
                  </tr>`)}
                </tbody>
              </table>
            </div>
            ${s.length >= 200 ? l`<div class="faint" style="margin-top:6px">仅显示前 200 个客户端</div>` : v}
          ` : l`<div class="empty">没有匹配的客户端</div>`}
        `)}
      </div>
    `;
  }
  // ------------------------------------------------------------------ topology
  renderTopology() {
    const t = this.state?.snapshot;
    if (!t) return this.renderEmpty("尚无拓扑数据", "请先完成连接配置。");
    const e = this.cap("topology");
    if (!e.supported) return this.renderEmpty("暂无可靠拓扑数据", e.reason ?? "控制器未返回上联关系，应用不会根据设备名称伪造连接。");
    const s = t.gateway, n = /* @__PURE__ */ new Map();
    s && n.set(s.mac, { name: s.name, mac: s.mac, model: s.model, online: s.online, ip: s.ip, kind: "gateway", parentPort: s.uplink.parentPort, parentSpeed: s.uplink.parentSpeedMbps, clientCount: t.clients.filter((d) => d.uplinkMac === s.mac).length });
    for (const d of t.switches) n.set(d.mac, { name: d.name, mac: d.mac, model: d.model, online: d.online, ip: d.ip, kind: "switch", parentPort: d.uplink.parentPort, parentSpeed: d.uplink.parentSpeedMbps, clientCount: d.clientCount ?? t.clients.filter((c) => c.uplinkMac === d.mac).length });
    for (const d of t.aps) n.set(d.mac, { name: d.name, mac: d.mac, model: d.model, online: d.online, ip: d.ip, kind: "ap", parentPort: d.uplink.parentPort, parentSpeed: d.uplink.parentSpeedMbps, clientCount: d.clientCount ?? t.clients.filter((c) => c.uplinkMac === d.mac).length });
    const a = /* @__PURE__ */ new Map(), r = [], u = (d, c) => {
      if (!d || !n.has(d)) {
        r.push(c);
        return;
      }
      const p = a.get(d) ?? [];
      p.push(c), a.set(d, p);
    };
    for (const d of t.switches) u(d.uplink.parentMac, d.mac);
    for (const d of t.aps) u(d.uplink.parentMac, d.mac);
    s && !r.includes(s.mac) && r.unshift(s.mac);
    const o = (d, c) => {
      const p = n.get(d);
      if (!p) return l``;
      const g = a.get(d) ?? [], m = t.clients.filter((h) => h.uplinkMac === d);
      return l`
        <div class="tree-node" style=${`padding-left:${c * 18}px`}>
          <div class="tree-row">
            ${c > 0 ? l`<span class="tree-line"></span>` : v}
            ${this.statusDot(p.online)}
            <span class="tree-ic">${y(p.kind === "gateway" ? "router" : p.kind)}</span>
            <b>${p.name}</b>
            <span class="faint truncate">${p.model}</span>
            <span class="mono faint">${this.ip(p.ip)}</span>
            ${p.parentPort !== null ? l`<span class="faint">· 上联端口 ${p.parentPort}</span>` : v}
            ${p.parentSpeed !== null ? l`<span class="faint">· ${F(p.parentSpeed)}</span>` : v}
            <span class="faint">· ${p.clientCount ?? "—"} 客户端</span>
          </div>
          ${g.map((h) => o(h, c + 1))}
          ${m.length ? l`
            <div class="tree-clients" style=${`padding-left:${(c + 1) * 18}px`}>
              ${m.map((h) => l`<span class="badge" title=${`${h.wired ? "有线" : "无线"}${h.uplinkPort !== null ? ` · 端口 ${h.uplinkPort}` : ""}`}><span class="dot ${h.wired ? "" : "ok"}"></span>${this.cname(h)}${h.uplinkPort !== null ? l` <span class="faint">:${h.uplinkPort}</span>` : v}</span>`)}
            </div>
          ` : v}
        </div>
      `;
    };
    return l`
      <div class="detail-page">
        ${this.card("网络拓扑（仅使用控制器返回的上联关系）", l`
          ${r.map((d) => o(d, 0))}
          ${r.length ? v : l`<div class="empty">未找到根节点</div>`}
          ${(() => {
      const d = t.clients.filter((c) => !c.uplinkMac || !n.has(c.uplinkMac));
      return d.length ? l`<div class="tree-node" style="padding-left:0">
              <div class="tree-row"><span class="faint">·</span><b>未知上联设备</b><span class="faint">${d.length} 个客户端（控制器未报告可解析的上联 MAC）</span></div>
              <div class="tree-clients" style="padding-left:18px">${d.map((c) => l`<span class="badge"><span class="dot ${c.wired ? "" : "ok"}"></span>${this.cname(c)}${c.uplinkPort !== null ? l` <span class="faint">:${c.uplinkPort}</span>` : v}</span>`)}</div>
            </div>` : v;
    })()}
        `)}
      </div>
    `;
  }
  // ------------------------------------------------------------------ ports
  renderPorts(t, e) {
    return t.length ? l`
      <div class="table-wrap">
        <table class="table ports">
          <thead><tr><th>#</th><th>端口</th><th>状态</th><th class="right">协商</th><th>介质</th><th class="right">PoE</th><th class="right">↓</th><th class="right">↑</th><th class="right">错包</th></tr></thead>
          <tbody>
            ${t.map((s) => l`<tr class="clickable" title="点击查看端口详情" @click=${() => {
      this.selectedPort = { port: s, device: e }, this.requestUpdate();
    }}>
              <td class="faint">${s.idx}</td>
              <td>${s.name}${s.isUplink ? l` <span class="badge">上联</span>` : v}</td>
              <td><span class="row"><span class="dot ${s.up ? "ok" : ""}"></span>${s.up ? "Up" : "Down"}</span></td>
              <td class="right num">${F(s.speedMbps)}</td>
              <td class="mono">${s.media ?? s.connector ?? "—"}</td>
              <td class="right num">${s.poe?.enabled ? s.poe.powerW !== null ? s.poe.powerW.toFixed(2) + " W" : "开启" : "—"}</td>
              <td class="right">${this.rate(s.rxBps, "down")}</td>
              <td class="right">${this.rate(s.txBps, "up")}</td>
              <td class="right num">${s.rxErrors !== null || s.txErrors !== null ? `${s.rxErrors ?? "—"} / ${s.txErrors ?? "—"}` : "—"}</td>
            </tr>`)}
          </tbody>
        </table>
        <div class="faint port-hint">点击任一行查看 STP、link_down_count、丢弃、PoE class/电压/电流、MAC 表数量与端口满意度。</div>
      </div>
    ` : l`<div class="empty">未提供端口信息</div>`;
  }
  // ------------------------------------------------------------------ empty
  renderPortModal() {
    const t = this.selectedPort;
    if (!t) return l``;
    const e = t.port, s = e.poe, n = (a) => {
      a.stopPropagation(), this.selectedPort = null, this.requestUpdate();
    };
    return l`
      <div class="modal-mask" @click=${n}>
        <div class="modal" @click=${(a) => a.stopPropagation()}>
          <div class="modal-head">
            <div><h2>${t.device} · ${e.name}</h2><span class="faint mono">端口 #${e.idx}</span></div>
            <button class="btn" @click=${n}>关闭</button>
          </div>
          <div class="kv-grid modal-grid">
            <div class="kv"><span>状态</span><b>${e.up ? "Up" : "Down"}</b></div>
            <div class="kv"><span>协商速率</span><b>${F(e.speedMbps)}</b></div>
            <div class="kv"><span>最大速率</span><b>${F(e.maxSpeedMbps)}</b></div>
            <div class="kv"><span>介质 / Connector</span><b>${e.media ?? "—"} / ${e.connector ?? "—"}</b></div>
            ${e.media && /SFP|optical/i.test(e.media) ? l`<div class="kv"><span>SFP 模块诊断</span><b>${e.sfpFound === !0 ? "已检测到（控制器未返回 DDM）" : e.sfpFound === !1 ? "未检测到光模块" : "控制器未提供 SFP 检测字段"}</b></div>` : v}
            <div class="kv"><span>上联</span><b>${e.isUplink ? "是" : "否"}</b></div>
            <div class="kv"><span>全双工 / 自协商</span><b>${e.fullDuplex === !0 ? "全双工" : e.fullDuplex === !1 ? "半双工" : "—"} / ${e.autoneg === !0 ? "开" : e.autoneg === !1 ? "关" : "—"}</b></div>
            <div class="kv"><span>STP 状态 / 角色</span><b>${e.stpState ?? "—"} / ${e.stpRole ?? "—"}</b></div>
            <div class="kv"><span>link_down_count</span><b>${e.linkDownCount ?? "—"}</b></div>
            <div class="kv"><span>RX / TX 流量</span><b>${this.rate(e.rxBps, "down")} / ${this.rate(e.txBps, "up")}</b></div>
            <div class="kv"><span>RX / TX 错包</span><b>${e.rxErrors ?? "—"} / ${e.txErrors ?? "—"}</b></div>
            <div class="kv"><span>RX / TX 丢弃</span><b>${e.rxDropped ?? "—"} / ${e.txDropped ?? "—"}</b></div>
            <div class="kv"><span>MAC 表数量</span><b>${e.macTableCount ?? "—"}</b></div>
            <div class="kv"><span>端口满意度</span><b>${e.satisfaction !== null ? I(e.satisfaction) : "当前接口未返回"}</b></div>
            <div class="kv"><span>PoE 状态</span><b>${s ? s.enabled ? "开启" : "关闭" : "该端口未提供 PoE"}</b></div>
            <div class="kv"><span>PoE class</span><b>${s?.poeClass ?? "—"}</b></div>
            <div class="kv"><span>PoE 电压 / 电流</span><b>${s?.voltageV !== null && s?.voltageV !== void 0 ? `${_(s.voltageV, 1)} V` : "—"} / ${s?.currentA !== null && s?.currentA !== void 0 ? `${_(s.currentA, 3)} A` : "—"}</b></div>
            <div class="kv"><span>PoE 功率</span><b>${s?.powerW !== null && s?.powerW !== void 0 ? `${_(s.powerW, 2)} W` : "—"}</b></div>
            <div class="kv"><span>PoE 状态字符串</span><b>${s?.state ?? "—"}</b></div>
          </div>
        </div>
      </div>
    `;
  }
  renderSpeedtestModal() {
    if (!this.showSpeedtestHistory) return l``;
    const t = this.filteredSpeedtests(), e = 25, s = Math.max(1, Math.ceil(t.length / e));
    this.speedtestPage >= s && (this.speedtestPage = s - 1);
    const n = t.slice(this.speedtestPage * e, this.speedtestPage * e + e), a = [...t].reverse().slice(-120), r = a.map((c) => c.downloadMbps), u = a.map((c) => c.uploadMbps), o = a.map((c) => c.latencyMs), d = (c) => {
      c.stopPropagation(), this.showSpeedtestHistory = !1, this.requestUpdate();
    };
    return l`
      <div class="modal-mask" @click=${d}>
        <div class="modal wide-modal" @click=${(c) => c.stopPropagation()}>
          <div class="modal-head">
            <div><h2>历史测速全部记录</h2><span class="faint">只读控制器已有记录 · 共 ${t.length} 条 · 不会主动测速</span></div>
            <button class="btn" @click=${d}>关闭</button>
          </div>
          <div class="filters">
            <select class="select" .value=${this.speedtestWan} @change=${(c) => {
      this.speedtestWan = c.target.value, this.speedtestPage = 0, this.requestUpdate();
    }}>
              <option value="all">全部 WAN</option>
              ${this.speedtestWanOptions().map((c) => l`<option value=${c.value}>${c.label}</option>`)}
            </select>
            <input class="input" type="date" .value=${this.speedtestFrom} @change=${(c) => {
      this.speedtestFrom = c.target.value, this.speedtestPage = 0, this.requestUpdate();
    }} />
            <input class="input" type="date" .value=${this.speedtestTo} @change=${(c) => {
      this.speedtestTo = c.target.value, this.speedtestPage = 0, this.requestUpdate();
    }} />
            <select class="select" .value=${this.speedtestSort} @change=${(c) => {
      this.speedtestSort = c.target.value, this.speedtestPage = 0, this.requestUpdate();
    }}>
              <option value="desc">时间倒序</option><option value="asc">时间正序</option>
            </select>
          </div>
          ${t.length ? l`
            <div class="st-charts">
              <div><span class="muted">下载 / 上传（Mbps）</span>${kt([
      { values: r, color: "var(--sp-down)", fill: !0 },
      { values: u, color: "var(--sp-up)" }
    ], { height: 70, ariaLabel: "历史测速速率趋势" })}</div>
              <div><span class="muted">延迟（ms）</span>${kt([{ values: o, color: "var(--sp-warn)" }], { height: 70, ariaLabel: "历史测速延迟趋势" })}</div>
            </div>
            <div class="table-wrap">
              <table class="table">
                <thead><tr><th>时间</th><th>WAN</th><th class="right">下载</th><th class="right">上传</th><th class="right">延迟</th></tr></thead>
                <tbody>${n.map((c) => l`<tr>
                  <td class="mono">${B(c.time)}</td>
                  <td class="mono">${c.wanNetworkGroup ?? c.interfaceName}</td>
                  <td class="right num">${c.downloadMbps !== null ? `${_(c.downloadMbps, c.downloadMbps < 10 ? 1 : 0)} Mbps` : "—"}</td>
                  <td class="right num">${c.uploadMbps !== null ? `${_(c.uploadMbps, c.uploadMbps < 10 ? 1 : 0)} Mbps` : "—"}</td>
                  <td class="right num">${c.latencyMs !== null ? `${_(c.latencyMs, 0)} ms` : "—"}</td>
                </tr>`)}</tbody>
              </table>
            </div>
            <div class="between pager">
              <span class="faint">第 ${this.speedtestPage + 1} / ${s} 页</span>
              <span class="row"><button class="btn" ?disabled=${this.speedtestPage <= 0} @click=${() => {
      this.speedtestPage = Math.max(0, this.speedtestPage - 1), this.requestUpdate();
    }}>上一页</button><button class="btn" ?disabled=${this.speedtestPage >= s - 1} @click=${() => {
      this.speedtestPage = Math.min(s - 1, this.speedtestPage + 1), this.requestUpdate();
    }}>下一页</button></span>
            </div>
          ` : l`<div class="empty">没有符合筛选条件的测速记录</div>`}
        </div>
      </div>
    `;
  }
  renderEmpty(t, e) {
    return l`
      <div class="empty-state">
        <div class="empty-ic">${y("info")}</div>
        <h3>${t}</h3>
        <p class="muted">${e}</p>
      </div>
    `;
  }
  // ------------------------------------------------------------------ render
  render() {
    const t = this.state;
    return !t?.initialized && !t?.snapshot ? l`<div class="page"><div class="empty-state"><div class="skeleton" style="width:220px;height:16px"></div><div class="skeleton" style="width:320px;height:12px;margin-top:12px"></div></div></div>` : l`
      <div class="page">
        ${this.renderHeader()}
        ${this.renderTabs()}
        ${this.renderBanner()}
        <main class="content">
          ${this.tab === "overview" ? this.renderOverview() : this.tab === "wan" ? this.renderWan() : this.tab === "gateway" ? this.renderGateway() : this.tab === "switch" ? this.renderSwitch() : this.tab === "ap" ? this.renderAp() : this.tab === "clients" ? this.renderClients() : this.renderTopology()}
        </main>
        ${this.selectedPort ? this.renderPortModal() : v}
        ${this.showSpeedtestHistory ? this.renderSpeedtestModal() : v}
        <footer class="foot">
          <span>UniFi Network Monitor ${ae} · 只读 GET · 数据来自本地控制器</span>
          <span>${t.snapshot ? `快照 ${B(t.snapshot.fetchedAt)}` : ""}</span>
        </footer>
      </div>
    `;
  }
};
Ve.styles = [pe, Lt`
    :host { display: block; height: 100%; max-height: 100%; overflow: hidden; background: var(--sp-bg); backdrop-filter: blur(18px) saturate(130%); -webkit-backdrop-filter: blur(18px) saturate(130%); }
    .page { height: 100%; overflow-y: auto; overflow-x: hidden; display: flex; flex-direction: column; max-width: 1440px; margin: 0 auto; padding: 0 16px 12px; box-sizing: border-box; scrollbar-width: thin; }
    .head { display: flex; align-items: center; justify-content: space-between; gap: 12px; padding: 13px 2px 10px; border-bottom: 1px solid var(--sp-border-soft); position: sticky; top: 0; z-index: 5; background: color-mix(in srgb, var(--sp-bg) 92%, transparent); backdrop-filter: blur(14px); }
    .head-left { display: flex; align-items: center; gap: 10px; min-width: 0; }
    .logo { width: 34px; height: 34px; border-radius: 10px; display: grid; place-items: center; background: var(--sp-surface); border: 1px solid var(--sp-border); color: var(--sp-down); font-size: 19px; flex: none; }
    h1 { font-size: 16px; margin: 0; font-weight: 650; letter-spacing: .2px; }
    .sub { font-size: 11px; }
    .head-right { display: flex; align-items: center; gap: 6px; flex: none; }
    .updated { font-size: 11px; }
    .tabs { display: flex; gap: 2px; overflow-x: auto; padding: 7px 0 0; border-bottom: 1px solid var(--sp-border-soft); position: sticky; top: 58px; z-index: 4; background: color-mix(in srgb, var(--sp-bg) 92%, transparent); backdrop-filter: blur(14px); scrollbar-width: none; }
    .tabs::-webkit-scrollbar { display: none; }
    .tab { appearance: none; border: 0; background: transparent; color: var(--sp-muted); padding: 7px 11px 8px; font-size: 12px; cursor: pointer; border-bottom: 2px solid transparent; white-space: nowrap; }
    .tab:hover { color: var(--sp-text); }
    .tab.active { color: var(--sp-text); border-bottom-color: var(--sp-down); }
    .banner { margin-top: 10px; }
    .hint { font-size: 11px; margin-top: 2px; }
    .content { flex: 1 0 auto; padding: 12px 0 4px; }
    .overview { display: flex; flex-direction: column; gap: 10px; }
    .ov-wans { display: grid; grid-template-columns: repeat(auto-fit, minmax(300px, 1fr)); gap: 10px; }
    .ov-grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(280px, 1fr)); gap: 10px; align-items: start; }
    .card { background: var(--sp-surface); border: 1px solid var(--sp-border-soft); border-radius: var(--sp-radius); padding: 11px 12px; min-width: 0; }
    .card-hd { display: flex; align-items: center; justify-content: space-between; gap: 8px; margin-bottom: 7px; }
    .card-hd h3 { font-size: 12px; margin: 0; font-weight: 600; white-space: nowrap; }
    .wan-card { cursor: pointer; transition: border-color .15s, background .15s; }
    .wan-card:hover { border-color: var(--sp-border); background: var(--sp-surface-hover); }
    .wan-big { display: flex; align-items: flex-end; gap: 18px; margin: 3px 0 4px; flex-wrap: wrap; }
    .big { display: flex; flex-direction: column; gap: 1px; }
    .big .muted { font-size: 10px; display: inline-flex; align-items: center; gap: 3px; }
    .big .rate { font-size: 15px; }
    .big .rate .num { font-size: 21px; font-weight: 700; letter-spacing: -.4px; }
    .big .rate .u { font-size: 10px; color: var(--sp-muted); }
    .wan-foot { display: flex; justify-content: space-between; gap: 6px; flex-wrap: wrap; font-size: 10px; color: var(--sp-muted); margin-top: 3px; }
    .rate { display: inline-flex; align-items: baseline; gap: 3px; color: var(--sp-down); white-space: nowrap; }
    .rate.up { color: var(--sp-up); }
    .rate .ic { width: 12px; height: 12px; align-self: center; }
    .rate .num { font-size: 12px; font-weight: 600; }
    .rate .u { font-size: 9px; color: var(--sp-muted); }
    .dev-summary { display: grid; grid-template-columns: repeat(3, 1fr); gap: 8px; }
    .dev-stat { display: flex; align-items: center; gap: 7px; }
    .dev-ic { width: 28px; height: 28px; border-radius: 8px; background: var(--sp-surface); display: grid; place-items: center; color: var(--sp-down); }
    .dev-stat b { font-size: 14px; }
    .ratio { height: 5px; background: var(--sp-surface); border-radius: 3px; overflow: hidden; margin-top: 7px; }
    .ratio-wired { display: block; height: 100%; background: var(--sp-up); }
    .kv { display: flex; justify-content: space-between; gap: 8px; padding: 2px 0; font-size: 11px; min-width: 0; }
    .kv span { color: var(--sp-muted); flex: none; }
    .kv b { font-weight: 500; text-align: right; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
    .kv-grid { display: grid; grid-template-columns: repeat(3, minmax(0, 1fr)); gap: 1px 16px; }
    .kv.wide { grid-column: 1 / -1; }
    .bars { display: flex; flex-direction: column; gap: 4px; margin: 4px 0; }
    .bar-line { display: flex; align-items: center; gap: 7px; font-size: 10px; margin: 2px 0; }
    .bar-line .muted { min-width: 46px; }
    .bar { flex: 1; height: 5px; background: rgba(255,255,255,.09); border-radius: 3px; overflow: hidden; min-width: 30px; }
    .bar span { display: block; height: 100%; background: var(--sp-down); border-radius: 3px; transition: width .4s ease; }
    .bar-line b { min-width: 40px; text-align: right; font-size: 10px; font-weight: 500; }
    .mini-list { display: flex; flex-direction: column; gap: 3px; }
    .mini-row { display: flex; align-items: center; gap: 6px; font-size: 11px; padding: 2px 0; }
    .mini-row .faint { font-size: 10px; }
    .wan-page { display: flex; flex-direction: column; gap: 10px; }
    .wan-detail .card-hd { border-bottom: 1px solid var(--sp-border-soft); padding-bottom: 7px; }
    .wan-metrics { display: grid; grid-template-columns: repeat(6, minmax(0, 1fr)); gap: 8px; margin: 9px 0; }
    .metric-lg { background: var(--sp-surface); border-radius: 9px; padding: 6px 7px; display: flex; flex-direction: column; gap: 1px; min-width: 0; }
    .metric-lg .muted { font-size: 9px; }
    .metric-lg b { font-size: 14px; font-weight: 650; }
    .metric-lg .rate .num { font-size: 16px; }
    .chart-box { margin: 8px 0 4px; }
    .legend { gap: 8px; font-size: 10px; }
    .sw { width: 8px; height: 8px; border-radius: 2px; display: inline-block; margin-right: 3px; }
    .sw.down { background: var(--sp-down); }
    .sw.up { background: var(--sp-up); }
    .sub-block { margin-top: 10px; }
    .note { display: flex; gap: 7px; align-items: flex-start; font-size: 11px; color: var(--sp-muted); padding: 8px 10px; border: 1px dashed var(--sp-border-soft); border-radius: 9px; }
    .note .ic { margin-top: 1px; flex: none; }
    .detail-page { display: flex; flex-direction: column; gap: 10px; }
    .res-grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(150px, 1fr)); gap: 8px; }
    .res { display: flex; flex-direction: column; gap: 2px; background: var(--sp-surface); border-radius: 9px; padding: 6px 8px; font-size: 11px; }
    .res b { font-size: 15px; }
    .chips { display: flex; gap: 5px; flex-wrap: wrap; margin-top: 4px; }
    .chip { font-size: 10px; padding: 2px 7px; border-radius: 999px; background: var(--sp-surface); border: 1px solid var(--sp-border-soft); color: var(--sp-muted); }
    .selector { display: flex; gap: 5px; flex-wrap: wrap; }
    .ap-grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(320px, 1fr)); gap: 10px; align-items: start; }
    .radio-grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(190px, 1fr)); gap: 7px; margin-top: 8px; }
    .radio { background: var(--sp-surface); border: 1px solid var(--sp-border-soft); border-radius: 9px; padding: 7px 8px; display: flex; flex-direction: column; gap: 2px; }
    .radio .kv { font-size: 10px; }
    .client-kpi { display: grid; grid-template-columns: repeat(3, 1fr); gap: 8px; margin-bottom: 8px; }
    .client-kpi > div { background: var(--sp-surface); border-radius: 9px; padding: 6px 8px; display: flex; flex-direction: column; }
    .client-kpi b { font-size: 18px; }
    .filters { display: flex; flex-wrap: wrap; gap: 7px; align-items: center; margin-bottom: 8px; }
    .search { position: relative; flex: 1 1 200px; min-width: 160px; }
    .search .ic { position: absolute; left: 8px; top: 8px; color: var(--sp-faint); width: 13px; height: 13px; }
    .search .input { padding-left: 27px; }
    .sort { flex: 0 0 108px; }
    .table-wrap { overflow: auto; max-width: 100%; }
    .table.clients td { font-size: 11px; padding: 5px 7px; }
    .table.ports td { font-size: 11px; }
    .tiny { font-size: 9px; }
    .empty-state { display: flex; flex-direction: column; align-items: center; justify-content: center; text-align: center; padding: 60px 20px; gap: 6px; color: var(--sp-muted); }
    .empty-ic { width: 42px; height: 42px; border-radius: 12px; background: var(--sp-surface); display: grid; place-items: center; font-size: 20px; color: var(--sp-faint); }
    .empty-state h3 { color: var(--sp-text); font-size: 14px; margin: 2px 0 0; }
    .empty-state p { max-width: 460px; margin: 0; font-size: 12px; line-height: 1.5; }
    .tree-node { margin: 2px 0; }
    .tree-row { display: flex; align-items: center; gap: 6px; font-size: 12px; padding: 4px 6px; border-radius: 7px; }
    .tree-row:hover { background: var(--sp-surface); }
    .tree-line { width: 10px; height: 1px; background: var(--sp-border); display: inline-block; }
    .tree-ic { color: var(--sp-down); display: inline-flex; }
    .tree-clients { display: flex; flex-wrap: wrap; gap: 4px; margin: 3px 0 6px; }
    .foot { display: flex; justify-content: space-between; gap: 8px; flex-wrap: wrap; padding: 9px 2px 0; border-top: 1px solid var(--sp-border-soft); color: var(--sp-faint); font-size: 10px; }
    @media (max-width: 820px) {
      .page { padding: 0 9px 10px; }
      .head { flex-wrap: wrap; padding-top: 9px; }
      .head-right { width: 100%; justify-content: flex-end; }
      .tabs { top: 92px; }
      .wan-metrics { grid-template-columns: repeat(3, minmax(0, 1fr)); }
      .ov-wans { grid-template-columns: 1fr; }
      .ov-grid { grid-template-columns: 1fr; }
      .dev-summary { grid-template-columns: 1fr; }
      .kv-grid { grid-template-columns: 1fr; }
      .table.clients th:nth-child(4), .table.clients td:nth-child(4),
      .table.clients th:nth-child(8), .table.clients td:nth-child(8) { display: none; }
    }
    @media (max-width: 520px) {
      h1 { font-size: 14px; }
      .updated { display: none; }
      .wan-metrics { grid-template-columns: repeat(2, minmax(0, 1fr)); }
      .table.clients th:nth-child(3), .table.clients td:nth-child(3) { display: none; }
      .radio-grid { grid-template-columns: 1fr; }
      .ap-grid { grid-template-columns: 1fr; }
    }
    tr.clickable { cursor: pointer; }
    tr.clickable:hover td { background: var(--sp-surface-hover); }
    .port-hint { margin-top: 8px; font-size: 9px; }
    .modal-mask { position: fixed; inset: 0; z-index: 80; background: rgba(0,0,0,.55); display: flex; align-items: center; justify-content: center; padding: 20px; }
    .modal { width: min(720px, 100%); max-height: 84vh; overflow: auto; background: var(--sp-bg); border: 1px solid var(--sp-border); border-radius: 14px; padding: 14px; box-shadow: 0 20px 60px rgba(0,0,0,.5); }
    .wide-modal { width: min(980px, 100%); }
    .modal-head { display: flex; justify-content: space-between; align-items: flex-start; gap: 10px; margin-bottom: 10px; }
    .modal-head h2 { margin: 0 0 2px; font-size: 16px; }
    .modal-grid { grid-template-columns: repeat(2, minmax(0, 1fr)); }
    .st-charts { display: grid; grid-template-columns: 1.5fr 1fr; gap: 10px; margin: 10px 0; }
    .st-charts > div { border: 1px solid var(--sp-border-soft); border-radius: 8px; padding: 6px 8px; }
    .st-charts .muted { font-size: 9px; }
    .pager { margin-top: 10px; align-items: center; }
    @media (max-width: 640px) {
      .modal { padding: 10px; }
      .modal-grid { grid-template-columns: 1fr; }
      .st-charts { grid-template-columns: 1fr; }
    }
  `];
let Ie = Ve;
function Rs(i) {
  return i === null || !Number.isFinite(i) ? null : i < 1e12 ? i * 1e3 : i;
}
function ka(i) {
  return i === "unknown" ? "—" : `${i} GHz`;
}
const Xe = class Xe extends le {
  constructor() {
    super(...arguments), this.store = null, this.unsub = null, this.state = null, this.inited = !1, this.clientId = "";
  }
  onInitialized(t) {
    this.clientId = String(t?.customParam?.clientId ?? ""), this.tryInit();
  }
  updated(t) {
    super.updated(t), t?.has?.("spCtx") && this.tryInit(), this.applyTheme();
  }
  tryInit() {
    if (this.inited) return;
    const t = this.spCtx?.api;
    !t || !t.network || !t.timer || (this.inited = !0, this.store = Dt(), this.store.attach(t), this.unsub = this.store.subscribe((e) => {
      this.state = e, this.applyTheme(), this.requestUpdate();
    }));
  }
  onDisconnected() {
    this.unsub?.(), this.unsub = null, this.store && this.spCtx?.api && this.store.detach(this.spCtx.api), this.store = null, this.inited = !1;
  }
  applyTheme() {
    const t = this.state?.settings.theme ?? "auto";
    this.setAttribute("data-theme", ue(t, this.spCtx?.darkMode !== !1, this.parentElement));
  }
  client() {
    return (this.state?.snapshot?.clients ?? []).find((e) => e.id === this.clientId) ?? null;
  }
  name(t) {
    return ei(t.name ?? t.hostname, t.mac, this.state?.settings.hideClientNames === !0);
  }
  ip(t) {
    return this.state?.settings.maskIp !== !1 ? Le(t) : t ?? "—";
  }
  rate(t, e) {
    const s = z(t, this.state?.settings.showBits !== !1);
    return l`<span class="rate ${e}">${y(e === "down" ? "download" : "upload")}<b>${s.value}</b><span class="unit">${s.unit}</span></span>`;
  }
  kv(t, e, s = !1) {
    return l`<div class="kv ${s ? "wide" : ""}"><span>${t}</span><b>${e || "—"}</b></div>`;
  }
  clientFields(t) {
    const e = Rs(t.firstSeen), s = Rs(t.lastSeen), n = t.satisfaction !== null && t.satisfaction >= 0 ? I(t.satisfaction) : t.satisfaction === -1 ? "该客户端无评分" : "当前接口未返回";
    return l`
      <section class="card">
        <div class="card-hd"><h3>客户端信息</h3><span class="faint">${t.wired ? "有线" : "无线"} · 在线</span></div>
        <div class="kv-grid">
          ${this.kv("名称", this.name(t))}
          ${this.kv("MAC", l`<span class="mono">${t.mac || "—"}</span>`)}
          ${this.kv("类型", t.wired ? "有线" : "无线")}
          ${this.kv("IPv4", l`<span class="mono">${this.ip(t.ip)}</span>`)}
          ${this.kv("IPv6", l`<span class="mono">${t.ipv6.length ? t.ipv6.map((a) => this.ip(a)).join(" · ") : "当前接口未返回"}</span>`, !0)}
          ${this.kv("厂商 OUI", t.manufacturer ?? "当前接口未返回")}
          ${this.kv("网络", t.network ?? "—")}
          ${this.kv("VLAN", t.vlan !== null ? String(t.vlan) : "—")}
          ${this.kv("ESSID", t.essid ?? "—")}
          ${this.kv("上联设备", t.uplinkName ?? t.uplinkMac ?? "—")}
          ${this.kv("上联端口", t.uplinkPort !== null ? String(t.uplinkPort) : "—")}
          ${this.kv("在线时长", D(t.uptimeSec))}
          ${this.kv("首次出现", e !== null ? B(e) : "当前接口未返回")}
          ${this.kv("最后出现", s !== null ? `${B(s)}（${Z(s)}）` : "当前接口未返回")}
        </div>
      </section>
      <section class="card">
        <div class="card-hd"><h3>速率与链路</h3><span class="faint">实时传输 / 链路能力分开显示</span></div>
        <div class="rates">
          <div class="big"><span class="muted">当前下载</span>${this.rate(t.rxBps, "down")}</div>
          <div class="big"><span class="muted">当前上传</span>${this.rate(t.txBps, "up")}</div>
        </div>
        <div class="kv-grid">
          ${this.kv(t.wired ? "有线链路速率" : "无线链路速率（PHY）", F(t.linkSpeedMbps))}
          ${this.kv("信号强度", t.signalDbm !== null ? `${t.signalDbm} dBm` : t.wired ? "不适用（有线）" : "当前接口未返回")}
          ${this.kv("噪声", t.noiseDbm !== null ? `${t.noiseDbm} dBm` : t.wired ? "不适用（有线）" : "当前接口未返回")}
          ${this.kv("信道", t.channel !== null ? String(t.channel) : t.wired ? "不适用（有线）" : "当前接口未返回")}
          ${this.kv("信道宽度", t.widthMhz !== null ? `${t.widthMhz} MHz` : t.wired ? "不适用（有线）" : "当前接口未返回")}
          ${this.kv("频段", t.wired ? "有线" : ka(t.band))}
          ${this.kv("满意度", n)}
          ${this.kv("Wi-Fi 重传率", t.wifiRetryPct !== null ? I(t.wifiRetryPct) : "当前接口未返回")}
          ${this.kv("Wi-Fi 重传计数", t.txRetries !== null ? String(t.txRetries) : "当前接口未返回")}
        </div>
      </section>
    `;
  }
  render() {
    const t = this.state, e = this.client();
    return l`
      <div class="page">
        <header class="head">
          <div class="row">
            <span class="logo">${y("wired")}</span>
            <div class="col" style="gap:0">
              <h1>客户端详情</h1>
              <span class="muted">${e ? `${this.name(e)} · 实时更新` : "等待客户端数据"}</span>
            </div>
          </div>
          <div class="row">
            ${t?.snapshot ? l`<span class="faint">更新于 ${Z(t.snapshot.fetchedAt)}</span>` : v}
          </div>
        </header>
        ${e ? this.clientFields(e) : l`<div class="empty-state"><div class="empty-ic">${y("info")}</div><h3>客户端未找到</h3><p class="muted">该客户端可能已离线，或本轮客户端列表尚未返回。关闭窗口后刷新客户端列表重试。</p></div>`}
      </div>
    `;
  }
};
Xe.styles = [pe, Lt`
    .page { height: 100%; overflow-y: auto; padding: 14px 16px 24px; display: flex; flex-direction: column; gap: 10px; }
    .head { display: flex; align-items: center; justify-content: space-between; gap: 8px; }
    .logo { width: 30px; height: 30px; border-radius: 8px; display: inline-flex; align-items: center; justify-content: center; background: var(--sp-surface); color: var(--sp-down); }
    h1 { font-size: 16px; margin: 0; }
    .card { border: 1px solid var(--sp-border); background: var(--sp-card); border-radius: 10px; padding: 10px 12px; }
    .card-hd { display: flex; justify-content: space-between; gap: 8px; margin-bottom: 8px; }
    .card-hd h3 { margin: 0; font-size: 12px; }
    .kv-grid { display: grid; grid-template-columns: repeat(2, minmax(0, 1fr)); gap: 4px 18px; }
    .kv { display: flex; justify-content: space-between; gap: 8px; font-size: 11px; padding: 3px 0; border-bottom: 1px solid var(--sp-border-soft); }
    .kv span { color: var(--sp-muted); flex: none; }
    .kv b { font-weight: 500; text-align: right; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
    .kv.wide { grid-column: 1 / -1; }
    .mono { font-family: ui-monospace, SFMono-Regular, Menlo, monospace; }
    .rates { display: grid; grid-template-columns: 1fr 1fr; gap: 8px; margin-bottom: 8px; }
    .big { border: 1px solid var(--sp-border-soft); border-radius: 8px; padding: 8px; display: flex; flex-direction: column; gap: 2px; }
    .muted { color: var(--sp-muted); font-size: 10px; }
    .rate { display: inline-flex; align-items: baseline; gap: 3px; font-size: 14px; font-weight: 700; }
    .rate.down { color: var(--sp-down); } .rate.up { color: var(--sp-up); }
    .rate b { font-size: 20px; } .rate .unit { font-size: 10px; color: var(--sp-muted); }
    .empty-state { display: flex; flex-direction: column; align-items: center; justify-content: center; gap: 6px; padding: 40px 10px; text-align: center; }
    .empty-ic { color: var(--sp-muted); }
    @media (max-width: 560px) {
      .kv-grid { grid-template-columns: 1fr; }
      .kv.wide { grid-column: auto; }
      .rates { grid-template-columns: 1fr; }
    }
  `];
let Ne = Xe;
const Ze = class Ze extends le {
  constructor() {
    super(...arguments), this.store = null, this.unsub = null, this.state = null, this.inited = !1, this.formLoaded = !1, this.widgetInfo = null, this.host = "", this.site = "default", this.keyInput = "", this.showKey = !1, this.sites = [], this.testResult = null, this.testing = !1, this.saving = !1, this.toast = null, this.toastTimer = null, this.fastIntervalSec = 5, this.slowIntervalSec = 30, this.clientsIntervalSec = 30, this.primaryWanId = "", this.defaultTab = "overview", this.maskIp = !0, this.hideClientNames = !1, this.showWanAsn = !1, this.themeMode = "auto", this.showBits = !0, this.recordHistory = !0, this.modules = [...E.widgetModules], this.wanAliases = {}, this.operatorAliases = {}, this.deviceAliases = {};
  }
  onInitialized() {
    this.tryInit();
  }
  updated(t) {
    super.updated(t), t?.has?.("spCtx") && this.tryInit(), this.applyTheme();
  }
  applyTheme() {
    const t = this.state?.settings.theme ?? "auto", e = ue(t, this.spCtx?.darkMode !== !1, this.parentElement);
    this.setAttribute("data-theme", e);
  }
  tryInit() {
    if (this.inited) return;
    const t = this.spCtx?.api;
    !t || !t.network || !t.timer || (this.inited = !0, this.widgetInfo = this.spCtx?.widgetInfo ?? null, this.store = Dt(), this.store.attach(t), this.unsub = this.store.subscribe((e) => {
      this.state = e, !this.formLoaded && e.initialized && this.loadForm(e), this.requestUpdate();
    }));
  }
  onDisconnected() {
    if (this.unsub?.(), this.unsub = null, this.toastTimer !== null && this.spCtx?.api)
      try {
        this.spCtx.api.timer.clearTimeout(this.toastTimer);
      } catch {
      }
    this.store && this.spCtx?.api && this.store.detach(this.spCtx.api), this.store = null, this.inited = !1;
  }
  loadForm(t) {
    const e = t.settings;
    this.formLoaded = !0, this.host = e.host, this.site = e.site, this.fastIntervalSec = e.fastIntervalSec, this.slowIntervalSec = e.slowIntervalSec, this.clientsIntervalSec = e.clientsIntervalSec, this.primaryWanId = e.primaryWanId ?? "", this.defaultTab = e.defaultTab, this.maskIp = e.maskIp, this.hideClientNames = e.hideClientNames, this.showWanAsn = e.showWanAsn, this.themeMode = e.theme, this.showBits = e.showBits, this.recordHistory = e.recordHistory, this.modules = [...e.widgetModules], this.wanAliases = { ...e.wanAliases }, this.operatorAliases = { ...e.operatorAliases }, this.deviceAliases = { ...e.deviceAliases };
    const s = this.widgetInfo?.config?.modules;
    Array.isArray(s) && (this.modules = s.map(String).filter((n) => Te.includes(n))), this.requestUpdate();
  }
  notify(t, e) {
    if (this.toast = { kind: t, text: e }, this.toastTimer !== null)
      try {
        this.spCtx.api.timer.clearTimeout(this.toastTimer);
      } catch {
      }
    this.toastTimer = this.spCtx.api.timer.setTimeout(() => {
      this.toast = null, this.toastTimer = null, this.requestUpdate();
    }, 4500), this.requestUpdate();
  }
  async discover() {
    if (this.store)
      try {
        const t = await this.store.discoverSites(this.host, this.keyInput || void 0);
        this.sites = t, t.length && !t.some((e) => e.name === this.site) && (this.site = t[0].name), this.notify(t.length ? "ok" : "warn", t.length ? `发现 ${t.length} 个站点` : "未发现站点，请检查地址与 API Key");
      } catch (t) {
        this.notify("bad", t instanceof x ? t.message : "站点发现失败");
      }
  }
  async test() {
    if (!(!this.store || this.testing)) {
      this.testing = !0, this.testResult = null, this.requestUpdate();
      try {
        const t = await this.store.testConnection(this.host, this.keyInput || void 0);
        this.testResult = t, t.sites.length && (this.sites = t.sites, t.sites.some((e) => e.name === this.site) || (this.site = t.sites[0].name)), this.notify(t.ok ? t.degraded ? "warn" : "ok" : "bad", t.ok ? t.degraded ? "部分接口可用（已降级）" : "连接成功" : "连接失败，请查看下方明细");
      } catch (t) {
        this.notify("bad", t instanceof x ? t.message : "测试失败");
      } finally {
        this.testing = !1, this.requestUpdate();
      }
    }
  }
  async save() {
    if (!(!this.store || this.saving)) {
      this.saving = !0, this.requestUpdate();
      try {
        let t;
        try {
          t = Et(this.host);
        } catch (n) {
          this.notify("bad", n instanceof x ? n.message : "网关地址格式无效");
          return;
        }
        const e = {
          host: t,
          site: this.site.trim() || "default",
          fastIntervalSec: this.fastIntervalSec,
          slowIntervalSec: this.slowIntervalSec,
          clientsIntervalSec: this.clientsIntervalSec,
          primaryWanId: this.primaryWanId || null,
          defaultTab: this.defaultTab,
          maskIp: this.maskIp,
          hideClientNames: this.hideClientNames,
          showWanAsn: this.showWanAsn,
          theme: this.themeMode,
          showBits: this.showBits,
          recordHistory: this.recordHistory,
          widgetModules: [...this.modules],
          wanAliases: { ...this.wanAliases },
          operatorAliases: { ...this.operatorAliases },
          deviceAliases: { ...this.deviceAliases }
        }, s = !!this.keyInput.trim();
        if (await this.store.saveSettings(e, !s), s && (await this.store.saveApiKey(this.keyInput.trim()), this.keyInput = ""), this.widgetInfo && this.widgetInfo.widgetId)
          try {
            await this.spCtx.api.widget.save({
              ...this.widgetInfo,
              config: { ...this.widgetInfo.config ?? {}, modules: [...this.modules] }
            });
          } catch {
          }
        this.notify("ok", "设置已保存并自动生效"), this.widgetInfo && this.widgetInfo.widgetId && this.spCtx.api.window?.close?.();
      } catch (t) {
        this.notify("bad", t instanceof x ? t.message : "保存失败");
      } finally {
        this.saving = !1, this.requestUpdate();
      }
    }
  }
  async clearKey() {
    if (this.store)
      try {
        await this.store.clearApiKey(), this.keyInput = "", this.notify("warn", "API Key 已清除");
      } catch (t) {
        this.notify("bad", t instanceof x ? t.message : "清除失败");
      }
  }
  async resetCache() {
    this.store && (this.store.resetData(), this.notify("warn", "已清除本地缓存与历史数据"));
  }
  diagnosticsJson() {
    return JSON.stringify(this.store?.exportDiagnostics() ?? {}, null, 2);
  }
  exportDiagnostics() {
    try {
      const t = new Blob([this.diagnosticsJson()], { type: "application/json" }), e = URL.createObjectURL(t), s = document.createElement("a");
      s.href = e, s.download = `unifi-network-monitor-diagnostics-${(/* @__PURE__ */ new Date()).toISOString().replace(/[:.]/g, "-")}.json`, document.body.appendChild(s), s.click(), s.remove(), setTimeout(() => URL.revokeObjectURL(e), 2e3), this.notify("ok", "诊断信息已导出（已脱敏，不含密钥）");
    } catch {
      this.notify("bad", "导出失败");
    }
  }
  async copyDiagnostics() {
    const t = this.diagnosticsJson();
    try {
      await navigator.clipboard.writeText(t), this.notify("ok", "诊断信息已复制（已脱敏）");
    } catch {
      try {
        const e = document.createElement("textarea");
        e.value = t, e.style.position = "fixed", e.style.opacity = "0", document.body.appendChild(e), e.select(), document.execCommand("copy"), e.remove(), this.notify("ok", "诊断信息已复制（已脱敏）");
      } catch {
        this.notify("bad", "复制失败，请使用“导出诊断”");
      }
    }
  }
  setAlias(t, e, s) {
    const n = { ...t };
    s.trim() ? n[e] = s.trim() : delete n[e], t === this.wanAliases ? this.wanAliases = n : t === this.operatorAliases ? this.operatorAliases = n : this.deviceAliases = n, this.requestUpdate();
  }
  renderToast() {
    return this.toast ? l`<div class="toast ${this.toast.kind}">${y(this.toast.kind === "ok" ? "check" : this.toast.kind === "bad" ? "warning" : "info")} ${this.toast.text}</div>` : v;
  }
  renderConnection() {
    const e = this.state?.settings.apiKeyConfigured === !0;
    return l`
      <section class="card">
        <div class="card-hd"><h3>连接</h3><span class="faint">${e ? "已配置 API Key" : "未配置 API Key"}</span></div>
        <div class="field">
          <label class="label">UniFi 网关地址（含 HTTPS 端口）</label>
          <input class="input mono" .value=${this.host} @input=${(s) => {
      this.host = s.target.value, this.requestUpdate();
    }} placeholder="https://unifi.local:443" autocomplete="off" spellcheck="false" />
          <div class="help">只允许 http/https，不能包含路径、用户名或密码。自签名证书场景请使用证书中的 <span class="mono">unifi.local</span>，并在 Sun-Panel 容器内信任该证书。</div>
        </div>
        <div class="row gap">
          <div class="field grow">
            <label class="label">站点（legacy 名称）</label>
            <input class="input" .value=${this.site} @input=${(s) => {
      this.site = s.target.value, this.requestUpdate();
    }} placeholder="default" />
          </div>
          <div class="field" style="flex:0 0 auto;align-self:flex-end">
            <button class="btn" @click=${() => void this.discover()}>${y("search")} 发现站点</button>
          </div>
        </div>
        ${this.sites.length ? l`
          <div class="field">
            <label class="label">已发现站点</label>
            <select class="select" .value=${this.site} @change=${(s) => {
      this.site = s.target.value, this.requestUpdate();
    }}>
              ${this.sites.map((s) => l`<option value=${s.name}>${s.label} (${s.name}) · ${s.source}</option>`)}
            </select>
          </div>
        ` : v}
        <div class="field">
          <label class="label">API Key（只写入敏感数据节点，不回显）</label>
          <div class="row">
            <input class="input mono" type=${this.showKey ? "text" : "password"} .value=${this.keyInput} @input=${(s) => {
      this.keyInput = s.target.value, this.requestUpdate();
    }} placeholder=${e ? "已配置，留空保持不变" : "粘贴 UniFi API Key"} autocomplete="new-password" spellcheck="false" />
            <button class="btn" title=${this.showKey ? "隐藏" : "显示"} @click=${() => {
      this.showKey = !this.showKey, this.requestUpdate();
    }}>${y(this.showKey ? "eyeOff" : "eye")}</button>
          </div>
          <div class="help">密钥不会写入源码、日志、安装包或诊断报告；所有请求通过 dataNode 模板替换注入。<b>应用内部只发送 GET。</b></div>
        </div>
        <div class="row gap">
          <button class="btn primary" ?disabled=${this.testing} @click=${() => void this.test()}>${y("activity")} ${this.testing ? "测试中…" : "测试连接"}</button>
          ${e ? l`<button class="btn danger" @click=${() => void this.clearKey()}>清除 API Key</button>` : v}
        </div>
        ${this.testResult ? this.renderTestResult(this.testResult) : v}
      </section>
    `;
  }
  renderTestResult(t) {
    return l`
      <div class="test">
        ${t.checks.map((e) => l`
          <div class="test-row">
            <span class="dot ${e.ok ? "ok" : "bad"}"></span>
            <span class="grow">${e.name}</span>
            <span class="faint mono">${e.status ?? "—"}</span>
            <span class=${e.ok ? "muted" : "bad-text"}>${e.message}</span>
          </div>
        `)}
        ${t.degraded ? l`<div class="help warn-text">部分接口不可用，应用会自动降级；传统只读接口可用时仍可显示大部分指标。</div>` : v}
      </div>
    `;
  }
  renderRefresh() {
    return l`
      <section class="card">
        <div class="card-hd"><h3>刷新与性能</h3><span class="faint">全部定时器走官方 api.timer</span></div>
        <div class="grid3">
          <div class="field">
            <label class="label">实时 WAN 速率（秒）</label>
            <input class="input" type="number" min="5" max="60" .value=${String(this.fastIntervalSec)} @change=${(t) => {
      this.fastIntervalSec = Number(t.target.value) || 5, this.requestUpdate();
    }} />
            <div class="help">默认 5 秒，范围 5–60。</div>
          </div>
          <div class="field">
            <label class="label">完整设备统计（秒）</label>
            <input class="input" type="number" min="15" max="300" .value=${String(this.slowIntervalSec)} @change=${(t) => {
      this.slowIntervalSec = Number(t.target.value) || 30, this.requestUpdate();
    }} />
            <div class="help">默认 30 秒，范围 15–300。</div>
          </div>
          <div class="field">
            <label class="label">客户端刷新（秒）</label>
            <input class="input" type="number" min="10" max="300" .value=${String(this.clientsIntervalSec)} @change=${(t) => {
      this.clientsIntervalSec = Number(t.target.value) || 30, this.requestUpdate();
    }} />
            <div class="help">默认 30 秒；仅窗口可见时刷新。</div>
          </div>
        </div>
        <div class="help">页面隐藏时自动降频到 60 秒；恢复可见后立即刷新。失败请求指数退避，同类请求不会重叠。</div>
      </section>
    `;
  }
  renderWanSettings() {
    const t = this.state?.snapshot?.wans ?? [], e = /* @__PURE__ */ new Map();
    for (const s of t) {
      const n = s.operatorKey ?? s.operator ?? "";
      n && e.set(n, s.operator ?? n);
    }
    return l`
      <section class="card">
        <div class="card-hd"><h3>WAN 与运营商</h3><span class="faint">${t.length} 条线路</span></div>
        <div class="field">
          <label class="label">主用线路（用于“主用/备用”标识）</label>
          <select class="select" .value=${this.primaryWanId} @change=${(s) => {
      this.primaryWanId = s.target.value, this.requestUpdate();
    }}>
            <option value="">自动（第一个 WAN）</option>
            ${t.map((s) => l`<option value=${s.id}>${s.name} · ${s.operator ?? "未知运营商"} · ${s.id}</option>`)}
          </select>
          <div class="help">“当前承载”由控制器返回的 WAN IP 与健康状态匹配得出，不依赖数组顺序。</div>
        </div>
        ${t.map((s) => l`
          <div class="field">
            <label class="label">${s.name} 别名（${s.operator ?? "未知运营商"}）</label>
            <input class="input" .value=${this.wanAliases[s.id] ?? ""} @input=${(n) => this.setAlias(this.wanAliases, s.id, n.target.value)} placeholder=${s.name} />
          </div>
        `)}
        ${[...e.entries()].map(([s, n]) => l`
          <div class="field">
            <label class="label">运营商别名（${n}）</label>
            <input class="input" .value=${this.operatorAliases[s] ?? ""} @input=${(a) => this.setAlias(this.operatorAliases, s, a.target.value)} placeholder=${n} />
          </div>
        `)}
      </section>
    `;
  }
  renderDeviceAliases() {
    const t = this.state?.snapshot, e = [t?.gateway, ...t?.switches ?? [], ...t?.aps ?? []].filter(Boolean);
    return l`
      <section class="card">
        <div class="card-hd"><h3>设备别名</h3><span class="faint">${e.length} 台</span></div>
        ${e.length ? e.map((s) => l`
          <div class="field">
            <label class="label">${s.name} <span class="faint mono">${s.mac}</span></label>
            <input class="input" .value=${this.deviceAliases[s.mac] ?? ""} @input=${(n) => this.setAlias(this.deviceAliases, s.mac, n.target.value)} placeholder=${s.name} />
          </div>
        `) : l`<div class="empty">连接成功后自动发现设备</div>`}
      </section>
    `;
  }
  renderDisplay() {
    return l`
      <section class="card">
        <div class="card-hd"><h3>显示</h3><span class="faint">首页卡片与详情默认值</span></div>
        <div class="grid2">
          <div class="field">
            <label class="label">详情默认模块</label>
            <select class="select" .value=${this.defaultTab} @change=${(t) => {
      this.defaultTab = t.target.value, this.requestUpdate();
    }}>
              <option value="overview">概览</option><option value="wan">WAN</option><option value="gateway">网关</option><option value="switch">交换机</option><option value="ap">AP</option><option value="clients">客户端</option><option value="topology">拓扑</option>
            </select>
          </div>
          <div class="field">
            <label class="label">主题</label>
            <select class="select" .value=${this.themeMode} @change=${(t) => {
      this.themeMode = t.target.value, this.requestUpdate();
    }}>
              <option value="auto">跟随 Sun-Panel</option><option value="dark">深色</option><option value="light">浅色</option>
            </select>
          </div>
        </div>
        <div class="field">
          <div class="between"><label class="label">首页卡片展示模块</label><button class="btn" @click=${() => {
      this.modules = [...E.widgetModules], this.requestUpdate();
    }}>恢复默认</button></div>
          <div class="checks">
            ${Te.map((t) => l`
              <label class="check"><input type="checkbox" .checked=${this.modules.includes(t)} @change=${(e) => {
      const s = e.target.checked;
      this.modules = s ? [.../* @__PURE__ */ new Set([...this.modules, t])] : this.modules.filter((n) => n !== t), this.requestUpdate();
    }} /> ${t === "wan" ? "WAN 速率" : t === "devices" ? "设备数量" : t === "gateway" ? "网关 CPU/温度" : t === "clients" ? "有线/无线终端" : t === "poe" ? "PoE 功耗" : t === "updated" ? "更新时间" : "历史测速"}</label>
            `)}
          </div>
        </div>
        <div class="checks">
          <label class="check"><input type="checkbox" .checked=${this.maskIp} @change=${(t) => {
      this.maskIp = t.target.checked, this.requestUpdate();
    }} /> IP 地址脱敏</label>
          <label class="check"><input type="checkbox" .checked=${this.hideClientNames} @change=${(t) => {
      this.hideClientNames = t.target.checked, this.requestUpdate();
    }} /> 隐藏客户端名称</label>
          <label class="check"><input type="checkbox" .checked=${this.showWanAsn} @change=${(t) => {
      this.showWanAsn = t.target.checked, this.requestUpdate();
    }} /> 显示 WAN ASN（默认关闭）</label>
          <label class="check"><input type="checkbox" .checked=${this.showBits} @change=${(t) => {
      this.showBits = t.target.checked, this.requestUpdate();
    }} /> 速率用比特（Mbps）</label>
          <label class="check"><input type="checkbox" .checked=${this.recordHistory} @change=${(t) => {
      this.recordHistory = t.target.checked, this.requestUpdate();
    }} /> 记录运行期间曲线</label>
        </div>
      </section>
    `;
  }
  renderDiagnostics() {
    const t = this.state, e = t?.endpoints ?? [];
    return l`
      <section class="card">
        <div class="card-hd"><h3>诊断</h3><span class="faint">v${ae}</span></div>
        <div class="kv"><span>最近成功</span><b>${t?.lastSuccessAt ? B(t.lastSuccessAt) : "—"}</b></div>
        <div class="kv"><span>快照时间</span><b>${t?.snapshot ? B(t.snapshot.fetchedAt) : "—"}</b></div>
        <div class="kv"><span>最近错误</span><b class=${t?.lastError ? "bad-text" : ""}>${t?.lastError ? qe(t.lastError) : "无"}</b></div>
        <div class="table-wrap" style="margin-top:6px">
          <table class="table">
            <thead><tr><th>接口</th><th>状态</th><th class="right">HTTP</th><th class="right">耗时</th><th>最近成功</th><th>错误</th></tr></thead>
            <tbody>
              ${e.map((s) => l`<tr>
                <td>${s.label}</td>
                <td><span class="row"><span class="dot ${s.ok ? "ok" : s.lastAttemptAt ? "bad" : ""}"></span>${s.ok ? "OK" : s.lastAttemptAt ? "失败" : "未请求"}</span></td>
                <td class="right mono">${s.status ?? "—"}</td>
                <td class="right mono">${s.durationMs !== null ? `${s.durationMs}ms` : "—"}</td>
                <td class="mono">${s.lastSuccessAt ? Z(s.lastSuccessAt) : "—"}</td>
                <td class="faint truncate" title=${s.error ?? ""}>${s.error ?? ""}</td>
              </tr>`)}
            </tbody>
          </table>
        </div>
        <div class="row gap" style="margin-top:8px">
          <button class="btn" @click=${() => this.exportDiagnostics()}>${y("download")} 导出诊断</button>
          <button class="btn" @click=${() => void this.copyDiagnostics()}>${y("link")} 复制</button>
          <button class="btn danger" @click=${() => void this.resetCache()}>${y("refresh")} 清除缓存</button>
        </div>
        <div class="help">诊断信息不包含 API Key、客户端名称、IP、MAC、序列号；仅包含接口状态、计数、版本与脱敏错误。</div>
      </section>
    `;
  }
  render() {
    const t = this.state, e = !!(this.widgetInfo && this.widgetInfo.widgetId);
    return l`
      <div class="page">
        <header class="head">
          <div class="row">
            <span class="logo">${y("settings")}</span>
            <div class="col" style="gap:0">
              <h1>${e ? "UniFi 小部件设置" : "UniFi 网络监控设置"}</h1>
              <span class="muted" style="font-size:11px">只读监控 · 所有配置保存后自动生效</span>
            </div>
          </div>
          <div class="row">
            ${t?.snapshot ? l`<span class="badge">${t.snapshot.wans.length} WAN · ${t.snapshot.counts.clientsTotal ?? "—"} 终端</span>` : v}
            <button class="btn primary" ?disabled=${this.saving} @click=${() => void this.save()}>${y("check")} ${this.saving ? "保存中…" : "保存并应用"}</button>
          </div>
        </header>
        ${this.renderToast()}
        <main class="content">
          ${this.renderConnection()}
          ${this.renderRefresh()}
          ${this.renderWanSettings()}
          ${this.renderDeviceAliases()}
          ${this.renderDisplay()}
          ${this.renderDiagnostics()}
          <div class="note">
            ${y("shield")}
            <span>应用只发送只读 GET；不会重启设备、切换 WAN、测速、升级固件或修改 PoE/路由/防火墙/DHCP/DNS/VLAN/WiFi。API Key 存放在 Sun-Panel 用户级敏感数据节点，通过模板替换注入请求。</span>
          </div>
        </main>
      </div>
    `;
  }
};
Ze.styles = [pe, Lt`
    :host { display: block; height: 100%; max-height: 100%; overflow: hidden; background: var(--sp-bg); backdrop-filter: blur(18px) saturate(130%); -webkit-backdrop-filter: blur(18px) saturate(130%); }
    .page { height: 100%; overflow-y: auto; overflow-x: hidden; max-width: 900px; margin: 0 auto; padding: 12px 14px 22px; box-sizing: border-box; scrollbar-width: thin; }
    .head { display: flex; align-items: center; justify-content: space-between; gap: 10px; padding-bottom: 10px; border-bottom: 1px solid var(--sp-border-soft); }
    .logo { width: 34px; height: 34px; border-radius: 10px; display: grid; place-items: center; background: var(--sp-surface); border: 1px solid var(--sp-border); color: var(--sp-down); }
    h1 { font-size: 15px; margin: 0; font-weight: 650; }
    .content { display: flex; flex-direction: column; gap: 10px; margin-top: 10px; }
    .card { background: var(--sp-surface); border: 1px solid var(--sp-border-soft); border-radius: var(--sp-radius); padding: 11px 12px; }
    .card-hd { display: flex; align-items: center; justify-content: space-between; gap: 8px; margin-bottom: 7px; }
    .card-hd h3 { margin: 0; font-size: 12px; font-weight: 600; }
    .field { margin-bottom: 8px; }
    .field:last-child { margin-bottom: 0; }
    .help { font-size: 10px; color: var(--sp-faint); margin-top: 3px; line-height: 1.4; }
    .gap { gap: 8px; flex-wrap: wrap; }
    .grid3 { display: grid; grid-template-columns: repeat(3, minmax(0, 1fr)); gap: 8px; }
    .grid2 { display: grid; grid-template-columns: repeat(2, minmax(0, 1fr)); gap: 8px; }
    .checks { display: flex; flex-wrap: wrap; gap: 6px 14px; }
    .check { display: inline-flex; align-items: center; gap: 5px; font-size: 11px; color: var(--sp-muted); cursor: pointer; }
    .check input { accent-color: var(--sp-down); }
    .test { margin-top: 8px; border: 1px solid var(--sp-border-soft); border-radius: 9px; padding: 6px 8px; display: flex; flex-direction: column; gap: 3px; }
    .test-row { display: flex; align-items: center; gap: 6px; font-size: 11px; }
    .bad-text { color: var(--sp-bad); }
    .warn-text { color: var(--sp-warn); }
    .toast { position: sticky; top: 0; z-index: 10; margin: 8px 0 0; padding: 7px 10px; border-radius: 9px; font-size: 12px; display: flex; align-items: center; gap: 6px; background: var(--sp-bg-strong); border: 1px solid var(--sp-border); }
    .toast.ok { border-color: color-mix(in srgb, var(--sp-ok) 45%, transparent); }
    .toast.bad { border-color: color-mix(in srgb, var(--sp-bad) 45%, transparent); }
    .toast.warn { border-color: color-mix(in srgb, var(--sp-warn) 45%, transparent); }
    .table-wrap { overflow: auto; max-width: 100%; }
    .table td, .table th { font-size: 10px; padding: 4px 6px; }
    @media (max-width: 620px) {
      .grid3, .grid2 { grid-template-columns: 1fr; }
      .head { flex-wrap: wrap; }
    }
  `];
let Re = Ze;
const Ye = class Ye extends Gs {
  constructor() {
    super(...arguments), this.store = null, this.unsub = null, this.state = null, this.widgetConfig = {}, this.inited = !1;
  }
  onInitialized() {
    this.tryInit();
  }
  updated(t) {
    super.updated(t), t?.has?.("spCtx") && this.tryInit(), this.applyTheme();
  }
  tryInit() {
    if (this.inited) return;
    const t = this.spCtx?.api;
    !t || !t.network || !t.timer || (this.inited = !0, this.store = Dt(), this.store.attach(t), this.widgetConfig = this.spCtx?.widgetInfo?.config ?? {}, this.unsub = this.store.subscribe((e) => {
      this.state = e, this.applyTheme(), this.requestUpdate();
    }));
  }
  onDisconnected() {
    this.unsub?.(), this.unsub = null, this.store && this.spCtx?.api && this.store.detach(this.spCtx.api), this.store = null, this.inited = !1;
  }
  applyTheme() {
    const t = this.state?.settings.theme ?? "auto", e = ue(t, this.spCtx?.darkMode !== !1, this.parentElement);
    this.setAttribute("data-theme", e);
  }
  size() {
    const t = String(this.spCtx?.widgetInfo?.gridSize ?? "2x2");
    return t === "1x1" ? "tiny" : t === "1x2" || t === "2x1" ? "compact" : t === "2x2" ? "standard" : t === "2x4" || t === "1xfull" ? "wide" : "full";
  }
  modules() {
    return this.state?.settings.widgetModules ?? ["wan", "devices", "gateway", "clients", "poe", "updated", "speedtest"];
  }
  hasModule(t) {
    return this.modules().includes(t);
  }
  openDashboard(t) {
    try {
      this.spCtx.api.window.open({
        componentName: "unifi-dashboard",
        title: "UniFi 网络监控",
        customParam: { tab: t ?? this.state?.settings.defaultTab ?? "overview" },
        windowConfig: {
          width: 1280,
          height: 860,
          showFullscreenBtn: !0,
          resize: !0,
          move: !0,
          background: "#0e1015",
          backgroundDark: "#0e1015",
          headerTextColor: "#ffffff",
          headerTextColorDark: "#ffffff"
        }
      });
    } catch {
    }
  }
  openSettings() {
    try {
      this.spCtx.api.window.open({
        componentName: "unifi-settings",
        title: "UniFi 监控设置",
        customParam: { mode: "app" },
        windowConfig: { width: 720, height: 760, showFullscreenBtn: !1, resize: !0, move: !0 }
      });
    } catch {
    }
  }
  refresh() {
    this.store?.refreshAll(!0);
  }
  renderRate(t, e) {
    const s = z(t, this.state?.settings.showBits !== !1);
    return l`<span class="rate ${e}" title=${e === "down" ? "下载" : "上传"}>
      ${y(e === "down" ? "download" : "upload")}
      <span class="num">${s.value}</span><span class="unit">${s.unit}</span>
    </span>`;
  }
  compactRate(t, e) {
    const s = z(t, this.state?.settings.showBits !== !1), a = { bps: "b", Kbps: "K", Mbps: "M", Gbps: "G", Tbps: "T", "B/s": "B", "KB/s": "K", "MB/s": "M", "GB/s": "G" }[s.unit] ?? s.unit;
    return l`<span class="crate ${e}"><span class="arrow">${e === "down" ? "↓" : "↑"}</span>${s.value}<span class="cu">${a}</span></span>`;
  }
  opShort(t) {
    const e = t.operator ?? "";
    return {
      "China Telecom": "电信",
      "China Mobile": "移动",
      "China Unicom": "联通",
      "China Broadnet": "广电"
    }[e] ?? (e.length > 8 ? e.slice(0, 8) : e || "未知");
  }
  renderWanSingle(t) {
    return l`
      <div class="wan-line wan-single ${t.active ? "active" : ""}" title=${`${R(t)} · ${t.operator ?? "未知运营商"} · ${t.latencyMs !== null ? Math.round(t.latencyMs) + "ms" : "延迟—"}`} @click=${(e) => {
      e.stopPropagation(), this.openDashboard("wan");
    }}>
        <span class="dot ${U(t.online)}"></span>
        <b class="name">${R(t)}</b>
        <span class="op">${this.opShort(t)}</span>
        ${t.active ? l`<span class="badge ok tiny-badge">承载</span>` : v}
        <span class="wrates">${this.compactRate(t.rxBps, "down")}${this.compactRate(t.txBps, "up")}</span>
        <span class="lat num">${t.latencyMs !== null ? `${Math.round(t.latencyMs)}ms` : "—"}</span>
      </div>
    `;
  }
  renderWanLine(t) {
    return l`
      <div class="wan-line" @click=${(e) => {
      e.stopPropagation(), this.openDashboard("wan");
    }}>
        <div class="wan-l1">
          <span class="dot ${U(t.online)}" title=${oi(t.online)}></span>
          <span class="wan-name grow"><span class="name">${R(t)}</span><span class="op">${t.operator ?? "未知运营商"}</span></span>
          ${t.active ? l`<span class="badge ok">承载</span>` : ""}
        </div>
        <div class="wan-l2">
          <div class="wan-rates">${this.renderRate(t.rxBps, "down")}${this.renderRate(t.txBps, "up")}</div>
          <span class="lat num" title="延迟">${t.latencyMs !== null ? `${Math.round(t.latencyMs)}ms` : "—"}</span>
        </div>
      </div>
    `;
  }
  renderError() {
    const t = this.state?.lastError ?? null;
    return l`
      <div class="err" @click=${(e) => e.stopPropagation()}>
        <div class="row">
          <span class="dot bad"></span>
          <strong>UniFi 未连接</strong>
          <span class="grow"></span>
          <button class="btn" title="重试" @click=${() => this.refresh()}>${y("refresh")}</button>
        </div>
        <div class="err-msg">${qe(t)}</div>
        <div class="err-hint">${li(t)}</div>
        <button class="btn primary" @click=${() => this.openSettings()}>${y("settings")} 打开设置</button>
      </div>
    `;
  }
  hiddenModules(t) {
    const e = {
      tiny: ["wan"],
      compact: ["wan", "devices", "clients", "updated"],
      standard: ["wan", "devices", "clients", "gateway", "poe", "updated", "speedtest"],
      wide: ["wan", "devices", "clients", "gateway", "poe", "updated", "speedtest"],
      full: ["wan", "devices", "clients", "gateway", "poe", "updated", "speedtest"]
    };
    return this.modules().filter((s) => !e[t].includes(s));
  }
  moduleHint(t) {
    const e = this.hiddenModules(t);
    return e.length ? l`<span class="module-hint" title=${`空间不足：${e.join("、")} 未在当前尺寸显示；点击卡片查看详情`}>+${e.length}</span>` : v;
  }
  noModules() {
    return l`<div class="module-empty">未选择展示模块<br /><span @click=${(t) => {
      t.stopPropagation(), this.openSettings();
    }}>打开设置</span></div>`;
  }
  sparkline(t) {
    const e = Wt(this.state?.history ?? [], t.id, 24);
    if (!e.length) return v;
    const s = e.map((d) => d.rxBps === null ? null : d.rxBps * 8), n = e.map((d) => d.txBps === null ? null : d.txBps * 8), a = Math.max(1, ...s.filter((d) => d !== null), ...n.filter((d) => d !== null)), r = 64, u = 14, o = (d) => {
      const c = [];
      return d.forEach((p, g) => {
        if (p === null) return;
        const m = g / Math.max(1, d.length - 1) * r, h = u - Math.max(0, Math.min(u, p / a * u));
        c.push(`${c.length ? "L" : "M"}${m.toFixed(1)},${h.toFixed(1)}`);
      }), c.join(" ");
    };
    return l`<svg class="spark" viewBox="0 0 64 14" preserveAspectRatio="none" aria-label="最近速率趋势">
      <path d=${o(s)} fill="none" stroke="var(--sp-down)" stroke-width="1.1" />
      <path d=${o(n)} fill="none" stroke="var(--sp-up)" stroke-width="1.1" />
    </svg>`;
  }
  wanIdentity(t) {
    const e = [];
    return t.ipv4 && e.push(`IP ${this.state?.settings.maskIp !== !1 ? Le(t.ipv4) : t.ipv4}`), this.state?.settings.showWanAsn === !0 && t.asn !== null && e.push(`ASN ${t.asn}`), e.join(" · ");
  }
  latestSpeedtestText() {
    const t = this.state?.snapshot;
    if (!t) return "无记录";
    const e = t.wans.find((u) => u.active) ?? t.wans[0];
    if (!e) return "无记录";
    const s = $a(t, e);
    if (!s) return "无记录";
    const n = s.downloadMbps !== null ? _(s.downloadMbps, s.downloadMbps < 10 ? 1 : 0) : "—", a = s.uploadMbps !== null ? _(s.uploadMbps, s.uploadMbps < 10 ? 1 : 0) : "—", r = s.latencyMs !== null ? `${_(s.latencyMs, 0)}ms` : "—";
    return `${n}/${a} Mbps · ${r}`;
  }
  renderTiny() {
    const t = this.state?.snapshot, e = ba(t), s = t?.wans.some((a) => a.online === !0) ?? null, n = this.hasModule("wan");
    return l`
      <div class="tiny">
        <div class="between">
          <span class="row"><span class="dot ${U(s)}"></span><span class="tiny-title">UniFi</span></span>
          <span class="row">${this.moduleHint("tiny")}</span>
        </div>
        ${n ? l`
          <div class="tiny-rates">
            ${this.renderRate(e.rx, "down")}
            ${this.renderRate(e.tx, "up")}
          </div>
        ` : this.noModules()}
      </div>
    `;
  }
  renderCompact() {
    const t = this.state?.snapshot, e = t?.wans.slice(0, 2) ?? [], s = t?.counts, n = this.hasModule("wan"), a = this.hasModule("devices"), r = this.hasModule("clients");
    return l`
      <div class="compact">
        <div class="between hdr">
          <span class="row"><span class="dot ${U(e.some((u) => u.online === !0))}"></span><strong>UniFi</strong></span>
          <span class="row">${this.moduleHint("compact")}${this.hasModule("updated") ? l`<span class="faint compact-time">${t ? Z(t.fetchedAt) : "加载中"}</span>` : v}</span>
        </div>
        ${n ? l`<div class="compact-wans">${e.map((u) => String(this.spCtx?.widgetInfo?.gridSize) === "1x2" ? this.renderWanSingle(u) : this.renderWanLine(u))}${e.length ? "" : l`<div class="empty">暂无 WAN 数据</div>`}</div>` : v}
        ${a || r ? l`
          <div class="between compact-foot">
            <span class="muted">${a && s ? `GW ${s.gatewayOnline ?? "—"}/${s.gateway ?? "—"} · SW ${s.switchOnline ?? "—"}/${s.switch ?? "—"} · AP ${s.apOnline ?? "—"}/${s.ap ?? "—"}` : ""}</span>
            <span class="muted">${r && s ? `终端 ${s.clientsTotal ?? "—"}` : ""}</span>
          </div>
        ` : v}
        ${!n && !a && !r ? this.noModules() : v}
      </div>
    `;
  }
  mobileSpaceHint(t, e, s) {
    if (typeof window > "u" || window.innerWidth > 520) return v;
    const n = [];
    return t && n.push("设备数量"), e && n.push("固件/运行时间"), s && n.push("历史测速"), n.length ? l`<span class="module-hint" title=${`移动端空间不足：${n.join("、")} 未在卡片显示，点击打开详情`}>+${n.length}</span>` : v;
  }
  renderStandard() {
    const t = this.state?.snapshot, e = t?.wans.slice(0, 2) ?? [], s = It(t), n = te(t), a = t?.gateway, r = t?.counts, u = this.hasModule("wan"), o = this.hasModule("devices"), d = this.hasModule("clients"), c = this.hasModule("gateway"), p = this.hasModule("poe"), g = this.hasModule("speedtest"), m = [];
    return d && (m.push(l`<div class="m6"><span>有线</span><b>${r?.clientsWired ?? "—"}</b></div>`), m.push(l`<div class="m6"><span>无线</span><b>${r?.clientsWireless ?? "—"}</b></div>`)), c && (m.push(l`<div class="m6"><span>CPU</span><b>${a?.cpuPct !== null && a?.cpuPct !== void 0 ? Math.round(a.cpuPct) + "%" : "—"}</b></div>`), m.push(l`<div class="m6"><span>内存</span><b>${a?.memPct !== null && a?.memPct !== void 0 ? Math.round(a.memPct) + "%" : "—"}</b></div>`), m.push(l`<div class="m6"><span>温度</span><b>${n !== null ? `${Math.round(n * 10) / 10}°` : "—"}</b></div>`)), p && m.push(l`<div class="m6"><span>PoE</span><b>${s.usedW !== null ? `${Math.round(s.usedW * 10) / 10}W` : "—"}</b></div>`), l`
      <div class="standard">
        <div class="between hdr">
          <span class="row">
            <span class="dot ${U(e.some((h) => h.online === !0))}"></span>
            <strong>UniFi</strong>
            ${this.hasModule("updated") ? l`<span class="faint compact-time">${t ? Z(t.fetchedAt) : "加载中"}</span>` : v}
          </span>
          <span class="row">${this.moduleHint("standard")}${this.mobileSpaceHint(o, c, g) || (this.state?.stale ? l`<span class="badge warn">陈旧</span>` : u && e.length ? l`<span class="faint">${e.length} WAN</span>` : v)}</span>
        </div>
        ${u ? l`<div class="std-wans">
          ${e.map((h) => l`
            <div class="wan-row ${h.active ? "active" : ""}" title=${`${R(h)} · ${h.operator ?? "未知运营商"} · ${h.id}`} @click=${(b) => {
      b.stopPropagation(), this.openDashboard("wan");
    }}>
              <span class="dot ${U(h.online)}"></span>
              <span class="wname"><b>${R(h)}</b><i>${this.opShort(h)}</i></span>
              <span class="wrates">${this.compactRate(h.rxBps, "down")}${this.compactRate(h.txBps, "up")}</span>
              <span class="lat num">${h.latencyMs !== null ? `${Math.round(h.latencyMs)}ms` : "—"}</span>
            </div>
          `)}
          ${e.length ? "" : l`<div class="empty">暂无 WAN 数据</div>`}
        </div>` : v}
        ${o ? l`<div class="std-device">GW ${r?.gatewayOnline ?? "—"}/${r?.gateway ?? "—"} · SW ${r?.switchOnline ?? "—"}/${r?.switch ?? "—"} · AP ${r?.apOnline ?? "—"}/${r?.ap ?? "—"}${d ? ` · 终端 ${r?.clientsTotal ?? "—"}` : ""}</div>` : v}
        ${m.length ? l`<div class="metrics6">${m}</div>` : v}
        ${c && a ? l`<div class="std-gw">固件 ${a.firmware ?? "—"} · ${D(a.uptimeSec)}</div>` : v}
        ${g ? l`<div class="std-speed">测速 ${this.latestSpeedtestText()}</div>` : v}
        ${!u && !o && !d && !c && !p && !g ? this.noModules() : v}
      </div>
    `;
  }
  renderWide() {
    const t = this.state?.snapshot, e = t?.wans.slice(0, 2) ?? [], s = t?.counts, n = It(t), a = te(t), r = t?.gateway, u = this.hasModule("wan"), o = this.hasModule("devices"), d = this.hasModule("clients"), c = this.hasModule("gateway"), p = this.hasModule("poe"), g = this.hasModule("speedtest"), m = o || d || c || p || g;
    return l`
      <div class="wide ${u ? "" : "no-wan"}">
        <div class="between hdr">
          <div class="row">
            <span class="dot ${U(e.some((h) => h.online === !0))}"></span>
            <strong class="title">UniFi 网络</strong>
            <span class="muted truncate">${r ? `${r.model} · ${r.name}` : ""}</span>
            ${this.state?.stale ? l`<span class="badge warn">陈旧数据</span>` : ""}
          </div>
          <div class="row">
            ${this.hasModule("updated") ? l`<span class="faint">${t ? `更新于 ${Z(t.fetchedAt)}` : "加载中"}</span>` : v}
            ${this.moduleHint("wide")}
            <button class="icon-btn" title="刷新" @click=${(h) => {
      h.stopPropagation(), this.refresh();
    }}>${y("refresh")}</button>
            <button class="icon-btn" title="设置" @click=${(h) => {
      h.stopPropagation(), this.openSettings();
    }}>${y("settings")}</button>
          </div>
        </div>
        <div class="wide-body ${m ? "" : "no-side"}">
          ${u ? l`<div class="wide-wans">
            ${e.map((h) => l`
              <div class="wide-wan surface" @click=${(b) => {
      b.stopPropagation(), this.openDashboard("wan");
    }}>
                <div class="between">
                  <span class="row"><span class="dot ${U(h.online)}"></span><b>${R(h)}</b>${h.active ? l`<span class="badge ok">承载</span>` : ""}</span>
                  <span class="faint truncate">${h.operator ?? "未知"}</span>
                </div>
                <div class="wide-rates">
                  <span class="down">↓ ${z(h.rxBps, this.state?.settings.showBits !== !1).value}${z(h.rxBps, this.state?.settings.showBits !== !1).unit}</span>
                  <span class="up">↑ ${z(h.txBps, this.state?.settings.showBits !== !1).value}${z(h.txBps, this.state?.settings.showBits !== !1).unit}</span>
                </div>
                <div class="wide-foot">${h.latencyMs !== null ? `${Math.round(h.latencyMs)}ms` : "延迟—"} · ${h.availabilityPct !== null ? I(h.availabilityPct) : "可用率—"} · ${F(h.linkSpeedMbps)}</div>
                ${this.sparkline(h)}
                ${this.wanIdentity(h) ? l`<div class="wide-ident">${this.wanIdentity(h)}</div>` : v}
              </div>
            `)}
          </div>` : v}
          ${m ? l`<div class="wide-side surface">
            <div class="between"><span class="muted">概览</span><span class="faint">${g ? "测速" : ""}</span></div>
            ${o ? l`<div class="wide-dev">网关 ${s?.gatewayOnline ?? "—"}/${s?.gateway ?? "—"} · 交换机 ${s?.switchOnline ?? "—"}/${s?.switch ?? "—"} · AP ${s?.apOnline ?? "—"}/${s?.ap ?? "—"}</div>` : v}
            ${d ? l`<div class="wide-dev">终端 ${s?.clientsTotal ?? "—"} · 有线 ${s?.clientsWired ?? "—"} · 无线 ${s?.clientsWireless ?? "—"}</div>` : v}
            ${c ? l`<div class="wide-gw">CPU ${r?.cpuPct !== null && r?.cpuPct !== void 0 ? Math.round(r.cpuPct) + "%" : "—"} · 内存 ${r?.memPct !== null && r?.memPct !== void 0 ? Math.round(r.memPct) + "%" : "—"}</div>` : v}
            ${c ? l`<div class="wide-gw">温度 ${a !== null ? it(a) : "—"} · 固件 ${r?.firmware ?? "—"}</div>` : v}
            ${c ? l`<div class="wide-gw">运行 ${r ? D(r.uptimeSec) : "—"}</div>` : v}
            ${p ? l`<div class="wide-gw">PoE ${n.usedW !== null ? `${Math.round(n.usedW * 10) / 10}W` : "—"}${n.budgetW !== null ? ` / ${Math.round(n.budgetW)}W` : ""}</div>` : v}
            ${g ? l`<div class="wide-gw">测速 ${this.latestSpeedtestText()}</div>` : v}
            ${!o && !d && !c && !p && !g ? this.noModules() : v}
          </div>` : v}
        </div>
      </div>
    `;
  }
  renderFull() {
    const t = this.state?.snapshot, e = t?.wans.slice(0, 4) ?? [], s = t?.counts, n = It(t), a = te(t), r = t?.gateway, u = this.hasModule("wan"), o = this.hasModule("devices"), d = this.hasModule("clients"), c = this.hasModule("gateway"), p = this.hasModule("poe"), g = this.hasModule("speedtest"), m = o || d || c || p || g;
    return l`
      <div class="full">
        <div class="between hdr">
          <div class="row">
            <span class="dot ${U(e.some((h) => h.online === !0))}"></span>
            <strong class="title">UniFi 网络</strong>
            <span class="muted truncate">${r ? `${r.model} · ${r.name}` : ""}</span>
            ${this.state?.stale ? l`<span class="badge warn">陈旧数据</span>` : ""}
          </div>
          <div class="row">
            ${this.hasModule("updated") ? l`<span class="faint" title=${t ? ti(t.fetchedAt) : ""}>${t ? `更新于 ${Z(t.fetchedAt)}` : "加载中"}</span>` : v}
            ${this.moduleHint("full")}
            <button class="icon-btn" title="刷新" @click=${(h) => {
      h.stopPropagation(), this.refresh();
    }}>${y("refresh")}</button>
            <button class="icon-btn" title="设置" @click=${(h) => {
      h.stopPropagation(), this.openSettings();
    }}>${y("settings")}</button>
          </div>
        </div>
        <div class="full-body ${m ? "" : "no-side"}">
          ${u ? l`<div class="wancards">
            ${e.map((h) => {
      const b = z(h.rxBps, this.state?.settings.showBits !== !1), k = z(h.txBps, this.state?.settings.showBits !== !1);
      return l`
                <div class="wancard surface" @click=${($) => {
        $.stopPropagation(), this.openDashboard("wan");
      }}>
                  <div class="between">
                    <span class="row"><span class="dot ${U(h.online)}"></span><strong>${R(h)}</strong>${h.active ? l`<span class="badge ok">承载</span>` : ""}</span>
                    <span class="faint truncate">${h.operator ?? "未知运营商"}</span>
                  </div>
                  <div class="big-rates">
                    <div class="big-rate"><span class="muted">${y("download")} 下载</span><span class="num">${b.value}</span><span class="unit">${b.unit}</span></div>
                    <div class="big-rate up"><span class="muted">${y("upload")} 上传</span><span class="num">${k.value}</span><span class="unit">${k.unit}</span></div>
                  </div>
                  <div class="wancard-foot">
                    <span title="延迟">${h.latencyMs !== null ? `${Math.round(h.latencyMs)} ms` : "延迟 —"}</span>
                    <span title="可用率">${h.availabilityPct !== null ? I(h.availabilityPct) : "可用率 —"}</span>
                    <span title="网口协商速率（不是宽带签约速率）">${F(h.linkSpeedMbps)}</span>
                  </div>
                  ${this.sparkline(h) ? l`<div class="full-spark">${this.sparkline(h)}</div>` : v}
                  ${this.wanIdentity(h) ? l`<div class="wide-ident">${this.wanIdentity(h)}</div>` : v}
                </div>
              `;
    })}
          </div>` : v}
          ${m ? l`<div class="side">
            ${o ? l`<div class="surface pad">
              <div class="between"><span class="muted">设备</span><span class="faint">在线 / 总数</span></div>
              <div class="dev-grid">
                <div><span class="muted">${y("gateway")} 网关</span><b>${s?.gatewayOnline ?? "—"}/${s?.gateway ?? "—"}</b></div>
                <div><span class="muted">${y("switch")} 交换机</span><b>${s?.switchOnline ?? "—"}/${s?.switch ?? "—"}</b></div>
                <div><span class="muted">${y("ap")} AP</span><b>${s?.apOnline ?? "—"}/${s?.ap ?? "—"}</b></div>
              </div>
            </div>` : v}
            ${d ? l`<div class="surface pad">
              <div class="between"><span class="muted">终端</span><span class="faint">有线 / 无线 / 总数</span></div>
              <div class="dev-grid">
                <div><span class="muted">${y("wired")} 有线</span><b>${s?.clientsWired ?? "—"}</b></div>
                <div><span class="muted">${y("wifi")} 无线</span><b>${s?.clientsWireless ?? "—"}</b></div>
                <div><span class="muted">${y("activity")} 终端</span><b>${s?.clientsTotal ?? "—"}</b></div>
              </div>
            </div>` : v}
            ${c ? l`<div class="surface pad">
              <div class="between"><span class="muted">网关</span><span class="faint">${r?.firmware ?? "—"}</span></div>
              <div class="gw-line"><span>CPU</span><b>${r?.cpuPct !== null && r?.cpuPct !== void 0 ? Math.round(r.cpuPct) + "%" : "—"}</b></div>
              <div class="gw-line"><span>内存</span><b>${r?.memPct !== null && r?.memPct !== void 0 ? Math.round(r.memPct) + "%" : "—"}</b></div>
              <div class="gw-line"><span>温度</span><b>${a !== null ? it(a) : "—"}</b></div>
              <div class="gw-line"><span>运行</span><b>${r ? D(r.uptimeSec) : "—"}</b></div>
              ${p ? l`<div class="gw-line"><span>PoE</span><b>${n.usedW !== null ? `${Math.round(n.usedW * 10) / 10} / ${n.budgetW !== null ? Math.round(n.budgetW) : "—"} W` : "—"}</b></div>` : v}
            </div>` : v}
            ${p && !c ? l`<div class="surface pad">
              <div class="between"><span class="muted">PoE</span><span class="faint">总功耗</span></div>
              <div class="gw-line"><span>已用 / 预算</span><b>${n.usedW !== null ? `${Math.round(n.usedW * 10) / 10}${n.budgetW !== null ? ` / ${Math.round(n.budgetW)}` : ""} W` : "—"}</b></div>
            </div>` : v}
            ${g ? l`<div class="surface pad">
              <div class="between"><span class="muted">历史测速</span><span class="faint">最新</span></div>
              <div class="gw-line"><span>结果</span><b>${this.latestSpeedtestText()}</b></div>
            </div>` : v}
            ${!o && !d && !c && !p && !g ? this.noModules() : v}
          </div>` : v}
        </div>
      </div>
    `;
  }
  render() {
    const t = this.state, e = this.size(), s = !!t?.snapshot, n = String(this.spCtx?.widgetInfo?.gridSize ?? ""), a = `wrap size-${e}${e === "compact" ? n === "2x1" ? " compact-tall" : " compact-wide" : ""}`;
    return l`
      <div class=${a} role="button" tabindex="0"
        aria-label="UniFi 网络监控，点击打开详情"
        @click=${() => this.openDashboard()}
        @keydown=${(r) => {
      (r.key === "Enter" || r.key === " ") && (r.preventDefault(), this.openDashboard());
    }}>
        ${!t?.initialized && !s ? l`
          <div class="loading">
            <div class="skeleton" style="width:42%;height:12px"></div>
            <div class="skeleton" style="width:86%;height:10px;margin-top:10px"></div>
            <div class="skeleton" style="width:70%;height:10px;margin-top:6px"></div>
          </div>
        ` : t?.lastError && !s ? this.renderError() : e === "tiny" ? this.renderTiny() : e === "compact" ? this.renderCompact() : e === "standard" ? this.renderStandard() : e === "wide" ? this.renderWide() : this.renderFull()}
      </div>
    `;
  }
};
Ye.styles = [pe, Lt`
    :host { container-type: inline-size; height: 100%; }
    .wrap { height: 100%; padding: 10px 12px; cursor: pointer; user-select: none; border-radius: 12px; overflow: hidden; display: flex; flex-direction: column; justify-content: center; gap: 6px; outline: none; }
    .wrap:focus-visible { box-shadow: inset 0 0 0 2px var(--sp-down); }
    .size-tiny { padding: 8px 9px; }
    .hdr { min-height: 18px; font-size: 12px; }
    .title { font-size: 13px; }
    .icon-btn { appearance: none; border: 0; background: transparent; color: var(--sp-muted); cursor: pointer; padding: 3px; border-radius: 6px; display: inline-flex; }
    .icon-btn:hover { background: var(--sp-surface); color: var(--sp-text); }
    .tiny { display: flex; flex-direction: column; gap: 6px; }
    .tiny-title { font-size: 11px; font-weight: 600; letter-spacing: .3px; }
    .tiny-rates { display: flex; flex-direction: column; gap: 2px; }
    .rate { display: inline-flex; align-items: baseline; gap: 3px; font-size: 11px; white-space: nowrap; }
    .rate .ic { width: 12px; height: 12px; align-self: center; }
    .rate .num { font-size: 12px; font-weight: 600; }
    .rate .unit { font-size: 9px; color: var(--sp-muted); }
    .rate.down { color: var(--sp-down); }
    .rate.up { color: var(--sp-up); }
    .tiny .rate .num { font-size: 11px; }
    .compact { display: flex; flex-direction: column; gap: 5px; }
    .compact-wans { display: flex; flex-direction: column; gap: 1px; }
    .compact-wans .wan-line { flex-direction: column; align-items: stretch; gap: 0; padding: 0 1px; }
    .wan-l1, .wan-l2 { display: flex; align-items: center; gap: 3px; min-width: 0; }
    .wan-l1 .wan-name { flex-direction: row; align-items: baseline; gap: 4px; }
    .wan-l1 .wan-name .name { font-size: 9px; }
    .wan-l1 .wan-name .op { max-width: 60px; }
    .wan-l2 { justify-content: flex-end; }
    .wan-l2 .wan-rates { margin-left: 0; gap: 4px; }
    .wan-l2 .lat { width: auto; min-width: 22px; }
    .wan-line { display: flex; align-items: center; gap: 6px; padding: 3px 4px; border-radius: 7px; min-width: 0; }
    .wan-line:hover { background: var(--sp-surface); }
    .wan-name { display: flex; flex-direction: column; line-height: 1.15; min-width: 0; }
    .wan-name .name { font-size: 11px; font-weight: 600; }
    .wan-name .op { font-size: 9px; color: var(--sp-muted); overflow: hidden; text-overflow: ellipsis; white-space: nowrap; max-width: 90px; }
    .wan-rates { display: flex; gap: 6px; margin-left: auto; }
    .lat { font-size: 9px; color: var(--sp-muted); min-width: 34px; text-align: right; }
    .compact-foot { font-size: 9px; }
    .standard { display: flex; flex-direction: column; gap: 6px; height: 100%; justify-content: center; }
    .std-wans { display: flex; flex-direction: column; gap: 3px; }
    .wan-row { display: flex; align-items: center; gap: 4px; min-width: 0; padding: 2px 3px; border-radius: 6px; border-left: 2px solid transparent; }
    .wan-row:hover { background: var(--sp-surface); }
    .wan-row.active { border-left-color: var(--sp-ok); background: color-mix(in srgb, var(--sp-ok) 7%, transparent); }
    .wan-row .dot { width: 6px; height: 6px; }
    .wname { display: flex; flex-direction: column; line-height: 1.1; width: 34px; min-width: 30px; flex: none; }
    .wname b { font-size: 10px; font-weight: 650; }
    .wname i { font-style: normal; font-size: 8px; color: var(--sp-muted); overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
    .wrates { display: flex; align-items: baseline; gap: 3px; margin-left: auto; min-width: 0; }
    .crate { display: inline-flex; align-items: baseline; gap: 0; font-size: 9.5px; font-weight: 600; font-variant-numeric: tabular-nums; white-space: nowrap; }
    .crate.down { color: var(--sp-down); }
    .crate.up { color: var(--sp-up); }
    .crate .arrow { font-size: 9px; font-weight: 400; }
    .crate .cu { font-size: 7px; color: var(--sp-muted); font-weight: 500; margin-left: 1px; }
    .lat { font-size: 8px; color: var(--sp-muted); width: 22px; text-align: right; flex: none; }
    .metrics6 { display: grid; grid-template-columns: repeat(3, minmax(0, 1fr)); gap: 1px 3px; border-top: 1px solid var(--sp-border-soft); padding-top: 5px; }
    .m6 { display: flex; align-items: baseline; justify-content: space-between; gap: 2px; min-width: 0; }
    .m6 span { font-size: 8px; color: var(--sp-muted); white-space: nowrap; }
    .m6 b { font-size: 9px; font-weight: 600; font-variant-numeric: tabular-nums; white-space: nowrap; }
    .full { display: flex; flex-direction: column; gap: 8px; height: 100%; }
    .full-body { display: grid; grid-template-columns: minmax(0, 1.62fr) minmax(190px, .9fr); gap: 8px; flex: 1; min-height: 0; }
    /* 2x4 / 1xfull: short, wide cards. Use one row (WAN1 | WAN2 | compact side)
       and hide the speedtest block; 4x4 keeps the tall layout. */
    .wrap.size-wide .wide { display: flex; flex-direction: column; gap: 4px; height: 100%; }
    .wrap.size-wide .wide-body { display: flex; gap: 6px; flex: 1; min-height: 0; }
    .wrap.size-wide .wide-wan { flex: 1 1 0; min-width: 0; padding: 5px 6px; display: flex; flex-direction: column; gap: 3px; cursor: pointer; }
    .wrap.size-wide .wide-wan:hover { background: var(--sp-surface-hover); }
    .wrap.size-wide .wide-rates { display: flex; flex-direction: column; align-items: flex-start; gap: 0; font-size: 11px; line-height: 1.25; font-weight: 700; white-space: nowrap; letter-spacing: -.2px; }
    .wrap.size-wide .wide-rates .down { color: var(--sp-down); }
    .wrap.size-wide .wide-rates .up { color: var(--sp-up); }
    .wrap.size-wide .wide-foot { font-size: 8px; color: var(--sp-muted); white-space: nowrap; overflow: hidden; text-overflow: ellipsis; }
    .wrap.size-wide .wide-side { flex: 0 0 132px; min-width: 0; padding: 5px 6px; display: flex; flex-direction: column; gap: 2px; font-size: 8px; overflow: hidden; }
    .wrap.size-wide .wide-dev, .wrap.size-wide .wide-gw { white-space: normal; overflow: hidden; text-overflow: clip; line-height: 1.35; font-size: 7.5px; color: var(--sp-muted); }
    .wrap.size-wide .wide-dev b, .wrap.size-wide .wide-gw b { color: var(--sp-text); }
    .wancards { display: grid; grid-template-columns: repeat(auto-fit, minmax(180px, 1fr)); gap: 7px; align-content: start; }
    .wancard { padding: 8px 9px; display: flex; flex-direction: column; gap: 3px; cursor: pointer; }
    .wancard:hover { background: var(--sp-surface-hover); }
    .big-rates { display: flex; align-items: baseline; gap: 12px; flex-wrap: wrap; }
    .big-rate { display: flex; align-items: baseline; gap: 3px; color: var(--sp-down); }
    .big-rate.up { color: var(--sp-up); }
    .big-rate .muted { font-size: 9px; display: inline-flex; align-items: center; gap: 2px; }
    .big-rate .num { font-size: 19px; font-weight: 700; line-height: 1.05; letter-spacing: -.4px; }
    .big-rate .unit { font-size: 9px; color: var(--sp-muted); }
    .wancard-foot { display: flex; justify-content: space-between; gap: 4px; font-size: 9px; color: var(--sp-muted); }
    .side { display: flex; flex-direction: column; gap: 7px; min-width: 0; }
    .pad { padding: 7px 8px; display: flex; flex-direction: column; gap: 4px; font-size: 11px; }
    .dev-grid { display: grid; grid-template-columns: 1fr 1fr; gap: 3px 8px; }
    .dev-grid > div { display: flex; justify-content: space-between; gap: 4px; min-width: 0; }
    .dev-grid .muted { display: inline-flex; align-items: center; gap: 3px; font-size: 10px; }
    .dev-grid b { font-variant-numeric: tabular-nums; font-weight: 600; }
    .gw-line { display: flex; justify-content: space-between; gap: 6px; font-size: 11px; }
    .gw-line span { color: var(--sp-muted); }
    .gw-line b { font-variant-numeric: tabular-nums; }
    .err { display: flex; flex-direction: column; gap: 6px; cursor: default; }
    .err strong { font-size: 12px; }
    .err-msg { font-size: 11px; color: var(--sp-bad); }
    .err-hint { font-size: 10px; color: var(--sp-muted); line-height: 1.35; display: -webkit-box; -webkit-line-clamp: 2; -webkit-box-orient: vertical; overflow: hidden; }
    .err .btn { align-self: flex-start; }
    .loading { display: flex; flex-direction: column; justify-content: center; height: 100%; }
    .module-hint { font-size: 7px; padding: 1px 4px; border-radius: 5px; background: rgba(255,255,255,.08); color: var(--sp-muted); white-space: nowrap; }
    .module-empty { display: flex; flex-direction: column; align-items: center; justify-content: center; gap: 2px; height: 100%; font-size: 9px; color: var(--sp-muted); text-align: center; }
    .module-empty span { color: var(--sp-down); cursor: pointer; }
    .std-device { font-size: 8px; color: var(--sp-muted); border-top: 1px solid var(--sp-border-soft); padding-top: 4px; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; }
    .std-gw, .std-speed { font-size: 7.5px; color: var(--sp-muted); white-space: nowrap; overflow: hidden; text-overflow: ellipsis; }
    .spark { display: block; width: 100%; height: 14px; margin-top: 2px; opacity: .95; }
    .wide-wans { display: flex; gap: 6px; flex: 1; min-width: 0; }
    .wide-ident { font-size: 7px; color: var(--sp-muted); white-space: nowrap; overflow: hidden; text-overflow: ellipsis; }
    .wide-body.no-side { display: block; }
    .wide-body.no-side .wide-wans { height: 100%; }
    .wide.no-wan .wide-body { display: flex; }
    .wide.no-wan .wide-side { flex: 1; }
    .full .full-spark { height: 14px; margin-top: 2px; }
    .full .full-spark .spark { height: 14px; }
    .full-body.no-side { grid-template-columns: 1fr; }
    .full-body.no-side .wancards { grid-template-columns: repeat(auto-fit, minmax(220px, 1fr)); }
    @media (max-width: 520px) {
      .std-device, .std-gw, .std-speed { font-size: 7px; }
      .module-hint { font-size: 6.5px; padding: 0 3px; }
      .spark { height: 12px; }
    }
    @container (max-width: 210px) {
      .wan-name .op { display: none; }
      .big-rate .num { font-size: 15px; }
      .wancard-foot { font-size: 8px; }
    }
    @container (max-width: 176px) {
      .wan-row { gap: 2px; padding: 1px 1px; }
      .wname { width: 30px; min-width: 28px; }
      .lat { width: 18px; font-size: 7px; }
      .crate { font-size: 8px; }
      .crate .cu { font-size: 6px; }
      .metrics6 { grid-template-columns: repeat(2, minmax(0, 1fr)); gap: 1px 4px; }
      .m6 span { font-size: 7px; }
      .m6 b { font-size: 8px; }
      .metrics6 { padding-top: 4px; }
    }
    @container (max-width: 150px) {
      .title { font-size: 11px; }
      .wname i { display: none; }
      .m6 span { font-size: 6.5px; }
      .m6 b { font-size: 7.5px; }
    }
    .compact-wans .wan-single { flex-direction: row; align-items: center; gap: 3px; }
    .wan-single { align-items: center; gap: 3px; }
    .wan-single .name { font-size: 9px; white-space: nowrap; }
    .wan-single .op { font-size: 6px; color: var(--sp-muted); max-width: 42px; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; }
    .wan-single .tiny-badge { font-size: 5.5px; padding: 0 2px; }
    .wan-single .lat { width: auto; font-size: 7px; }
    .size-compact.compact-wide .compact-foot { font-size: 6px; }
    .size-compact.compact-tall .wan-l2 .lat { align-self: flex-end; width: auto; font-size: 7px; }
    .size-compact.compact-wide { padding: 4px 6px; gap: 1px; }
    .size-compact.compact-wide .hdr { font-size: 10px; }
    .size-compact.compact-wide .wan-line { gap: 0; }
    .size-compact.compact-wide .compact-foot { font-size: 6.5px; }
    .size-compact.compact-wide .wan-l1 .name { font-size: 8.5px; }
    .size-compact.compact-wide .wan-l1 .op { font-size: 6.5px; max-width: 70px; }
    .size-compact.compact-wide .crate { font-size: 7.5px; }
    .size-compact.compact-tall { padding: 6px 7px; gap: 1px; }
    .size-compact.compact-tall .hdr { font-size: 10px; }
    .size-compact.compact-tall .compact-foot { flex-direction: column; align-items: flex-start; gap: 1px; font-size: 6.5px; }
    .size-compact.compact-tall .wan-l2 .wan-rates { flex-direction: column; align-items: flex-start; gap: 0; }
    .size-compact.compact-tall .wan-l2 { flex-direction: column; align-items: flex-end; justify-content: flex-start; gap: 0; }
    .size-compact.compact-tall .wan-l1 .op { display: none; }
    @container (max-width: 120px) { .compact-tall .compact-time { display: none; } }
    .size-tiny .unit { font-size: 5px; }
    .size-tiny .module-hint { font-size: 6px; padding: 0 2px; }
    .size-tiny .faint { font-size: 6px; }
    .size-tiny .rate { font-size: 10px; }
    /* Mobile cards are often ~160px wide (2 columns); viewport media queries
       are used as a reliable fallback when container queries are unsupported. */
    @media (max-width: 520px) {
      .wan-row { gap: 3px; padding: 1px 2px; }
      .wname { width: 32px; min-width: 30px; }
      .wrates { gap: 2px; }
      .crate { font-size: 8px; }
      .crate .cu { font-size: 6px; }
      .metrics6 { grid-template-columns: repeat(2, minmax(0, 1fr)); gap: 1px 4px; }
      .m6 span { font-size: 7px; }
      .m6 b { font-size: 8px; }
    }
  `];
let Ue = Ye;
const Aa = {
  pages: {
    "unifi-settings": { ...Gt.pages["unifi-settings"], component: Re },
    "unifi-dashboard": { ...Gt.pages["unifi-dashboard"], component: Ie },
    "unifi-client-detail": { ...Gt.pages["unifi-client-detail"], component: Ne }
  },
  widgets: {
    "unifi-widget": { ...Gt.widgets["unifi-widget"], component: Ue }
  }
}, _a = "UniFi Network Monitor", Ma = "Read-only monitoring for UniFi gateway, dual WAN, switches, APs and clients. Auto-discovers devices and links from the local controller.", Sa = "Uses Sun-Panel network passthrough for read-only GET requests to the local UniFi controller (API key authentication).", Ca = "UniFi Network Monitor", Pa = "Dual-WAN rates/latency, device counts, wired/wireless clients, gateway CPU/memory/temperature and PoE.", Ta = "OK", Ea = "Warning", Ia = "Error", Na = "Unknown", Ra = "Unsupported", Ua = "Updated", Ba = "Refresh", Oa = "Settings", za = "Save & apply", Da = "Cancel", Wa = "Test connection", Ha = "Export diagnostics", La = "Copy", Fa = "Clear", ja = "Loading", Ka = {
  APP_NAME: _a,
  APP_DESCRIPTION: Ma,
  NETWORK_DESCRIPTION: Sa,
  WIDGET_NAME: Ca,
  WIDGET_DESCRIPTION: Pa,
  COMMON_OK: Ta,
  COMMON_WARN: Ea,
  COMMON_BAD: Ia,
  COMMON_UNKNOWN: Na,
  COMMON_UNSUPPORTED: Ra,
  COMMON_UPDATED: Ua,
  COMMON_REFRESH: Ba,
  COMMON_SETTINGS: Oa,
  COMMON_SAVE: za,
  COMMON_CANCEL: Da,
  COMMON_TEST: Wa,
  COMMON_EXPORT: Ha,
  COMMON_COPY: La,
  COMMON_CLEAR: Fa,
  COMMON_LOADING: ja
}, Ga = "UniFi 网络监控", qa = "只读监控 UniFi 网关、双 WAN、交换机、AP 与终端；自动识别设备与线路，数据来自本地控制器。", Va = "通过 Sun-Panel 网络透传访问本地 UniFi 控制器的只读 GET 接口（API Key 认证）。", Xa = "UniFi 网络监控", Za = "双 WAN 速率/延迟、设备在线数、有线无线终端、网关 CPU/内存/温度与 PoE。", Ya = "正常", Ja = "警告", Qa = "异常", tr = "未知", er = "暂不支持", sr = "更新于", ir = "刷新", nr = "设置", ar = "保存并应用", rr = "取消", or = "测试连接", lr = "导出诊断", dr = "复制", cr = "清除", pr = "加载中", ur = {
  APP_NAME: Ga,
  APP_DESCRIPTION: qa,
  NETWORK_DESCRIPTION: Va,
  WIDGET_NAME: Xa,
  WIDGET_DESCRIPTION: Za,
  COMMON_OK: Ya,
  COMMON_WARN: Ja,
  COMMON_BAD: Qa,
  COMMON_UNKNOWN: tr,
  COMMON_UNSUPPORTED: er,
  COMMON_UPDATED: sr,
  COMMON_REFRESH: ir,
  COMMON_SETTINGS: nr,
  COMMON_SAVE: ar,
  COMMON_CANCEL: rr,
  COMMON_TEST: or,
  COMMON_EXPORT: lr,
  COMMON_COPY: dr,
  COMMON_CLEAR: cr,
  COMMON_LOADING: pr
}, hr = {
  "zh-CN": ur,
  "en-US": Ka
};
Ri({
  translations: hr,
  defaultLocale: Ae.defaultLocale,
  dev: !1
});
const wr = {
  appConfig: {
    ...Ae,
    apiVersion: Ni,
    microAppId: Ae.microAppId,
    dev: !1
  },
  components: Aa
};
export {
  wr as default
};
